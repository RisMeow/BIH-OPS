import React from 'react';
import { AlertTriangle, X, HelpCircle } from 'lucide-react';

interface ConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    variant?: 'danger' | 'info';
}

export default function ConfirmModal({
    isOpen, onClose, onConfirm, title, message,
    confirmText = "Xác nhận", cancelText = "Hủy", variant = 'info'
}: ConfirmModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-[2px] p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-6 scale-100 animate-in zoom-in-95 duration-200 border border-white/20 ring-1 ring-black/5">
                <div className="flex flex-col items-center text-center mb-6">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 shadow-lg ${variant === 'danger'
                            ? 'bg-red-50 text-red-500 shadow-red-500/20'
                            : 'bg-blue-50 text-blue-500 shadow-blue-500/20'
                        }`}>
                        {variant === 'danger' ? <AlertTriangle size={32} /> : <HelpCircle size={32} />}
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">{title}</h3>
                    <p className="text-slate-500 leading-relaxed font-medium text-sm">{message}</p>
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={onClose}
                        className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-2xl transition-all"
                    >
                        {cancelText}
                    </button>
                    <button
                        onClick={() => { onConfirm(); onClose(); }}
                        className={`flex-1 py-3 text-white font-bold rounded-2xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 ${variant === 'danger'
                                ? 'bg-red-500 hover:bg-red-600 shadow-red-500/20'
                                : 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/20'
                            }`}
                    >
                        {confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
}

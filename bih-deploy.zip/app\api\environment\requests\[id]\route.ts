import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can manage environment tasks
function canManageEnvironment(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'ENVIRONMENT' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) return true;
    return false;
}

// GET: Get single request detail
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const cleaningRequest = await prisma.cleaningRequest.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        if (!cleaningRequest) {
            return NextResponse.json({ error: "Request not found" }, { status: 404 });
        }

        return NextResponse.json(cleaningRequest);
    } catch (error) {
        console.error("Get Cleaning Request Error:", error);
        return NextResponse.json({ error: 'Failed to fetch request' }, { status: 500 });
    }
}

// PATCH: Update status or assign staff
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { assignedToId, status } = body;

        const updateData: any = {};

        // ASSIGN: Only leaders/admin can assign
        if (assignedToId !== undefined) {
            if (!canManageEnvironment(user)) {
                return NextResponse.json({
                    error: "Permission denied: Only Environment Leader can assign tasks"
                }, { status: 403 });
            }
            updateData.assignedToId = assignedToId ? parseInt(assignedToId) : null;
            if (!status || status === 'PENDING') {
                updateData.status = 'ASSIGNED';
            }
        }

        // STATUS CHANGE
        if (status) {
            // COMPLETED: Assigned staff or leaders can update
            if (['IN_PROGRESS', 'COMPLETED'].includes(status)) {
                const currentRequest = await prisma.cleaningRequest.findUnique({ where: { id } });
                const isAssignedStaff = currentRequest?.assignedToId === user.id;
                const isLeader = canManageEnvironment(user);

                if (!isAssignedStaff && !isLeader) {
                    return NextResponse.json({
                        error: "Permission denied: Only assigned staff or leaders can update status"
                    }, { status: 403 });
                }
            }

            updateData.status = status;
        }

        const updatedRequest = await prisma.cleaningRequest.update({
            where: { id },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        return NextResponse.json(updatedRequest);
    } catch (error) {
        console.error("Update Cleaning Request Error:", error);
        return NextResponse.json({ error: 'Failed to update request' }, { status: 500 });
    }
}

// DELETE: Delete request (Only admin or environment leader)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (!canManageEnvironment(user)) {
            return NextResponse.json({
                error: "Permission denied: Only Environment Leader can delete requests"
            }, { status: 403 });
        }

        await prisma.cleaningRequest.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted successfully' });
    } catch (error) {
        console.error("Delete Cleaning Request Error:", error);
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
    const { data: session, status } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === "authenticated" && session?.user?.role) {
            const role = session.user.role as string;
            // Redirect to the user's department dashboard
            const redirectPath = `/dashboard/${role.toLowerCase()}`;
            router.replace(redirectPath);
        }
    }, [status, session, router]);

    if (status === "loading") {
        return (
            <div className="h-full flex flex-col items-center justify-center gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-[var(--bih-teal)]" />
                <p className="text-[var(--bih-gray-500)]">Đang tải...</p>
            </div>
        );
    }

    // Show loading while redirecting
    return (
        <div className="h-full flex flex-col items-center justify-center gap-4">
            <Loader2 className="w-8 h-8 animate-spin text-[var(--bih-teal)]" />
            <p className="text-[var(--bih-gray-500)]">Đang chuyển hướng...</p>
        </div>
    );
}

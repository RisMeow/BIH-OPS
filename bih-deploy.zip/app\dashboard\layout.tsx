"use client";

import { useSession, signOut } from "next-auth/react";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import {
    Wrench, Stethoscope, Car, Shield, Package, Leaf,
    LogOut, User, Settings, Menu, X, ChevronDown,
    Home, FileText, Building2
} from "lucide-react";
import styles from "./layout.module.css";
import { useLanguage } from "@/app/context/LanguageContext";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import NotificationPopover from "@/app/components/NotificationPopover";
import BottomNav from "@/app/components/BottomNav";
import AIChatWidget from "@/components/AIChatWidget";

// Role configuration (static data like icons/colors)
const roleConfigs: Record<string, { icon: React.ElementType; color: string; translationKey: string }> = {
    TECHNICAL: { icon: Wrench, color: "var(--bih-teal)", translationKey: "technical" },
    NURSING: { icon: Stethoscope, color: "#EC4899", translationKey: "nursing" },
    DRIVER: { icon: Car, color: "#8B5CF6", translationKey: "driver" },
    SECURITY: { icon: Shield, color: "#F59E0B", translationKey: "security" },
    SUPPLY: { icon: Package, color: "#10B981", translationKey: "supply" },
    ENVIRONMENT: { icon: Leaf, color: "#06B6D4", translationKey: "environment" },
    ADMIN: { icon: Settings, color: "#EF4444", translationKey: "system" },
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
    const { data: session, status } = useSession();
    const router = useRouter();
    const pathname = usePathname();
    const { t } = useLanguage();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        if (status === "unauthenticated") {
            router.push("/");
        }
    }, [status, router]);

    if (status === "loading") {
        return (
            <div className={styles.loadingScreen}>
                <div className={styles.loadingSpinner} />
                <p>{t.common.loading}</p>
            </div>
        );
    }

    if (!session) return null;

    const userRole = session.user?.role as string || "ADMIN";
    const userName = session.user?.name || "User";
    const userPosition = (session.user as any)?.position || "";

    const currentDeptConfig = roleConfigs[userRole] || roleConfigs.ADMIN;
    const DeptIcon = currentDeptConfig.icon;

    // Helper to get translated department name
    const getDeptLabel = (key: string) => {
        // @ts-ignore
        return t.sidebar[roleConfigs[key]?.translationKey] || key;
    };

    const currentDeptLabel = getDeptLabel(userRole);

    // Navigation items based on role
    const getNavItems = () => {
        const baseItems = [
            { href: "/dashboard/request", icon: FileText, label: t.nav.sendRequest },
            { href: "/dashboard/my-requests", icon: Home, label: t.nav.myRequests },
            { href: "/dashboard/profile", icon: User, label: t.nav.profile },
        ];

        if (userRole === "ADMIN") {
            const allDepartments = Object.keys(roleConfigs)
                .filter((key) => key !== 'ADMIN')
                .map((key) => ({
                    href: `/dashboard/${key.toLowerCase()}`,
                    icon: roleConfigs[key].icon,
                    label: getDeptLabel(key),
                }));

            const adminItem = {
                href: "/dashboard/system",
                icon: Settings,
                label: t.nav.systemSettings,
            };

            return [adminItem, ...allDepartments, ...baseItems];
        }

        const deptItem = {
            href: `/dashboard/${userRole.toLowerCase()}`,
            icon: currentDeptConfig.icon,
            label: t.nav.myDepartment,
        };

        return [deptItem, ...baseItems];
    };

    const navItems = getNavItems();

    const handleLogout = async () => {
        await signOut({ redirect: false });
        router.push("/");
    };

    const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

    // Determine dashboard link for the badge
    const dashboardLink = userRole === 'ADMIN' ? '/dashboard/admin' : `/dashboard/${userRole.toLowerCase()}`;

    return (
        <div className={styles.layout}>
            {/* Sidebar */}
            <aside className={styles.sidebar}>
                {/* Logo */}
                <div className={styles.sidebarHeader}>
                    <div className={styles.logoContainer}>
                        <div className="relative w-[140px] h-[46px]">
                            <Image
                                src="/BIH-Logo-147x48-1.png"
                                alt="BIH Logo"
                                fill
                                style={{ objectFit: 'contain' }}
                                priority
                            />
                        </div>
                    </div>
                    <div className="mt-1 pl-1">
                        <span className="text-xs font-bold text-teal-600 uppercase tracking-widest block">Operation</span>
                    </div>
                </div>

                {/* Department Badge - NOW CLICKABLE */}
                <Link href={dashboardLink} className={styles.deptBadge} style={{ backgroundColor: `${currentDeptConfig.color}15`, borderColor: `${currentDeptConfig.color}30`, cursor: 'pointer', textDecoration: 'none' }}>
                    <DeptIcon size={18} style={{ color: currentDeptConfig.color }} />
                    <span style={{ color: currentDeptConfig.color }}>{currentDeptLabel}</span>
                </Link>

                {/* Navigation */}
                <nav className={styles.nav}>
                    {navItems.map((item) => {
                        const Icon = item.icon;
                        const active = isActive(item.href);
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={`${styles.navItem} ${isActive(item.href) ? styles.active : ""}`}
                            >
                                <Icon size={20} />
                                <span>{item.label}</span>
                                {active && (
                                    <motion.div
                                        layoutId="activeIndicator"
                                        className={styles.activeIndicator}
                                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                                    />
                                )}
                            </Link>
                        );
                    })}
                </nav>

                {/* User Profile */}
                <div className={styles.userProfile}>
                    <div className={styles.userInfo}>
                        <div className={styles.avatar}>
                            {userName.charAt(0).toUpperCase()}
                        </div>
                        <div className={styles.userDetails}>
                            <span className={styles.userName}>{userName}</span>
                            <span className={styles.userRole}>{userPosition || userRole}</span>
                        </div>
                    </div>
                    <button onClick={handleLogout} className={styles.logoutBtn} title={t.common.logout}>
                        <LogOut size={18} />
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <div className={styles.mainWrapper}>
                {/* Top Header */}
                <header className={styles.header}>
                    <button
                        className={styles.mobileMenuBtn}
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        <Menu size={24} />
                    </button>
                    <h2 className={styles.pageTitle}>
                        {t.nav.welcome}, {userName}
                    </h2>
                    <div className={styles.headerActions}>
                        {/* Language Switcher */}
                        <LanguageSwitcher />
                        {/* Notification Popover */}
                        <NotificationPopover />
                    </div>
                </header>

                {/* Page Content */}
                <main className={styles.content}>
                    {children}
                </main>
            </div>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {isMobileMenuOpen && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className={styles.mobileOverlay}
                            onClick={() => setIsMobileMenuOpen(false)}
                        />
                        <motion.div
                            initial={{ x: "-100%" }}
                            animate={{ x: 0 }}
                            exit={{ x: "-100%" }}
                            transition={{ type: "spring", damping: 30, stiffness: 300 }}
                            className={styles.mobileMenu}
                        >
                            <div className={styles.mobileMenuHeader}>
                                <div className={styles.logoContainer}>
                                    <div className="relative w-[120px] h-[40px]">
                                        <Image
                                            src="/BIH-Logo-147x48-1.png"
                                            alt="BIH Logo"
                                            fill
                                            style={{ objectFit: 'contain' }}
                                        />
                                    </div>
                                    <div className="ml-2">
                                        <span className="text-[10px] font-bold text-teal-600 uppercase tracking-widest">Operation</span>
                                    </div>
                                </div>
                                <button onClick={() => setIsMobileMenuOpen(false)}>
                                    <X size={24} />
                                </button>
                            </div>
                            <nav className={styles.mobileNav}>
                                {navItems.map((item) => {
                                    const Icon = item.icon;
                                    return (
                                        <Link
                                            key={item.href}
                                            href={item.href}
                                            className={`${styles.navItem} ${isActive(item.href) ? styles.active : ""}`}
                                            onClick={() => setIsMobileMenuOpen(false)}
                                        >
                                            <Icon size={20} />
                                            <span>{item.label}</span>
                                        </Link>
                                    );
                                })}
                            </nav>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>
            <AIChatWidget />
            <BottomNav />
        </div>
    );
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string };
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const requests = await prisma.cleaningRequest.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(requests);
    } catch (error) {
        console.error("Fetch Cleaning Requests Error:", error);
        return NextResponse.json({ error: "Failed to fetch requests" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        const { location, taskType, description } = body;

        if (!location || !taskType) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newRequest = await prisma.cleaningRequest.create({
            data: {
                location,
                taskType,
                description: description || '',
                status: 'PENDING',
                // Tracking: Lưu thông tin người gửi yêu cầu
                requestedById: user.id,
                requestedBy: user.fullName
            }
        });

        // Notify Environment Leaders
        try {
            const leaders = await prisma.user.findMany({
                where: { role: 'ENVIRONMENT', position: { in: ['LEADER', 'MANAGER'] } },
                select: { id: true }
            });

            const { createNotification } = await import("@/lib/notification");

            const taskLabels: Record<string, string> = {
                "CLEANING": "Vệ sinh",
                "WASTE": "Thu gom rác",
                "LANDSCAPE": "Cây xanh",
                "PEST_CONTROL": "Diệt côn trùng",
                "REPAIR": "Sửa chữa nhỏ",
                "OTHER": "Khác"
            };

            await Promise.all(leaders.map(leader =>
                createNotification(
                    leader.id,
                    "Yêu cầu Môi trường mới",
                    `${user.fullName} gửi yêu cầu ${taskLabels[taskType] || taskType} tại ${location}`,
                    "ENVIRONMENT",
                    newRequest.id,
                    "WARNING"
                )
            ));
        } catch (notifError) {
            console.error("Failed to send notifications", notifError);
        }

        return NextResponse.json(newRequest, { status: 201 });
    } catch (error) {
        console.error("Create Cleaning Request Error:", error);
        return NextResponse.json({ error: "Failed to create request" }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        const { id, status, assignedToId, rejectReason } = body;

        if (!id) {
            return NextResponse.json({ error: "Missing ID" }, { status: 400 });
        }

        const updateData: Record<string, unknown> = {};
        if (status) updateData.status = status;
        if (assignedToId !== undefined) updateData.assignedToId = assignedToId ? parseInt(assignedToId) : null;

        const updated = await prisma.cleaningRequest.update({
            where: { id: parseInt(id) },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        // Nếu REJECTED, tạo TicketFeedback
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'ENVIRONMENT',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Ghi nhận timeline khi thay đổi trạng thái
        if (status && status !== 'PENDING') {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'ENVIRONMENT',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái đã thay đổi thành: ${status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Update Cleaning Request Error:", error);
        return NextResponse.json({ error: "Failed to update request" }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');

        if (!id) {
            return NextResponse.json({ error: "Missing ID" }, { status: 400 });
        }

        await prisma.cleaningRequest.delete({
            where: { id: parseInt(id) }
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Delete Cleaning Request Error:", error);
        return NextResponse.json({ error: "Failed to delete request" }, { status: 500 });
    }
}


const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    try {
        console.log("Checking NursingRequest count...");
        const nrCount = await prisma.nursingRequest.count();
        console.log("NursingRequest Count:", nrCount);

        console.log("Checking PatientTransport count...");
        const ptCount = await prisma.patientTransport.count();
        console.log("PatientTransport Count:", ptCount);

        console.log("Seeding PatientTransport...");
        // Ensure to match the schema.prisma fields exactly!
        // priority is String, transportMode is String
        const newPt = await prisma.patientTransport.create({
            data: {
                patientName: "TEST_SEED_PATIENT",
                fromLocation: "TEST_SEED_LOC",
                toLocation: "TEST_SEED_DEST",
                transportMode: "WHEELCHAIR",
                priority: "NORMAL",
                status: "PENDING",
                requestedBy: "SEED_SCRIPT",
                notes: "Created by diagnose script"
            }
        });
        console.log("Seeded successfully:", JSON.stringify(newPt, null, 2));
    } catch (e) {
        console.error("Error creating seed data:", e);
    } finally {
        await prisma.$disconnect();
    }
}
main();

import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can approve plans (Supply Leader or Admin)
function canApprovePlan(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SUPPLY' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) return true;
    return false;
}

// GET: Lấy chi tiết một phiếu
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const plan = await prisma.procurementPlan.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                items: true,
                createdBy: { select: { id: true, fullName: true } }
            }
        });

        if (!plan) {
            return NextResponse.json({ error: "Plan not found" }, { status: 404 });
        }

        return NextResponse.json(plan);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch plan' }, { status: 500 });
    }
}

// PATCH: Approve / Reject
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { status, reason } = body; // 'APPROVED' | 'REJECTED'

        if (!status) {
            return NextResponse.json({ error: 'Missing status' }, { status: 400 });
        }

        // Only leaders can approve/reject
        if (['APPROVED', 'REJECTED'].includes(status)) {
            if (!canApprovePlan(user)) {
                return NextResponse.json({
                    error: "Permission denied: Only Supply Leader or Admin can approve plans"
                }, { status: 403 });
            }
        }

        // Build update data
        const updateData: any = { status };

        // Handle Rejection
        if (status === 'REJECTED') {
            updateData.rejectionReason = reason || "Không có lý do";
        }

        // Auto generate code when APPROVED
        if (status === 'APPROVED') {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const prefix = `DT-${year}${month}-`;

            // Fix: Check existing code to ensure uniqueness logic is robust
            // ... (keep existing code generation logic)

            // Find the last code with this prefix to auto-increment
            const lastPlan = await prisma.procurementPlan.findFirst({
                where: {
                    code: { startsWith: prefix }
                },
                orderBy: { code: 'desc' }
            });

            let nextNumber = 1;
            if (lastPlan && lastPlan.code) {
                const lastNumberStr = lastPlan.code.replace(prefix, '');
                const lastNumber = parseInt(lastNumberStr, 10);
                if (!isNaN(lastNumber)) {
                    nextNumber = lastNumber + 1;
                }
            }

            updateData.code = `${prefix}${String(nextNumber).padStart(3, '0')}`;
            updateData.approvedById = Number(user.id); // Validated type casting
            updateData.approvedAt = now;
        }

        // Handle Full Edit (only if PENDING)
        // If the body contains title/items, we assume it's an edit request
        if (body.title && body.items && status === 'PENDING') {
            updateData.title = body.title;
            updateData.description = body.description;
            updateData.supplierBank = body.supplierBank; // Plan level fallback

            // For items, easiest is to delete all and recreate
            // Transaction? update includes delete/create
            // We use nested writes
        }

        const updateOperation = {
            ...updateData,
            items: body.items ? {
                deleteMany: {},
                create: body.items.map((item: any) => ({
                    itemName: item.itemName,
                    category: item.category || 'OFFICE',
                    quantity: parseInt(item.quantity) || 1,
                    unit: item.unit || 'PCS',
                    supplier: item.supplier || '',
                    unitPrice: parseFloat(item.unitPrice || 0),
                    vat: parseFloat(item.vat || 0),
                    bankAccount: item.bankAccount || '',
                    note: item.note
                }))
            } : undefined
        };
        // Remove undefined keys
        // Prisma handles undefined relations gracefully? 
        // No, if items is undefined we shouldn't pass it.

        const finalData = { ...updateData };
        if (body.items && body.items.length > 0) {
            finalData.items = {
                deleteMany: {},
                create: body.items.map((item: any) => ({
                    itemName: item.itemName,
                    category: item.category || 'OFFICE',
                    quantity: parseInt(item.quantity) || 1,
                    unit: item.unit || 'PCS',
                    supplier: item.supplier || '',
                    unitPrice: parseFloat(item.unitPrice || 0),
                    vat: parseFloat(item.vat || 0),
                    bankAccount: item.bankAccount || '',
                    note: item.note
                }))
            };
        }

        if (body.title) finalData.title = body.title;
        if (body.description) finalData.description = body.description;
        if (body.supplierBank) finalData.supplierBank = body.supplierBank;


        const updatedPlan = await prisma.procurementPlan.update({
            where: { id },
            data: finalData,
            include: {
                items: true,
                createdBy: { select: { id: true, fullName: true } }
            }
        });

        return NextResponse.json(updatedPlan);
    } catch (error) {
        console.error("Approve Plan Error:", error);
        return NextResponse.json({ error: 'Failed to update plan' }, { status: 500 });
    }
}

// DELETE: Xóa phiếu nháp (Only creator or leader can delete)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);

        // Check if user is the creator or a leader
        const plan = await prisma.procurementPlan.findUnique({ where: { id } });
        if (!plan) {
            return NextResponse.json({ error: "Plan not found" }, { status: 404 });
        }

        const isCreator = plan.createdById === user.id;
        const isLeader = canApprovePlan(user);

        if (!isCreator && !isLeader) {
            return NextResponse.json({
                error: "Permission denied: Only the creator or Supply Leader can delete plans"
            }, { status: 403 });
        }

        // Can only delete PENDING plans
        if (plan.status !== 'PENDING') {
            return NextResponse.json({
                error: "Cannot delete: Plan is already approved or rejected"
            }, { status: 400 });
        }

        await prisma.procurementPlan.delete({ where: { id } });
        return NextResponse.json({ message: 'Deleted' });
    } catch (error) {
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

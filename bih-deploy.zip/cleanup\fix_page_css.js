
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // Regex to capture the THEAD block for PLANS table
    // It is distinguished by headers: "Mã phiếu", "Nội dung", "Tổng tiền"
    const theadRegex = /<thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">\s*<tr>\s*<th className="p-4">Mã phiếu<\/th>[\s\S]*?<\/thead>/;

    const newThead = `<thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                                <tr>
                                    <th className="p-4 whitespace-nowrap w-[150px]">Mã phiếu</th>
                                    <th className="p-4 whitespace-nowrap min-w-[300px]">Nội dung</th>
                                    <th className="p-4 whitespace-nowrap w-[120px]">Ngày tạo</th>
                                    <th className="p-4 whitespace-nowrap w-[180px]">Người lập</th>
                                    <th className="p-4 text-right whitespace-nowrap w-[150px]">Tổng tiền</th>
                                    <th className="p-4 text-center whitespace-nowrap w-[120px]">Trạng thái</th>
                                    <th className="p-4 text-center whitespace-nowrap w-[100px]">Thao tác</th>
                                </tr>
                            </thead>`;

    // 1. Replace THEAD
    if (theadRegex.test(content)) {
        content = content.replace(theadRegex, newThead);
        console.log("THEAD updated.");
    } else {
        console.log("THEAD regex not matched.");
    }

    // 2. Replace TBODY row cells
    // Harder to regex fully safely, but we can target specific unique row patterns
    // <td className="p-4 font-bold text-slate-700">{plan.code || <span className="text-slate-400 italic">Chờ duyệt</span>}</td>
    const cellCodeRegex = /<td className="p-4 font-bold text-slate-700">\{plan.code \|\| <span className="text-slate-400 italic">Chờ duyệt<\/span>\}<\/td>/;
    const newCellCode = `<td className="p-4 font-bold text-slate-700 whitespace-nowrap">{plan.code || <span className="text-slate-400 italic">Chờ duyệt</span>}</td>`;

    // <td className="p-4 font-medium text-slate-800 max-w-xs truncate" title={plan.title}>{plan.title}</td>
    const cellTitleRegex = /<td className="p-4 font-medium text-slate-800 max-w-xs truncate" title={plan.title}>\{plan.title\}<\/td>/;
    const newCellTitle = `<td className="p-4 font-medium text-slate-800 whitespace-nowrap" title={plan.title}>{plan.title}</td>`;

    // <td className="p-4 text-slate-500">{new Date(plan.createdAt).toLocaleDateString('vi-VN')}</td>
    const cellDateRegex = /<td className="p-4 text-slate-500">\{new Date\(plan.createdAt\).toLocaleDateString\('vi-VN'\)\}<\/td>/;
    const newCellDate = `<td className="p-4 text-slate-500 whitespace-nowrap">{new Date(plan.createdAt).toLocaleDateString('vi-VN')}</td>`;

    // <td className="p-4 text-slate-600">{plan.createdBy\?\.fullName \|\| 'N\/A'}<\/td>
    // Note: special chars escaping in regex
    const cellUserRegex = /<td className="p-4 text-slate-600">\{plan.createdBy\?\.fullName \|\| 'N\/A'\}<\/td>/;
    const newCellUser = `<td className="p-4 text-slate-600 whitespace-nowrap">{plan.createdBy?.fullName || 'N/A'}</td>`;

    // <td className="p-4 text-right font-bold text-slate-700">{calculatePlanTotal(plan.items).toLocaleString('en-US')}</td>
    const cellTotalRegex = /<td className="p-4 text-right font-bold text-slate-700">\{calculatePlanTotal\(plan.items\).toLocaleString\('en-US'\)\}<\/td>/;
    const newCellTotal = `<td className="p-4 text-right font-bold text-slate-700 whitespace-nowrap">{calculatePlanTotal(plan.items).toLocaleString('en-US')}</td>`;

    if (cellCodeRegex.test(content)) content = content.replace(cellCodeRegex, newCellCode);
    if (cellTitleRegex.test(content)) content = content.replace(cellTitleRegex, newCellTitle);
    if (cellDateRegex.test(content)) content = content.replace(cellDateRegex, newCellDate);
    if (cellUserRegex.test(content)) content = content.replace(cellUserRegex, newCellUser);
    if (cellTotalRegex.test(content)) content = content.replace(cellTotalRegex, newCellTotal);

    fs.writeFileSync(path, content);
    console.log("File updated with CSS fixes.");

} catch (e) {
    console.error("Error:", e);
}

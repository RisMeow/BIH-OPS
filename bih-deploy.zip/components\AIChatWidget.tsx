"use client";

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Send, X, Settings, Image as ImageIcon, Sparkles, User, AlertTriangle, Key } from 'lucide-react';
import clsx from 'clsx';

interface Message {
    role: 'user' | 'assistant';
    content: string;
    isError?: boolean;
}

export default function AIChatWidget() {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([
        { role: 'assistant', content: 'Xin chào! Tôi là BIH Assistant. Tôi có thể giúp bạn tạo yêu cầu kỹ thuật nhanh chóng.' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // Settings State
    const [showSettings, setShowSettings] = useState(false);
    const [apiKey, setApiKey] = useState('');
    const [provider, setProvider] = useState<'google' | 'openai'>('google');
    const [model, setModel] = useState('gemini-1.5-flash');

    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Load settings from localStorage
    useEffect(() => {
        const savedKey = localStorage.getItem('bih_ai_key');
        const savedProvider = localStorage.getItem('bih_ai_provider');
        const savedModel = localStorage.getItem('bih_ai_model');

        if (savedKey) {
            setApiKey(savedKey);
        } else {
            setShowSettings(true); // Auto show settings if no key
        }
        if (savedProvider) setProvider(savedProvider as any);
        if (savedModel) setModel(savedModel);
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        if (isOpen) scrollToBottom();
    }, [messages, isOpen]);

    const handleSaveSettings = () => {
        localStorage.setItem('bih_ai_key', apiKey);
        localStorage.setItem('bih_ai_provider', provider);
        localStorage.setItem('bih_ai_model', model);
        setShowSettings(false);
        // Add a system message confirming settings saved
        setMessages(prev => [...prev, { role: 'assistant', content: 'Đã lưu cấu hình! Bạn có thể bắt đầu chat ngay bây giờ.' }]);
    };

    const handleSend = async () => {
        if (!input.trim()) return;
        if (!apiKey) {
            setShowSettings(true);
            return;
        }

        const userMsg = input;
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
        setIsLoading(true);

        try {
            const res = await fetch('/api/ai/agent', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    messages: [...messages, { role: 'user', content: userMsg }], // Send history + new msg
                    apiKey,
                    provider,
                    model
                })
            });

            const data = await res.json();

            if (!res.ok) {
                if (data.isQuotaError) {
                    throw new Error("Hết hạn ngạch (Quota) hoặc API Key không hợp lệ. Vui lòng kiểm tra lại key của bạn.");
                }
                throw new Error(data.error || "Lỗi kết nối");
            }

            setMessages(prev => [...prev, { role: 'assistant', content: data.content }]);

        } catch (error: any) {
            setMessages(prev => [...prev, {
                role: 'assistant',
                content: `⚠️ Lỗi: ${error.message}`,
                isError: true
            }]);
            if (error.message.includes("Quota") || error.message.includes("Key")) {
                setShowSettings(true);
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.95 }}
                        className="bg-white/90 backdrop-blur-md border border-white/20 shadow-2xl rounded-2xl w-[380px] h-[600px] flex flex-col overflow-hidden mb-4"
                    >
                        {/* Header */}
                        <div className="p-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex justify-between items-center shrink-0">
                            <div className="flex items-center gap-2">
                                <Sparkles size={20} className="text-yellow-300" />
                                <h3 className="font-bold">BIH Assistant</h3>
                            </div>
                            <div className="flex items-center gap-2">
                                <button onClick={() => setShowSettings(!showSettings)} className="p-1.5 hover:bg-white/20 rounded-lg transition-colors" title="Settings">
                                    <Settings size={18} />
                                </button>
                                <button onClick={() => setIsOpen(false)} className="p-1.5 hover:bg-white/20 rounded-lg transition-colors">
                                    <X size={18} />
                                </button>
                            </div>
                        </div>

                        {/* Content Area */}
                        <div className="flex-1 relative overflow-hidden flex flex-col">

                            {/* Settings Overlay */}
                            <AnimatePresence>
                                {showSettings && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -20 }}
                                        className="absolute inset-x-0 top-0 bg-slate-50 border-b p-4 z-10 shadow-md space-y-4"
                                    >
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">Provider</label>
                                            <div className="flex bg-slate-200 rounded-lg p-1">
                                                <button
                                                    onClick={() => {
                                                        setProvider('google');
                                                        setModel('gemini-1.5-flash');
                                                    }}
                                                    className={clsx("flex-1 py-1.5 text-xs font-medium rounded-md transition-all", provider === 'google' ? "bg-white shadow text-blue-600" : "text-slate-500 hover:text-slate-700")}
                                                >
                                                    Google Gemini
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        setProvider('openai');
                                                        setModel('gpt-3.5-turbo');
                                                    }}
                                                    className={clsx("flex-1 py-1.5 text-xs font-medium rounded-md transition-all", provider === 'openai' ? "bg-white shadow text-green-600" : "text-slate-500 hover:text-slate-700")}
                                                >
                                                    OpenAI GPT
                                                </button>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">Model</label>
                                            <select
                                                value={model}
                                                onChange={(e) => setModel(e.target.value)}
                                                className="w-full bg-slate-100 border-none rounded-lg px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                            >
                                                {provider === 'google' ? (
                                                    <>
                                                        <option value="gemini-1.5-flash">Gemini 1.5 Flash (Recommended)</option>
                                                        <option value="gemini-1.5-pro">Gemini 1.5 Pro (Powerful)</option>
                                                        <option value="gemini-pro">Gemini Pro (Legacy)</option>
                                                        <option value="gemini-1.0-pro">Gemini 1.0 Pro</option>
                                                    </>
                                                ) : (
                                                    <>
                                                        <option value="gpt-3.5-turbo">GPT-3.5 Turbo (Fast)</option>
                                                        <option value="gpt-4-turbo">GPT-4 Turbo (Smart)</option>
                                                        <option value="gpt-4o">GPT-4o (Best)</option>
                                                        <option value="gpt-4o-mini">GPT-4o Mini (Efficient)</option>
                                                    </>
                                                )}
                                            </select>
                                        </div>

                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">API Key</label>
                                            <div className="relative">
                                                <Key size={14} className="absolute left-3 top-2.5 text-slate-400" />
                                                <input
                                                    type="password"
                                                    value={apiKey}
                                                    onChange={(e) => setApiKey(e.target.value)}
                                                    className="w-full bg-white border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                                    placeholder={provider === 'google' ? "AIzaSy..." : "sk-..."} // Placeholder hint
                                                />
                                            </div>
                                            <p className="text-[10px] text-slate-400 mt-1">
                                                Key được lưu trên trình duyệt của bạn.{' '}
                                                <a href={provider === 'google' ? "https://aistudio.google.com/app/apikey" : "https://platform.openai.com/api-keys"} target="_blank" className="underline hover:text-blue-500">
                                                    Lấy key ở đây
                                                </a>
                                            </p>
                                        </div>

                                        <button
                                            onClick={handleSaveSettings}
                                            className="w-full py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors"
                                        >
                                            Lưu cấu hình
                                        </button>
                                    </motion.div>
                                )}
                            </AnimatePresence>

                            {/* Chat Messages */}
                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                                {messages.map((msg, idx) => (
                                    <div key={idx} className={clsx("flex gap-3", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
                                        <div className={clsx("w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm", msg.role === 'user' ? "bg-slate-200" : "bg-gradient-to-br from-blue-500 to-indigo-600 text-white")}>
                                            {msg.role === 'user' ? <User size={16} className="text-slate-600" /> : <Bot size={16} />}
                                        </div>
                                        <div className={clsx("max-w-[80%] rounded-2xl p-3 text-sm shadow-sm",
                                            msg.role === 'user' ? "bg-slate-100 text-slate-800 rounded-tr-sm" :
                                                msg.isError ? "bg-red-50 text-red-600 border border-red-100 rounded-tl-sm" :
                                                    "bg-blue-50/50 text-slate-800 border border-blue-100 rounded-tl-sm")}>
                                            <p className="whitespace-pre-wrap">{msg.content}</p>
                                        </div>
                                    </div>
                                ))}
                                {isLoading && (
                                    <div className="flex gap-3">
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shrink-0">
                                            <Bot size={16} className="text-white" />
                                        </div>
                                        <div className="bg-slate-50 rounded-2xl p-3 rounded-tl-sm border border-slate-100 flex items-center gap-1">
                                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                                        </div>
                                    </div>
                                )}
                                <div ref={messagesEndRef} />
                            </div>

                            {/* Input Area */}
                            <div className="p-3 bg-white border-t border-slate-100">
                                <form
                                    onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                                    className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-full px-2 py-1.5 focus-within:ring-2 focus-within:ring-blue-500/20 focus-within:border-blue-300 transition-all"
                                >
                                    <input
                                        className="flex-1 bg-transparent px-3 py-1.5 text-sm focus:outline-none placeholder:text-slate-400"
                                        placeholder="Nhập yêu cầu..."
                                        value={input}
                                        onChange={e => setInput(e.target.value)}
                                        disabled={isLoading}
                                    />
                                    <button
                                        type="submit"
                                        disabled={!input.trim() || isLoading}
                                        className={clsx("p-2 rounded-full transition-all",
                                            input.trim() && !isLoading ? "bg-blue-600 text-white shadow-md hover:bg-blue-700" : "bg-slate-200 text-slate-400 cursor-not-allowed")}
                                    >
                                        <Send size={16} />
                                    </button>
                                </form>
                                <p className="text-[10px] text-center text-slate-400 mt-2">
                                    BIH AI có thể mắc lỗi. Hãy kiểm tra lại thông tin quan trọng.
                                </p>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* FAB Button */}
            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsOpen(!isOpen)}
                className="w-14 h-14 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full shadow-lg shadow-blue-600/30 flex items-center justify-center text-white relative z-50 hover:shadow-xl transition-shadow"
            >
                {isOpen ? <X size={24} /> : <Bot size={28} />}

                {/* Ping animation if closed */}
                {!isOpen && (
                    <span className="absolute top-0 right-0 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500 border-2 border-white"></span>
                    </span>
                )}
            </motion.button>
        </div>
    );
}

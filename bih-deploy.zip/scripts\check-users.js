const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    const users = await prisma.user.findMany({
        select: {
            id: true,
            username: true,
            role: true,
            position: true,
            password: true
        }
    });

    console.log('Users in database:');
    users.forEach(u => {
        console.log(`- ${u.id}: ${u.username} (${u.role}/${u.position}) - password hash: ${u.password.substring(0, 20)}...`);
    });

    // Test password verification
    const bcrypt = require('bcryptjs');
    const admin = users.find(u => u.username === 'admin');
    if (admin) {
        const isValid = await bcrypt.compare('123456', admin.password);
        console.log(`\nPassword test for admin: ${isValid ? 'VALID ✓' : 'INVALID ✗'}`);
    }
}

main()
    .then(() => prisma.$disconnect())
    .catch(e => { console.error(e); prisma.$disconnect(); });

"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import { dictionary, Locale } from '@/lib/dictionary';

interface LanguageContextType {
    locale: Locale;
    t: typeof dictionary['vi'];
    switchLanguage: (lang: Locale) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
    const [locale, setLocale] = useState<Locale>('vi');

    // Load saved language from localStorage and listen for changes
    useEffect(() => {
        const saved = localStorage.getItem('app-locale') as Locale;
        if (saved && (saved === 'vi' || saved === 'en')) {
            setLocale(saved);
        }

        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === 'app-locale' && e.newValue) {
                setLocale(e.newValue as Locale);
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }, []);

    const switchLanguage = (lang: Locale) => {
        setLocale(lang);
        localStorage.setItem('app-locale', lang);
        // Dispatch a custom event for same-tab updates if needed (though context handles this)
    };

    const value = {
        locale,
        t: dictionary[locale],
        switchLanguage
    };

    return (
        <LanguageContext.Provider value={value}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLanguage() {
    const context = useContext(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}

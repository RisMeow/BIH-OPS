"use client";

import { useState, useEffect } from "react";

interface DateInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function DateInput({ value, onChange, className, required, placeholder, ...props }: DateInputProps) {
    const [inputType, setInputType] = useState('text');

    const formatDate = (dateStr: string) => {
        if (!dateStr) return '';
        const [year, month, day] = dateStr.split('-');
        if (!year || !month || !day) return dateStr;
        return `${day}/${month}/${year}`;
    };

    return (
        <input
            {...props}
            type={inputType}
            lang="en-GB" // Force browser to use DD/MM/YYYY format
            required={required}
            className={className}
            placeholder={placeholder || "dd/mm/yyyy"}
            value={inputType === 'text' ? formatDate(value as string) : value}
            onFocus={() => setInputType('date')}
            onBlur={() => setInputType('text')}
            onChange={onChange}
        />
    );
}

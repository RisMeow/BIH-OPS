const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    const passwordHash = await bcrypt.hash('123456', 10); // Mật khẩu chung: 123456

    const users = [
        { username: 'admin', fullName: 'Quản trị viên', role: 'ADMIN' },
        { username: 'technical', fullName: 'Trưởng phòng Kỹ thuật', role: 'TECHNICAL' },
        { username: 'nursing', fullName: 'Điều dưỡng trưởng', role: 'NURSING' },
        { username: 'driver', fullName: 'Đội trưởng Đội xe', role: 'DRIVER' },
        { username: 'security', fullName: 'Đội trưởng An ninh', role: 'SECURITY' },
        { username: 'supply', fullName: 'Nhân viên Cung ứng', role: 'SUPPLY' },
        { username: 'environment', fullName: 'Giám sát Vệ sinh', role: 'ENVIRONMENT' },
    ];

    console.log('Start seeding users...');

    for (const u of users) {
        const user = await prisma.user.upsert({
            where: { username: u.username },
            update: {
                password: passwordHash, // Cập nhật lại pass nếu đã tồn tại
                role: u.role
            },
            create: {
                username: u.username,
                password: passwordHash,
                fullName: u.fullName,
                role: u.role,
            },
        });
        console.log(`Created user: ${user.username} (${user.role})`);
    }

    console.log('Seeding finished.');
}

main()
    .then(async () => {
        await prisma.$disconnect();
    })
    .catch(async (e) => {
        console.error(e);
        await prisma.$disconnect();
        process.exit(1);
    });

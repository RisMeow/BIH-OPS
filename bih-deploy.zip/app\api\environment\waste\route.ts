import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(req: Request) {
    try {
        const logs = await prisma.wasteCollectionLog.findMany({
            include: { handler: { select: { fullName: true } } },
            orderBy: { collectedAt: 'desc' }
        });
        return NextResponse.json(logs);
    } catch (error) {
        console.error("Error fetching waste logs:", error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}

export async function POST(req: Request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json();
        const { wasteType, weight, location, notes } = body;

        const log = await prisma.wasteCollectionLog.create({
            data: {
                wasteType,
                weight: parseFloat(weight),
                location,
                notes,
                handlerId: parseInt(String(session.user.id))
            }
        });
        return NextResponse.json(log);
    } catch (error) {
        console.error("Error creating waste log:", error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}

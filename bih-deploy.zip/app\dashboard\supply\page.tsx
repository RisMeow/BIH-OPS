"use client";

import { useState, useEffect } from "react";
import {
    ShoppingCart, Plus,
    PenTool, Box, FileText, CheckCircle2, Edit,
    Printer, Trash2, Download, Search, XCircle, TrendingUp, AlertCircle, Clock, List, LayoutGrid, RefreshCw
} from "lucide-react";
import { useSession } from "next-auth/react";
import { useLanguage } from "@/app/context/LanguageContext";
import clsx from "clsx";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import Toast, { ToastType } from "@/app/components/Toast";
import ConfirmModal from "@/app/components/ConfirmModal";


// Types
interface Request {
    id: number;
    itemName: string;
    category: string;
    quantity: number;
    unit: string;
    urgency: string;
    status: string;
    requester: string;
    priority?: string;
    inventoryId?: number;
    inventory?: InventoryItem;
}

// ... (Other interfaces)

// ...


interface ProcurementItem {
    id?: number;
    itemName: string;
    category: string;
    quantity: number;
    unit: string;
    supplier?: string;
    unitPrice?: number;
    vat?: number;
    bankAccount?: string;
    note?: string;
}

interface ProcurementPlan {
    id: number;
    code: string;
    title: string;
    description: string;
    supplierBank?: string;
    status: string;
    createdAt: string;
    createdBy?: { fullName: string };
    approvedById?: number;
    approvedAt?: string;
    rejectionReason?: string;
    items: ProcurementItem[];
}

interface InventoryItem {
    id: number;
    sku: string;
    name: string;
    category: string;
    unit: string;
    quantity: number;
    minLevel: number;
    location?: string;
    description?: string;
}

export default function SupplyDashboard() {
    const { t } = useLanguage();
    const { data: session } = useSession();
    const [activeTab, setActiveTab] = useState<'REQUESTS' | 'PLANS' | 'INVENTORY' | 'HISTORY'>('PLANS');

    const isManager = session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER');

    // Bulk Selection State
    const [selectedReqIds, setSelectedReqIds] = useState<number[]>([]);

    const toggleSelectAll = () => {
        if (selectedReqIds.length === reqs.length) {
            setSelectedReqIds([]);
        } else {
            setSelectedReqIds(reqs.map(r => r.id));
        }
    };

    const toggleSelectRow = (id: number) => {
        if (selectedReqIds.includes(id)) {
            setSelectedReqIds(selectedReqIds.filter(i => i !== id));
        } else {
            setSelectedReqIds([...selectedReqIds, id]);
        }
    };

    const handleBulkDelete = () => {
        openConfirm("Xóa nhiều yêu cầu", `Bạn có chắc chắn muốn xóa ${selectedReqIds.length} yêu cầu đã chọn?`, async () => {
            try {
                const res = await fetch(`/api/supply/requests`, {
                    method: 'DELETE',
                    body: JSON.stringify({ ids: selectedReqIds }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    fetchRequests();
                    setSelectedReqIds([]);
                    showToast(`Đã xóa ${selectedReqIds.length} yêu cầu!`, 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    // UI Feedback
    const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
        message: '', type: 'info', isVisible: false
    });
    const showToast = (message: string, type: ToastType = 'success') => {
        setToast({ message, type, isVisible: true });
    };

    const [confirmConfig, setConfirmConfig] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
        variant: 'danger' | 'info';
    }>({ isOpen: false, title: '', message: '', onConfirm: () => { }, variant: 'info' });

    const openConfirm = (title: string, message: string, onConfirm: () => void, variant: 'danger' | 'info' = 'danger') => {
        setConfirmConfig({ isOpen: true, title, message, onConfirm, variant });
    };

    const [plans, setPlans] = useState<ProcurementPlan[]>([]);
    const [reqs, setReqs] = useState<Request[]>([]);
    const [inventory, setInventory] = useState<InventoryItem[]>([]);
    const [tickets, setTickets] = useState<any[]>([]); // Maintenance Tickets for linking
    const [history, setHistory] = useState<any[]>([]);

    // Stats
    const [stats, setStats] = useState({
        pendingPlans: 0,
        approvedPlans: 0,
        totalBudget: 0,
        lowStockItems: 0
    });

    // Modals
    const [isCreatePlanModalOpen, setIsCreatePlanModalOpen] = useState(false);
    const [editingPlanId, setEditingPlanId] = useState<number | null>(null);
    const [selectedPlan, setSelectedPlan] = useState<ProcurementPlan | null>(null);
    const [isCreateReqModalOpen, setIsCreateReqModalOpen] = useState(false);
    const [isCreateItemModalOpen, setIsCreateItemModalOpen] = useState(false);
    const [isEditingItem, setIsEditingItem] = useState(false);
    const [itemToEditId, setItemToEditId] = useState<number | null>(null);

    // Reject Modal
    const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
    const [planToRejectId, setPlanToRejectId] = useState<number | null>(null);
    const [rejectReason, setRejectReason] = useState("");

    // Forms
    const [planFormData, setPlanFormData] = useState({ title: "", description: "", supplierBank: "" });
    const [planItems, setPlanItems] = useState<ProcurementItem[]>([
        { itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }
    ]);
    const [reqFormData, setReqFormData] = useState({ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", urgency: "NORMAL", requester: "Admin" });
    const [newItemData, setNewItemData] = useState({ sku: "", name: "", category: "GENERAL", unit: "PCS", minLevel: 5, quantity: 0, location: "" });

    useEffect(() => {
        if (activeTab === 'PLANS') fetchPlans();
        if (activeTab === 'REQUESTS') fetchRequests();
        if (activeTab === 'INVENTORY') fetchInventory();
        if (activeTab === 'HISTORY') fetchHistory();
    }, [activeTab]);

    // Initial fetch for stats
    useEffect(() => {
        fetchPlans();
        fetchInventory();
    }, []);

    const fetchPlans = async () => {
        try {
            const res = await fetch('/api/supply/plans');
            const data = await res.json();
            if (Array.isArray(data)) {
                setPlans(data);
                const pending = data.filter((p: ProcurementPlan) => p.status === 'PENDING').length;
                const approved = data.filter((p: ProcurementPlan) => p.status === 'APPROVED').length;
                const budget = data.reduce((acc: number, p: ProcurementPlan) => acc + calculatePlanTotal(p.items), 0);
                setStats(prev => ({ ...prev, pendingPlans: pending, approvedPlans: approved, totalBudget: budget }));
            }
        } catch (error) { console.error("Failed to fetch plans", error); }
    };

    const fetchRequests = async () => {
        try {
            const res = await fetch('/api/supply/requests');
            const data = await res.json();
            if (Array.isArray(data)) setReqs(data);
        } catch (error) { console.error("Failed to fetch requests", error); }
    };

    const fetchInventory = async () => {
        try {
            const res = await fetch('/api/supply/inventory');
            const data = await res.json();
            if (Array.isArray(data)) {
                setInventory(data);
                const lowStock = data.filter((i: InventoryItem) => i.quantity <= i.minLevel).length;
                setStats(prev => ({ ...prev, lowStockItems: lowStock }));
            }
        } catch (error) { console.error("Failed to fetch inventory", error); }
    };

    const fetchTickets = async () => {
        try {
            const res = await fetch('/api/technical/requests');
            const data = await res.json();
            if (Array.isArray(data)) {
                // Filter active tickets only
                setTickets(data.filter((t: any) => t.status !== 'COMPLETED' && t.status !== 'CANCELLED'));
            }
        } catch (error) { console.error("Failed to fetch tickets", error); }
    };

    const fetchHistory = async () => {
        try {
            const res = await fetch('/api/supply/transactions');
            const data = await res.json();
            if (Array.isArray(data)) setHistory(data);
        } catch (error) { console.error("Failed to fetch history", error); }
    };

    const handleCreateItem = async () => {
        try {
            const res = await fetch('/api/supply/inventory', {
                method: 'POST',
                body: JSON.stringify(newItemData),
                headers: { 'Content-Type': 'application/json' }
            });
            const data = await res.json();

            if (res.ok) {
                fetchInventory();
                setIsCreateItemModalOpen(false);
                setNewItemData({ sku: "", name: "", category: "GENERAL", unit: "PCS", minLevel: 5, quantity: 0, location: "" });
                showToast("Thêm vật tư thành công!", 'success');
            } else {
                showToast(data.error || "Lỗi khi thêm vật tư", 'error');
            }
        } catch (e) {
            console.error(e);
            showToast("Lỗi kết nối server", 'error');
        }
    };

    const handleEditItemKey = (item: InventoryItem) => {
        setIsEditingItem(true);
        setItemToEditId(item.id);
        setNewItemData({
            sku: item.sku,
            name: item.name,
            category: item.category,
            unit: item.unit,
            minLevel: item.minLevel,
            quantity: item.quantity,
            location: item.location || ""
        });
        setIsCreateItemModalOpen(true);
    };

    const handleUpdateItem = async () => {
        if (!itemToEditId) return;
        try {
            const res = await fetch(`/api/supply/inventory/${itemToEditId}`, {
                method: 'PATCH',
                body: JSON.stringify(newItemData),
                headers: { 'Content-Type': 'application/json' }
            });
            const data = await res.json();

            if (res.ok) {
                fetchInventory();
                setIsCreateItemModalOpen(false);
                setNewItemData({ sku: "", name: "", category: "GENERAL", unit: "PCS", minLevel: 5, quantity: 0, location: "" });
                setIsEditingItem(false);
                setItemToEditId(null);
                showToast("Cập nhật vật tư thành công!", 'success');
            } else {
                showToast(data.error || "Lỗi khi cập nhật", 'error');
            }
        } catch (e) {
            console.error(e);
            showToast("Lỗi kết nối server", 'error');
        }
    };

    const generateSKU = (name: string, category: string) => {
        if (!name) return "";

        // 1. Get Prefix
        const prefixMap: Record<string, string> = {
            'ELECTRICAL': 'DIEN',
            'PLUMBING': 'NUOC',
            'OFFICE': 'VPP',
            'MEDICAL': 'YTE',
            'CHEMICAL': 'HOA',
            'IT': 'IT',
            'FURNITURE': 'NT',
            'GENERAL': 'CHUNG',
            'OTHER': 'KHAC'
        };
        const prefix = prefixMap[category] || 'KHO';

        // 2. Get Name Acronym
        const removeAccents = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D");
        const cleanName = removeAccents(name).toUpperCase().replace(/[^A-Z0-9\s]/g, "");
        const words = cleanName.split(/\s+/).filter(w => w.length > 0);

        let acronym = "";
        if (words.length >= 1) acronym += words[0][0];
        if (words.length >= 2) acronym += words[1][0];
        if (words.length >= 3) acronym += words[2][0];
        if (!acronym) acronym = "ITEM";

        // 3. Random Number
        const random = Math.floor(100 + Math.random() * 900);

        return `${prefix}-${acronym}-${random}`;
    };

    const handleDeleteItem = (id: number) => {
        openConfirm("Xóa vật tư", "Bạn có chắc chắn muốn XÓA vật tư này? Hành động này không thể hoàn tác.", async () => {
            try {
                const res = await fetch(`/api/supply/inventory/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchInventory();
                    showToast("Đã xóa vật tư!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    // Transaction Logic
    const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
    const [selectedInventoryItem, setSelectedInventoryItem] = useState<InventoryItem | null>(null);
    const [transactionData, setTransactionData] = useState({ type: 'IMPORT', quantity: 0, reason: '', referenceId: '' });
    // State to hold dynamic locations for RETURN type if we want to fetch them.
    // For now, we will use a simple input or predefined list if available.


    const openTransactionModal = (item: InventoryItem, type: 'IMPORT' | 'EXPORT' | 'RETURN') => {
        setSelectedInventoryItem(item);
        setTransactionData({ type, quantity: 0, reason: '', referenceId: '' });
        setIsTransactionModalOpen(true);
        if (type === 'EXPORT') fetchTickets(); // Fetch tickets when exporting
        // If RETURN, we might want to fetch departments or just use text input
    };

    const handleTransactionSubmit = async () => {
        if (!selectedInventoryItem) return;
        try {
            const res = await fetch(`/api/supply/inventory/${selectedInventoryItem.id}/transaction`, {
                method: 'POST',
                body: JSON.stringify(transactionData),
                headers: { 'Content-Type': 'application/json' }
            });

            if (res.ok) {
                fetchInventory();
                setIsTransactionModalOpen(false);
                showToast("Giao dịch kho thành công!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + (data.error || "Không xác định"), 'error');
            }
        } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
    };

    const calculateItemTotal = (item: ProcurementItem) => {
        const base = (item.quantity || 0) * (item.unitPrice || 0);
        const vatAmount = base * ((item.vat || 0) / 100);
        return base + vatAmount;
    };

    const calculatePlanTotal = (items: ProcurementItem[]) => {
        return items.reduce((acc, item) => acc + calculateItemTotal(item), 0);
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    };

    const handleAddItem = () => {
        setPlanItems([...planItems, { itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]);
    };

    const handleRemoveItem = (index: number) => {
        const newItems = [...planItems];
        newItems.splice(index, 1);
        setPlanItems(newItems);
    };

    const handleItemChange = (index: number, field: string, value: any) => {
        const newItems = [...planItems];
        // @ts-ignore
        newItems[index][field] = value;
        setPlanItems(newItems);
    };

    const handlePlanSubmit = async () => {
        try {
            if (!planFormData.title.trim()) { showToast("Vui lòng nhập nội dung dự trù", 'error'); return; }
            if (!planItems.some(i => i.itemName.trim())) { showToast("Vui lòng nhập ít nhất một hạng mục có tên", 'error'); return; }

            const payload = {
                ...planFormData,
                items: planItems.filter(i => i.itemName.trim())
            };

            let res;
            if (editingPlanId) {
                // For edit, we send Payload + Items. The API PATCH handles items update if status is PENDING.
                // We ensure status is preserved or strictly validated backend.
                res = await fetch(`/api/supply/plans/${editingPlanId}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ ...payload, items: planItems, status: 'PENDING' }),
                    headers: { 'Content-Type': 'application/json' }
                });
            } else {
                res = await fetch('/api/supply/plans', { method: 'POST', body: JSON.stringify(payload), headers: { 'Content-Type': 'application/json' } });
            }

            if (res.ok) {
                setIsCreatePlanModalOpen(false); setEditingPlanId(null); setPlanFormData({ title: "", description: "", supplierBank: "" }); setPlanItems([{ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]);;
                fetchPlans();
                setPlanFormData({ title: "", description: "", supplierBank: "" });
                setPlanItems([{ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]);
                showToast("Đã lưu phiếu dự trù thành công!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi khi lưu phiếu: " + (data.error || "Không xác định"), 'error');
            }
        } catch (e) { console.error(e); showToast("Lỗi kết nối khi lưu phiếu", 'error'); }
    };

    const handleApprovePlan = (id: number) => {
        openConfirm("Duyệt phiếu", "Bạn có chắc chắn muốn DUYỆT phiếu này?", async () => {
            try {
                const res = await fetch(`/api/supply/plans/${id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: 'APPROVED' }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    fetchPlans();
                    if (selectedPlan) setSelectedPlan({ ...selectedPlan, status: 'APPROVED' });
                    showToast("Đã duyệt phiếu thành công!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    const openRejectModal = (id: number) => {
        setPlanToRejectId(id);
        setRejectReason("");
        setIsRejectModalOpen(true);
    };

    const handleRejectPlan = async () => {
        if (!planToRejectId) return;
        try {
            const res = await fetch(`/api/supply/plans/${planToRejectId}`, {
                method: 'PATCH',
                body: JSON.stringify({ status: 'REJECTED', reason: rejectReason }),
                headers: { 'Content-Type': 'application/json' }
            });
            if (res.ok) {
                fetchPlans();
                setIsRejectModalOpen(false);
                setPlanToRejectId(null);
                if (selectedPlan && selectedPlan.id === planToRejectId) setSelectedPlan(null); // Close detail if rejecting open plan
                showToast("Đã từ chối phiếu!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + data.error, 'error');
            }
        } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
    };

    const handleDeletePlan = (id: number) => {
        openConfirm("Xóa phiếu", "Bạn có chắc muốn XÓA phiếu này không? Hành động này không thể hoàn tác.", async () => {
            try {
                const res = await fetch(`/api/supply/plans/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchPlans();
                    if (selectedPlan && selectedPlan.id === id) setSelectedPlan(null);
                    showToast("Đã xóa phiếu!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    const handleReqSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        // Logic create request (omitted for brevity as user focused on Plans)
        showToast("Tính năng tạo yêu cầu đang cập nhật...", 'info');
        setIsCreateReqModalOpen(false);
    };

    // New State for Link Modal
    const [isLinkModalOpen, setIsLinkModalOpen] = useState(false);
    const [linkRequest, setLinkRequest] = useState<Request | null>(null);

    // Edit Request Modal
    const [isEditReqModalOpen, setIsEditReqModalOpen] = useState(false);
    const [editingReq, setEditingReq] = useState<Request | null>(null);
    const [editReqData, setEditReqData] = useState({ quantity: 1, unit: 'Lần' });

    const openEditReqModal = (req: Request) => {
        setEditingReq(req);
        setEditReqData({ quantity: req.quantity || 1, unit: req.unit || 'Lần' });
        setIsEditReqModalOpen(true);
    };

    const handleUpdateReq = async () => {
        if (!editingReq) return;
        try {
            const res = await fetch(`/api/supply/requests/${editingReq.id}`, {
                method: 'PATCH',
                body: JSON.stringify(editReqData),
                headers: { 'Content-Type': 'application/json' }
            });

            if (res.ok) {
                fetchRequests();
                setIsEditReqModalOpen(false);
                setEditingReq(null);
                showToast("Cập nhật yêu cầu thành công!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + data.error, 'error');
            }
        } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
    };

    const handleDeleteRequest = (id: number) => {
        openConfirm("Xóa yêu cầu", "Bạn có chắc chắn muốn XÓA yêu cầu này? Hành động này không thể hoàn tác.", async () => {
            try {
                const res = await fetch(`/api/supply/requests/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchRequests();
                    showToast("Đã xóa yêu cầu!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    // History Actions
    const handleDeleteHistory = (id: number) => {
        openConfirm("Xóa lịch sử", "Xóa bản ghi này KHÔNG hoàn trả tồn kho. Bạn có chắc chắn muốn xóa?", async () => {
            try {
                const res = await fetch(`/api/supply/transactions/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchHistory();
                    showToast("Đã xóa bản ghi!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    const [isEditHistoryModalOpen, setIsEditHistoryModalOpen] = useState(false);
    const [editingHistory, setEditingHistory] = useState<any | null>(null);
    const [editHistoryData, setEditHistoryData] = useState({ reason: "" });

    const openEditHistory = (item: any) => {
        setEditingHistory(item);
        setEditHistoryData({ reason: item.reason || "" });
        setIsEditHistoryModalOpen(true);
    };

    const handleUpdateHistory = async () => {
        if (!editingHistory) return;
        try {
            const res = await fetch(`/api/supply/transactions/${editingHistory.id}`, {
                method: 'PATCH',
                body: JSON.stringify(editHistoryData),
                headers: { 'Content-Type': 'application/json' }
            });

            if (res.ok) {
                fetchHistory();
                setIsEditHistoryModalOpen(false);
                setEditingHistory(null);
                showToast("Cập nhật lịch sử thành công!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + data.error, 'error');
            }
        } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
    };

    const handleSupplyRequest = (req: Request) => {
        // If not linked, prompt to link first (or auto-link by name?)
        // For simplicity, we'll just check if linked.
        if (!req.inventory) {
            showToast("Vui lòng liên kết vật tư kho trước khi cấp phát (Tính năng sắp ra mắt)", 'info');
            //Ideally open a modal to select inventory.
            // Since I don't have a specific "Link Inventory" modal ready, I will reuse the Edit logic or just Create Item logic? No.
            // I'll show a prompt or just enable logic to select.
            // Let's rely on manual linking for now via a new small modal or dropdown row.
            // Actually, let's implement a "Link Inventory" modal.
            setLinkRequest(req);
            setIsLinkModalOpen(true);
            return;
        }

        openConfirm("Cấp phát vật tư", `Xác nhận xuất kho ${req.quantity} ${req.unit} ${req.inventory.name} cho yêu cầu này?`, async () => {
            try {
                const res = await fetch(`/api/supply/requests/${req.id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ fulfill: true }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    showToast("Cấp phát thành công!", 'success');
                    fetchRequests();
                    fetchInventory(); // Update stock
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        });
    };

    // PDF Generation Logic
    // We need a specific ID for the element to capture
    // PDF Generation Logic (Server-side)
    const handleDownloadPDF = async () => {
        if (!selectedPlan) return;
        window.open(`/api/supply/plans/${selectedPlan.id}/pdf`, '_blank');
        showToast("Đang tải xuống PDF...", 'info');
    };


    const handleEditPlan = (plan: ProcurementPlan) => {
        setPlanFormData({
            title: plan.title,
            description: plan.description || "",
            supplierBank: plan.supplierBank || ""
        });
        // Map items including bankAccount
        const mappedItems = plan.items.map(i => ({
            ...i,
            bankAccount: i.bankAccount || ""
        }));
        setPlanItems(mappedItems);

        setEditingPlanId(plan.id);
        setIsCreatePlanModalOpen(true);
    };

    const handleAdjustPlan = (id: number) => {
        openConfirm("Điều chỉnh phiếu", "Phiếu sẽ chuyển về trạng thái CHỜ DUYỆT để bạn chỉnh sửa. Tiếp tục?", async () => {
            try {
                const res = await fetch(`/api/supply/plans/${id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: 'PENDING' }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    showToast("Đã mở khóa phiếu để chỉnh sửa!", 'success');
                    fetchPlans();

                    // Open Edit Modal with fresh data if possible, or current selected
                    if (selectedPlan && selectedPlan.id === id) {
                        handleEditPlan(selectedPlan);
                        setSelectedPlan(null);
                    } else {
                        const p = plans.find(p => p.id === id);
                        if (p) handleEditPlan(p);
                    }
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); }
        }, 'info');
    };

    return (
        <div className="space-y-6 pb-20 print:p-0 print:m-0 print:w-full print:h-full">
            <Toast
                message={toast.message}
                type={toast.type}
                isVisible={toast.isVisible}
                onClose={() => setToast({ ...toast, isVisible: false })}
            />
            <ConfirmModal
                isOpen={confirmConfig.isOpen}
                onClose={() => setConfirmConfig({ ...confirmConfig, isOpen: false })}
                onConfirm={confirmConfig.onConfirm}
                title={confirmConfig.title}
                message={confirmConfig.message}
                variant={confirmConfig.variant}
            />
            {/* --- DASHBOARD STATS --- */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 print:hidden">
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                        <Clock size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 font-medium">Phiếu chờ duyệt</p>
                        <p className="text-2xl font-bold text-slate-800">{stats.pendingPlans}</p>
                    </div>
                </div>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                        <CheckCircle2 size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 font-medium">Đã duyệt tháng này</p>
                        <p className="text-2xl font-bold text-slate-800">{stats.approvedPlans}</p>
                    </div>
                </div>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                        <TrendingUp size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 font-medium">Tổng giá trị dự trù</p>
                        <p className="text-2xl font-bold text-slate-800">{new Intl.NumberFormat('vi-VN', { notation: "compact" }).format(stats.totalBudget)}</p>
                    </div>
                </div>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                        <AlertCircle size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 font-medium">Sắp hết hàng</p>
                        <p className="text-2xl font-bold text-slate-800">{stats.lowStockItems}</p>
                    </div>
                </div>
            </div>

            {/* --- MAIN CONTENT --- */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden print:hidden">
                <div className="border-b border-slate-100 p-4 flex justify-between items-center">
                    <div className="flex gap-2">
                        <button onClick={() => setActiveTab('PLANS')} className={clsx("px-4 py-2 rounded-xl font-bold transition-all", activeTab === 'PLANS' ? "bg-emerald-100 text-emerald-700" : "text-slate-500 hover:bg-slate-50")}>
                            Dự trù mua sắm
                        </button>
                        <button onClick={() => setActiveTab('REQUESTS')} className={clsx("px-4 py-2 rounded-xl font-bold transition-all", activeTab === 'REQUESTS' ? "bg-amber-100 text-amber-700" : "text-slate-500 hover:bg-slate-50")}>
                            Yêu cầu vật tư lẻ
                        </button>
                        <button onClick={() => setActiveTab('INVENTORY')} className={clsx("px-4 py-2 rounded-xl font-bold transition-all", activeTab === 'INVENTORY' ? "bg-blue-100 text-blue-700" : "text-slate-500 hover:bg-slate-50")}>
                            Kho hàng
                        </button>
                        <button onClick={() => setActiveTab('HISTORY')} className={clsx("px-4 py-2 rounded-xl font-bold transition-all", activeTab === 'HISTORY' ? "bg-purple-100 text-purple-700" : "text-slate-500 hover:bg-slate-50")}>
                            Lịch sử
                        </button>
                    </div>
                    {/* Create Button only for Inventory */}
                    {activeTab === 'INVENTORY' && (
                        <button
                            onClick={() => setIsCreateItemModalOpen(true)}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 flex items-center gap-2"
                        >
                            <Plus size={18} /> Tạo mới
                        </button>
                    )}
                    {activeTab === 'PLANS' && (
                        <button
                            onClick={() => setIsCreatePlanModalOpen(true)}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 flex items-center gap-2"
                        >
                            <Plus size={18} /> Tạo phiếu dự trù
                        </button>
                    )}
                </div>

                {/* PLANS TABLE */}
                {activeTab === 'PLANS' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                                <tr>
                                    <th className="p-4 whitespace-nowrap w-[150px]">Mã phiếu</th>
                                    <th className="p-4 whitespace-nowrap min-w-[300px]">Nội dung</th>
                                    <th className="p-4 whitespace-nowrap w-[120px]">Ngày tạo</th>
                                    <th className="p-4 whitespace-nowrap w-[180px]">Người lập</th>
                                    <th className="p-4 text-right whitespace-nowrap w-[150px]">Tổng tiền</th>
                                    <th className="p-4 text-center whitespace-nowrap w-[120px]">Trạng thái</th>
                                    <th className="p-4 text-center whitespace-nowrap w-[100px]">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {plans.map((plan) => (
                                    <tr key={plan.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="p-4 font-bold text-slate-700 whitespace-nowrap">{plan.code || <span className="text-slate-400 italic">Chờ duyệt</span>}</td>
                                        <td className="p-4 font-medium text-slate-800 whitespace-nowrap" title={plan.title}>{plan.title}</td>
                                        <td className="p-4 text-slate-500 whitespace-nowrap">{new Date(plan.createdAt).toLocaleDateString('en-GB')}</td>
                                        <td className="p-4 text-slate-600 whitespace-nowrap">{plan.createdBy?.fullName || 'N/A'}</td>
                                        <td className="p-4 text-right font-bold text-slate-700 whitespace-nowrap">{calculatePlanTotal(plan.items).toLocaleString('en-US')}</td>
                                        <td className="p-4 text-center">
                                            <span className={clsx("px-2 py-1 rounded-full text-xs font-bold",
                                                plan.status === 'PENDING' ? "bg-amber-100 text-amber-600" :
                                                    plan.status === 'APPROVED' ? "bg-emerald-100 text-emerald-600" :
                                                        "bg-red-100 text-red-600"
                                            )}>
                                                {plan.status === 'PENDING' ? 'Chờ duyệt' : plan.status === 'APPROVED' ? 'Đã duyệt' : 'Từ chối'}
                                            </span>
                                        </td>
                                        <td className="p-4 flex items-center justify-center gap-2">
                                            <button onClick={() => setSelectedPlan(plan)} className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Xem chi tiết">
                                                <FileText size={18} />
                                            </button>
                                            {plan.status === 'PENDING' && (
                                                <button onClick={() => handleDeletePlan(plan.id)} className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Xóa">
                                                    <Trash2 size={18} />
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {plans.length === 0 && <div className="p-10 text-center text-slate-400">Chưa có phiếu dự trù nào</div>}
                    </div>
                )}

                {/* REQUESTS TABLE */}
                {activeTab === 'REQUESTS' && (
                    <div className="overflow-x-auto">
                        {isManager && selectedReqIds.length > 0 && (
                            <div className="bg-red-50 p-2 mb-2 rounded-lg flex justify-between items-center border border-red-100">
                                <span className="text-red-700 font-bold text-sm ml-2">Đã chọn {selectedReqIds.length} yêu cầu</span>
                                <button onClick={handleBulkDelete} className="px-3 py-1.5 bg-red-600 text-white text-xs font-bold rounded-lg hover:bg-red-700 shadow-sm flex items-center gap-2">
                                    <Trash2 size={14} /> Xóa tất cả
                                </button>
                            </div>
                        )}
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                                <tr>
                                    {isManager && (
                                        <th className="p-4 w-10">
                                            <input type="checkbox"
                                                className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                                checked={reqs.length > 0 && selectedReqIds.length === reqs.length}
                                                onChange={toggleSelectAll}
                                            />
                                        </th>
                                    )}
                                    <th className="p-4">Yêu cầu</th>
                                    <th className="p-4">Danh mục</th>
                                    <th className="p-4">Số lượng</th>
                                    <th className="p-4">Mức độ</th>
                                    <th className="p-4">Người gửi</th>
                                    <th className="p-4 text-center">Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {reqs.map((req) => (
                                    <tr key={req.id} className="hover:bg-slate-50">
                                        <td className="p-4">
                                            <p className="font-bold text-slate-700">{req.itemName}</p>
                                            {req.inventory && (
                                                <p className="text-xs text-emerald-600 flex items-center gap-1">
                                                    <CheckCircle2 size={10} /> Linked: {req.inventory.name} (Tồn: {req.inventory.quantity})
                                                </p>
                                            )}
                                        </td>
                                        <td className="p-4 text-slate-500">{req.category}</td>
                                        <td className="p-4 text-slate-800">{req.quantity} {req.unit}</td>
                                        <td className="p-4">
                                            <span className={clsx("px-2 py-1 rounded-full text-xs font-bold",
                                                req.urgency === 'URGENT' || req.urgency === 'HIGH' ? "bg-red-100 text-red-600" : "bg-slate-100 text-slate-600"
                                            )}>{req.urgency}</span>
                                        </td>
                                        <td className="p-4 text-slate-600">{req.requester}</td>
                                        <td className="p-4 text-center">
                                            <div className="flex justify-center gap-2 items-center">
                                                {/* Status Display */}
                                                {req.status === 'COMPLETED' && (
                                                    <span className="text-emerald-600 font-bold text-xs">Đã cấp</span>
                                                )}

                                                {/* Action Buttons */}
                                                {req.status !== 'COMPLETED' && (
                                                    <>
                                                        <button onClick={() => openEditReqModal(req)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-lg" title="Chỉnh sửa số lượng">
                                                            <Edit size={16} />
                                                        </button>
                                                        {!req.inventory ? (
                                                            <button onClick={() => handleSupplyRequest(req)} className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs rounded-lg font-bold">
                                                                Liên kết kho
                                                            </button>
                                                        ) : (
                                                            <button onClick={() => handleSupplyRequest(req)} className="px-3 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 text-xs rounded-lg font-bold flex items-center gap-1">
                                                                <Box size={12} /> Cấp phát
                                                            </button>
                                                        )}
                                                    </>
                                                )}

                                                {/* Delete Button (Always Visible for Manager) */}
                                                {isManager && (
                                                    <button onClick={() => handleDeleteRequest(req.id)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-slate-100 rounded-lg" title="Xóa yêu cầu">
                                                        <Trash2 size={16} />
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {reqs.length === 0 && <div className="p-10 text-center text-slate-400">Chưa có yêu cầu vật tư lẻ nào</div>}
                    </div>
                )}

                {/* INVENTORY TABLE */}
                {activeTab === 'INVENTORY' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                                <tr>
                                    <th className="p-4">SKU</th>
                                    <th className="p-4">Tên vật tư</th>
                                    <th className="p-4">Danh mục</th>
                                    <th className="p-4 text-right">Tồn kho</th>
                                    <th className="p-4">Vị trí</th>
                                    <th className="p-4 text-center">Trạng thái</th>
                                    <th className="p-4 text-center">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {inventory.map((item) => (
                                    <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="p-4 font-mono text-slate-500 text-xs">{item.sku}</td>
                                        <td className="p-4 font-bold text-slate-700">{item.name}</td>
                                        <td className="p-4 text-slate-500">{item.category}</td>
                                        <td className="p-4 text-right font-bold">
                                            {item.quantity} <span className="text-xs font-normal text-slate-400">{item.unit}</span>
                                        </td>
                                        <td className="p-4 text-slate-600">{item.location || '-'}</td>
                                        <td className="p-4 text-center">
                                            {item.quantity <= item.minLevel ? (
                                                <span className="px-2 py-1 bg-red-100 text-red-600 rounded-full text-xs font-bold flex items-center gap-1 justify-center">
                                                    <AlertCircle size={12} /> Low Stock
                                                </span>
                                            ) : (
                                                <span className="px-2 py-1 bg-emerald-100 text-emerald-600 rounded-full text-xs font-bold">
                                                    In Stock
                                                </span>
                                            )}
                                        </td>
                                        <td className="p-4 flex justify-center gap-2">
                                            <div className="flex gap-1 mr-2 border-r pr-2 border-slate-200">
                                                <button onClick={() => openTransactionModal(item, 'IMPORT')} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 font-bold text-xs" title="Nhập kho">Nhập</button>
                                                <button onClick={() => openTransactionModal(item, 'EXPORT')} className="p-2 bg-amber-50 text-amber-600 rounded-lg hover:bg-amber-100 font-bold text-xs" title="Xuất kho">Xuất</button>
                                                <button onClick={() => openTransactionModal(item, 'RETURN')} className="p-2 bg-purple-50 text-purple-600 rounded-lg hover:bg-purple-100 font-bold text-xs" title="Thu hồi / Hoàn trả">Thu hồi</button>
                                            </div>
                                            <button onClick={() => handleEditItemKey(item)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-lg" title="Sửa"><PenTool size={16} /></button>
                                            <button onClick={() => handleDeleteItem(item.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-slate-100 rounded-lg" title="Xóa"><Trash2 size={16} /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {inventory.length === 0 && <div className="p-10 text-center text-slate-400">Kho hàng trống. Vui lòng thêm vật tư mới.</div>}
                    </div>
                )}

                {/* HISTORY TABLE */}
                {activeTab === 'HISTORY' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
                                <tr>
                                    <th className="p-4">Thời gian</th>
                                    <th className="p-4">Vật tư</th>
                                    <th className="p-4 text-center">Loại GD</th>
                                    <th className="p-4 text-right">Số lượng</th>
                                    <th className="p-4">Người thực hiện</th>
                                    <th className="p-4">Lý do / Link</th>
                                    {isManager && <th className="p-4 text-center">Thao tác</th>}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {history.map((h) => (
                                    <tr key={h.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="p-4 text-slate-500">{format(new Date(h.date), "dd/MM/yyyy HH:mm")}</td>
                                        <td className="p-4">
                                            <p className="font-bold text-slate-700">{h.itemName}</p>
                                            <p className="text-xs text-slate-400 font-mono">{h.sku}</p>
                                        </td>
                                        <td className="p-4 text-center">
                                            <span className={clsx("px-2 py-1 rounded-full text-xs font-bold",
                                                h.type === 'IMPORT' ? "bg-blue-100 text-blue-600" : "bg-amber-100 text-amber-600"
                                            )}>
                                                {h.type === 'IMPORT' ? 'Nhập kho' : h.type === 'RETURN' ? 'Thu hồi' : 'Xuất kho'}
                                            </span>
                                        </td>
                                        <td className="p-4 text-right font-bold text-slate-700">
                                            {h.type === 'EXPORT' ? '-' : '+'}{h.quantity} <span className="text-xs font-normal text-slate-400">{h.unit}</span>
                                        </td>
                                        <td className="p-4 text-slate-600">{h.performedBy}</td>
                                        <td className="p-4 text-slate-500 max-w-xs truncate">
                                            {h.reason}
                                            {h.referenceId && <span className="block text-xs text-blue-600 mt-1">Ref: #{h.referenceId}</span>}
                                        </td>
                                        {isManager && (
                                            <td className="p-4 flex items-center justify-center gap-2">
                                                <button onClick={() => openEditHistory(h)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-lg" title="Sửa ghi chú">
                                                    <Edit size={16} />
                                                </button>
                                                <button onClick={() => handleDeleteHistory(h.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-slate-100 rounded-lg" title="Xóa lịch sử">
                                                    <Trash2 size={16} />
                                                </button>
                                            </td>
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {history.length === 0 && <div className="p-10 text-center text-slate-400">Chưa có dữ liệu lịch sử.</div>}
                    </div>
                )}
            </div>

            {/* --- TRANSACTION MODAL --- */}
            {
                isTransactionModalOpen && selectedInventoryItem && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl animate-in zoom-in-95">
                            <div className={clsx("p-5 border-b flex justify-between items-center text-white",
                                transactionData.type === 'IMPORT' ? "bg-blue-600" :
                                    transactionData.type === 'EXPORT' ? "bg-amber-500" :
                                        "bg-purple-600"
                            )}>
                                <h3 className="font-bold text-lg">
                                    {transactionData.type === 'IMPORT' ? 'NHẬP KHO' :
                                        transactionData.type === 'EXPORT' ? 'XUẤT KHO' :
                                            'THU HỒI TỪ KHOA / HOÀN TRẢ'}
                                </h3>
                                <button onClick={() => setIsTransactionModalOpen(false)} className="p-1 rounded-full hover:bg-white/20"><XCircle size={24} /></button>
                            </div>
                            <div className="p-6 space-y-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-500 uppercase">Vật tư</label>
                                    <p className="font-bold text-slate-800 text-lg">{selectedInventoryItem.name}</p>
                                    <p className="text-sm text-slate-500">Tồn hiện tại: <span className="font-bold">{selectedInventoryItem.quantity} {selectedInventoryItem.unit}</span></p>
                                </div>
                                <div>
                                    <label className="text-sm font-bold text-slate-700">Số lượng</label>
                                    <input type="number" className="w-full p-2 border rounded-xl mt-1 text-lg font-bold" autoFocus value={transactionData.quantity} onChange={e => setTransactionData({ ...transactionData, quantity: parseInt(e.target.value) || 0 })} />
                                </div>

                                {transactionData.type === 'EXPORT' && (
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Liên kết Công việc / Yêu cầu</label>
                                        <select
                                            className="w-full p-2 border rounded-xl mt-1 text-sm bg-slate-50"
                                            value={transactionData.referenceId}
                                            onChange={e => {
                                                const val = e.target.value;
                                                const parts = val.split(':');
                                                const prefix = parts[0];
                                                const id = parts[1];

                                                // Find details for auto-reason
                                                const ticket = tickets.find(t => t.id.toString() === id);
                                                const req = reqs.find(r => r.id.toString() === id);

                                                let reason = "";
                                                if (prefix === 'TICKET' && ticket) reason = `Xuất vật tư cho sự cố #${ticket.id} (${ticket.title})`;
                                                if (prefix === 'REQ' && req) reason = `Xuất theo yêu cầu #${req.id} (${req.itemName})`;

                                                setTransactionData({
                                                    ...transactionData,
                                                    // If we have a prefix, store distinct ID. If not, empty.
                                                    // Ideally backend stores simple string referenceId
                                                    referenceId: val,
                                                    reason: reason || transactionData.reason
                                                });
                                            }}
                                        >
                                            <option value="">-- Không liên kết --</option>
                                            <optgroup label="Sự cố Kỹ thuật (Technical Tickets)">
                                                {tickets.map(t => (
                                                    <option key={`TICKET:${t.id}`} value={`TICKET:${t.id}`}>#{t.id} - {t.title} ({t.location})</option>
                                                ))}
                                            </optgroup>
                                            <optgroup label="Yêu cầu Vật tư lẻ (Supply Requests)">
                                                {reqs.map(r => (
                                                    <option key={`REQ:${r.id}`} value={`REQ:${r.id}`}>#{r.id} - {r.itemName} ({r.requester})</option>
                                                ))}
                                            </optgroup>
                                        </select>
                                    </div>
                                )}

                                <div>
                                    <label className="text-sm font-bold text-slate-700">
                                        {transactionData.type === 'RETURN' ? 'Khoa / Phòng trả lại' : 'Lý do / Ghi chú'}
                                    </label>
                                    <input className="w-full p-2 border rounded-xl mt-1"
                                        placeholder={transactionData.type === 'RETURN' ? "VD: Khoa Nội, Phòng 101..." : "VD: Nhập hàng mới, Xuất sửa chữa..."}
                                        value={transactionData.reason}
                                        onChange={e => setTransactionData({ ...transactionData, reason: e.target.value })} />
                                </div>
                            </div>
                            <div className="p-4 border-t bg-slate-50 flex gap-2">
                                <button onClick={() => setIsTransactionModalOpen(false)} className="flex-1 py-2 rounded-xl font-bold bg-slate-200 text-slate-600 hover:bg-slate-300">Hủy</button>
                                <button onClick={handleTransactionSubmit} className={clsx("flex-1 py-2 rounded-xl font-bold text-white shadow-lg",
                                    transactionData.type === 'IMPORT' ? "bg-blue-600 hover:bg-blue-700" :
                                        transactionData.type === 'EXPORT' ? "bg-amber-500 hover:bg-amber-600" :
                                            "bg-purple-600 hover:bg-purple-700"
                                )}>
                                    Xác nhận
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* --- EDIT REQUEST MODAL --- */}
            {
                isEditReqModalOpen && editingReq && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-in zoom-in-95">
                            <div className="p-4 border-b flex justify-between items-center">
                                <h3 className="font-bold text-lg text-slate-800">Điều chỉnh yêu cầu</h3>
                                <button onClick={() => setIsEditReqModalOpen(false)}><XCircle size={24} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="p-6 space-y-4">
                                <div>
                                    <p className="text-sm font-bold text-slate-500 uppercase">Vật tư yêu cầu</p>
                                    <p className="font-bold text-slate-800 text-lg">{editingReq.itemName}</p>
                                    <p className="text-xs text-slate-400">{editingReq.requester}</p>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Số lượng</label>
                                        <input type="number" min="1" className="w-full p-2 border rounded-xl mt-1 font-bold" value={editReqData.quantity} onChange={e => setEditReqData({ ...editReqData, quantity: parseInt(e.target.value) || 1 })} />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Đơn vị</label>
                                        <input className="w-full p-2 border rounded-xl mt-1" value={editReqData.unit} onChange={e => setEditReqData({ ...editReqData, unit: e.target.value })} />
                                    </div>
                                </div>
                            </div>
                            <div className="p-4 border-t bg-slate-50 flex gap-2">
                                <button onClick={() => setIsEditReqModalOpen(false)} className="flex-1 py-2 rounded-xl font-bold bg-slate-200 text-slate-600 hover:bg-slate-300">Hủy</button>
                                <button onClick={handleUpdateReq} className="flex-1 py-2 rounded-xl font-bold bg-blue-600 text-white hover:bg-blue-700 shadow-lg">Cập nhật</button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* --- EDIT HISTORY MODAL --- */}
            {
                isEditHistoryModalOpen && editingHistory && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-in zoom-in-95">
                            <div className="p-4 border-b flex justify-between items-center">
                                <h3 className="font-bold text-lg text-slate-800">Chỉnh sửa lịch sử</h3>
                                <button onClick={() => setIsEditHistoryModalOpen(false)}><XCircle size={24} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="p-6 space-y-4">
                                <div>
                                    <p className="text-sm font-bold text-slate-500 uppercase">Giao dịch</p>
                                    <p className="font-bold text-slate-800 text-lg">{editingHistory.itemName}</p>
                                    <p className="text-xs text-slate-400">{format(new Date(editingHistory.date), "dd/MM/yyyy HH:mm")}</p>
                                </div>
                                <div>
                                    <label className="text-sm font-bold text-slate-700">Lý do / Ghi chú</label>
                                    <textarea
                                        className="w-full p-2 border rounded-xl mt-1 h-24"
                                        placeholder="Nhập lý do..."
                                        value={editHistoryData.reason}
                                        onChange={e => setEditHistoryData({ ...editHistoryData, reason: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div className="p-4 border-t bg-slate-50 flex gap-2">
                                <button onClick={() => setIsEditHistoryModalOpen(false)} className="flex-1 py-2 rounded-xl font-bold bg-slate-200 text-slate-600 hover:bg-slate-300">Hủy</button>
                                <button onClick={handleUpdateHistory} className="flex-1 py-2 rounded-xl font-bold bg-blue-600 text-white hover:bg-blue-700 shadow-lg">Cập nhật</button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* --- CREATE PLAN MODAL --- */}
            {
                isCreatePlanModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
                            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
                                <h3 className="font-bold text-xl text-slate-800">{editingPlanId ? "Chỉnh sửa phiếu dự trù" : "Lập dự trù mới"}</h3>
                                <button onClick={() => { setIsCreatePlanModalOpen(false); setEditingPlanId(null); setPlanFormData({ title: "", description: "", supplierBank: "" }); setPlanItems([{ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]); }} className="p-1 rounded-full hover:bg-slate-100"><XCircle size={24} className="text-slate-400" /></button>
                            </div>
                            <div className="p-6 overflow-y-auto flex-1 space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div><label className="text-sm font-bold text-slate-700 mb-1 block">Nội dung dự trù</label><input className="w-full p-2 border rounded-xl" placeholder="VD: Sửa chữa bồn nước..." value={planFormData.title} onChange={e => setPlanFormData({ ...planFormData, title: e.target.value })} /></div>
                                    <div><label className="text-sm font-bold text-slate-700 mb-1 block">Thông tin chuyển khoản NCC</label><input className="w-full p-2 border rounded-xl" placeholder="VD: Vietcombank - 0123... - Công ty A" value={planFormData.supplierBank} onChange={e => setPlanFormData({ ...planFormData, supplierBank: e.target.value })} /></div>
                                </div>
                                <div><label className="text-sm font-bold text-slate-700 mb-1 block">Ghi chú</label><input className="w-full p-2 border rounded-xl" placeholder="Ghi chú thêm..." value={planFormData.description} onChange={e => setPlanFormData({ ...planFormData, description: e.target.value })} /></div>

                                {/* Items List */}
                                <div>
                                    <div className="flex justify-between items-end mb-2">
                                        <label className="text-sm font-bold text-slate-700">Danh sách chi tiết <span className="text-xs font-normal text-slate-400 italic">(Lưu ý: Nhập % VAT cho từng món)</span></label>
                                        <button onClick={handleAddItem} className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"><Plus size={14} /> Thêm dòng</button>
                                    </div>
                                    <div className="space-y-2">
                                        {planItems.map((item, idx) => (
                                            <div key={idx} className="flex gap-2 items-start bg-slate-50 p-3 rounded-xl border border-slate-100">
                                                <span className="text-xs text-slate-400 w-4 pt-3 text-center">{idx + 1}</span>
                                                <div className="flex-1 space-y-2">
                                                    <div className="flex gap-2">
                                                        <input className="flex-[3] p-2 border rounded-lg text-sm" placeholder="Hạng mục" value={item.itemName} onChange={e => handleItemChange(idx, 'itemName', e.target.value)} />
                                                        <input className="flex-[2] p-2 border rounded-lg text-sm" placeholder="Nhà cung cấp" value={item.supplier} onChange={e => handleItemChange(idx, 'supplier', e.target.value)} />
                                                    </div>
                                                    <div className="flex gap-2">
                                                        <input className="w-20 p-2 border rounded-lg text-sm" placeholder="ĐVT" value={item.unit} onChange={e => handleItemChange(idx, 'unit', e.target.value)} />
                                                        <input type="number" className="w-20 p-2 border rounded-lg text-sm" placeholder="SL" value={item.quantity} onChange={e => handleItemChange(idx, 'quantity', parseFloat(e.target.value))} />
                                                        <input type="number" className="flex-1 p-2 border rounded-lg text-sm" placeholder="Đơn giá" value={item.unitPrice} onChange={e => handleItemChange(idx, 'unitPrice', parseFloat(e.target.value))} />
                                                        <input type="number" className="w-20 p-2 border rounded-lg text-sm font-bold text-slate-700" placeholder="VAT%" title="VAT %" value={item.vat} onChange={e => handleItemChange(idx, 'vat', parseFloat(e.target.value))} />
                                                    </div>
                                                    <div className="mt-2">
                                                        <input className="w-full p-2 border rounded-lg text-sm" placeholder="Thông tin chuyển khoản (Số TK - Ngân hàng - Chi nhánh)" value={item.bankAccount || ''} onChange={e => handleItemChange(idx, 'bankAccount', e.target.value)} />
                                                    </div>
                                                </div>
                                                <button onClick={() => handleRemoveItem(idx)} className="p-2 text-slate-400 hover:text-red-500 pt-3"><Trash2 size={16} /></button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <div className="p-5 border-t border-slate-100 flex justify-end gap-3 bg-slate-50">
                                <button onClick={() => { setIsCreatePlanModalOpen(false); setEditingPlanId(null); setPlanFormData({ title: "", description: "", supplierBank: "" }); setPlanItems([{ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]); }} className="px-5 py-2.5 rounded-xl font-bold text-slate-500 hover:bg-slate-200">Hủy</button>
                                <button onClick={handlePlanSubmit} className="px-5 py-2.5 rounded-xl font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20">Lưu phiếu</button>
                            </div>
                        </div>
                    </div >
                )
            }

            {/* --- REJECT MODAL --- */}
            {
                isRejectModalOpen && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95">
                            <div className="flex justify-center mb-4 text-red-100 bg-red-500 w-16 h-16 rounded-full items-center mx-auto">
                                <XCircle size={32} className="text-white" />
                            </div>
                            <h3 className="text-center font-bold text-xl text-slate-800 mb-2">Từ chối duyệt phiếu?</h3>
                            <p className="text-center text-sm text-slate-500 mb-4">Vui lòng nhập lý do từ chối để người lập biết và chỉnh sửa.</p>
                            <textarea
                                className="w-full p-3 border border-slate-200 rounded-xl mb-4 focus:ring-2 focus:ring-red-500/20 outline-none"
                                placeholder="Nhập lý do từ chối..."
                                rows={3}
                                value={rejectReason}
                                onChange={e => setRejectReason(e.target.value)}
                            />
                            <div className="flex gap-2">
                                <button onClick={() => setIsRejectModalOpen(false)} className="flex-1 py-2 rounded-xl font-bold bg-slate-100 text-slate-600">Hủy</button>
                                <button
                                    onClick={handleRejectPlan}
                                    disabled={!rejectReason.trim()}
                                    className="flex-1 py-2 rounded-xl font-bold bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
                                >
                                    Xác nhận
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* --- CREATE ITEM MODAL --- */}
            {
                isCreateItemModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden flex flex-col shadow-2xl">
                            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
                                <h3 className="font-bold text-xl text-slate-800">{isEditingItem ? "Cập nhật vật tư" : "Thêm vật tư mới"}</h3>
                                <button onClick={() => { setIsCreateItemModalOpen(false); setIsEditingItem(false); }} className="p-1 rounded-full hover:bg-slate-100"><XCircle size={24} className="text-slate-400" /></button>
                            </div>
                            <div className="p-6 space-y-4">
                                <div>
                                    <label className="text-sm font-bold text-slate-700">Mã SKU <span className="text-xs font-normal text-slate-400">(Tự động)</span></label>
                                    <div className="flex gap-2">
                                        <input
                                            className="w-full p-2 border rounded-xl mt-1 bg-slate-50 font-mono text-slate-600"
                                            value={newItemData.sku}
                                            onChange={e => setNewItemData({ ...newItemData, sku: e.target.value })}
                                            placeholder="Tự động tạo..."
                                        />
                                        <button
                                            onClick={() => setNewItemData({ ...newItemData, sku: generateSKU(newItemData.name, newItemData.category) })}
                                            className="mt-1 p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl"
                                            title="Tạo lại mã SKU"
                                        >
                                            <RefreshCw size={20} />
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label className="text-sm font-bold text-slate-700">Tên vật tư</label>
                                    <input
                                        className="w-full p-2 border rounded-xl mt-1"
                                        value={newItemData.name}
                                        onChange={e => {
                                            const newName = e.target.value;
                                            // Only auto-update SKU if it's empty or we want aggressive auto-fill. 
                                            // Let's auto-fill if SKU is empty OR looks like a generated one (has dash).
                                            // For simplicity, just update state.
                                            setNewItemData(prev => ({
                                                ...prev,
                                                name: newName,
                                                // If SKU is empty, generate it.
                                                sku: prev.sku ? prev.sku : generateSKU(newName, prev.category)
                                            }));
                                        }}
                                        onBlur={() => {
                                            if (!newItemData.sku) {
                                                setNewItemData(prev => ({ ...prev, sku: generateSKU(prev.name, prev.category) }));
                                            }
                                        }}
                                        placeholder="VD: Bóng đèn LED 9W"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="text-sm font-bold text-slate-700">Danh mục</label>
                                        <select
                                            className="w-full p-2 border rounded-xl mt-1"
                                            value={newItemData.category}
                                            onChange={e => {
                                                const newCategory = e.target.value;
                                                setNewItemData(prev => ({
                                                    ...prev,
                                                    category: newCategory,
                                                    // Regenerate SKU if name exists and user changes category (optional but helpful)
                                                    sku: generateSKU(prev.name, newCategory)
                                                }));
                                            }}
                                        >
                                            <option value="GENERAL">Chung</option>
                                            <option value="ELECTRICAL">Điện</option>
                                            <option value="PLUMBING">Nước</option>
                                            <option value="OFFICE">Văn phòng phẩm</option>
                                            <option value="MEDICAL">Y tế</option>
                                            <option value="CHEMICAL">Hóa chất</option>
                                            <option value="IT">CNTT</option>
                                            <option value="FURNITURE">Nội thất</option>
                                            <option value="OTHER">Khác</option>
                                        </select>
                                    </div>
                                    <div><label className="text-sm font-bold text-slate-700">Đơn vị tính</label><input className="w-full p-2 border rounded-xl mt-1" value={newItemData.unit} onChange={e => setNewItemData({ ...newItemData, unit: e.target.value })} /></div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Tồn kho</label>
                                        <input
                                            type="number"
                                            className={clsx("w-full p-2 border rounded-xl mt-1", isEditingItem ? "bg-slate-100 text-slate-500 cursor-not-allowed" : "")}
                                            value={newItemData.quantity}
                                            onChange={e => setNewItemData({ ...newItemData, quantity: parseInt(e.target.value) || 0 })}
                                            disabled={isEditingItem}
                                            title={isEditingItem ? "Không thể sửa tồn kho trực tiếp. Hãy dùng chức năng Nhập/Xuất." : ""}
                                        />
                                    </div>
                                    <div><label className="text-sm font-bold text-slate-700">Mức cảnh báo (Min)</label><input type="number" className="w-full p-2 border rounded-xl mt-1" value={newItemData.minLevel} onChange={e => setNewItemData({ ...newItemData, minLevel: parseInt(e.target.value) || 0 })} /></div>
                                </div>
                                <div><label className="text-sm font-bold text-slate-700">Vị trí lưu kho</label><input className="w-full p-2 border rounded-xl mt-1" value={newItemData.location} onChange={e => setNewItemData({ ...newItemData, location: e.target.value })} placeholder="VD: Kệ A - Ngăn 2" /></div>
                            </div>
                            <div className="p-5 border-t border-slate-100 flex justify-end gap-3 bg-slate-50">
                                <button onClick={() => { setIsCreateItemModalOpen(false); setIsEditingItem(false); }} className="px-5 py-2.5 rounded-xl font-bold text-slate-500 hover:bg-slate-200">Hủy</button>
                                <button onClick={isEditingItem ? handleUpdateItem : handleCreateItem} className="px-5 py-2.5 rounded-xl font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20">
                                    {isEditingItem ? "Lưu thay đổi" : "Lưu vật tư"}
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* --- DETAIL & PRINT MODAL --- */}
            {
                selectedPlan && (
                    <div className="fixed inset-0 z-[50] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-0 md:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible print:h-auto print:w-auto print:block">
                        {/* Screen View Container */}
                        <div className="bg-slate-100 md:rounded-2xl w-full max-w-5xl min-h-[90vh] md:min-h-0 md:h-auto flex flex-col shadow-2xl print:hidden">
                            <div className="p-4 bg-white border-b flex justify-between items-center sticky top-0 md:static z-10">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">Chi tiết phiếu dự trù</h3>
                                    <p className="text-xs text-slate-500">{selectedPlan.code || 'CHƯA CÓ MÃ'} - {selectedPlan.title}</p>
                                </div>
                                <button onClick={() => setSelectedPlan(null)} className="p-2 hover:bg-slate-100 rounded-full"><XCircle size={24} className="text-slate-400" /></button>
                            </div>

                            <div className="p-6 overflow-y-auto max-h-[70vh]">
                                {selectedPlan.status === 'REJECTED' && (
                                    <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex gap-3 items-start">
                                        <AlertCircle className="text-red-500 shrink-0" size={24} />
                                        <div>
                                            <h4 className="font-bold text-red-800">Phiếu đã bị từ chối</h4>
                                            <p className="text-red-600 text-sm mt-1">Lý do: {selectedPlan.rejectionReason || "Không có lý do cụ thể"}</p>
                                        </div>
                                    </div>
                                )}

                                {/* Preview Content (simplified for screen) */}
                                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                    <div className="grid grid-cols-2 gap-6 mb-6">
                                        <div>
                                            <p className="text-xs text-slate-400 font-bold uppercase">Người lập</p>
                                            <p className="text-slate-800 font-medium">{selectedPlan.createdBy?.fullName || 'N/A'}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-slate-400 font-bold uppercase">Ngày lập</p>
                                            <p className="text-slate-800 font-medium">{format(new Date(selectedPlan.createdAt), "dd/MM/yyyy HH:mm")}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-slate-400 font-bold uppercase">Trạng thái</p>
                                            <span className={clsx("inline-block mt-1 px-2 py-1 rounded-md text-xs font-bold",
                                                selectedPlan.status === 'PENDING' ? "bg-amber-100 text-amber-600" :
                                                    selectedPlan.status === 'APPROVED' ? "bg-emerald-100 text-emerald-600" :
                                                        "bg-red-100 text-red-600"
                                            )}>{selectedPlan.status}</span>
                                        </div>
                                    </div>

                                    <table className="w-full text-sm border-collapse">
                                        <thead>
                                            <tr className="bg-slate-50">
                                                <th className="border p-2 text-left">Hạng mục</th>
                                                <th className="border p-2 text-center">SL</th>
                                                <th className="border p-2 text-right">Đơn giá</th>
                                                <th className="border p-2 text-right">Thành tiền</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {selectedPlan.items.map((item, i) => (
                                                <tr key={i}>
                                                    <td className="border p-2">{item.itemName}</td>
                                                    <td className="border p-2 text-center">{item.quantity} {item.unit}</td>
                                                    <td className="border p-2 text-right">{item.unitPrice?.toLocaleString()}</td>
                                                    <td className="border p-2 text-right font-bold">{calculateItemTotal(item).toLocaleString()}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        <tfoot>
                                            <tr className="bg-slate-50 font-bold">
                                                <td colSpan={2} className="border p-2 text-right">Tổng cộng</td>
                                                <td className="border p-2 text-right text-emerald-600">{calculatePlanTotal(selectedPlan.items).toLocaleString()} đ</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                            <div className="p-4 bg-white border-t flex justify-end gap-3 sticky bottom-0">
                                {selectedPlan.status === 'PENDING' && (
                                    <>
                                        <button onClick={() => handleDeletePlan(selectedPlan.id)} className="px-4 py-2 text-red-600 hover:bg-red-50 font-bold rounded-xl border border-transparent hover:border-red-100">Xóa phiếu</button>
                                        <button onClick={() => openRejectModal(selectedPlan.id)} className="px-4 py-2 bg-red-100 text-red-700 font-bold rounded-xl hover:bg-red-200">Từ chối</button>
                                        <button onClick={() => handleApprovePlan(selectedPlan.id)} className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20">Duyệt phiếu</button>
                                    </>
                                )}
                                {selectedPlan.status === 'APPROVED' && (
                                    <>

                                        {(session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER')) && (
                                            <button onClick={() => handleDeletePlan(selectedPlan.id)} className="px-4 py-2 text-red-600 hover:bg-red-50 font-bold rounded-xl border border-transparent hover:border-red-100">Xóa phiếu</button>
                                        )}

                                        <button onClick={() => handleAdjustPlan(selectedPlan.id)} className="px-4 py-2 bg-amber-100 text-amber-700 font-bold rounded-xl hover:bg-amber-200">Điều chỉnh</button>

                                        <button onClick={handleDownloadPDF} className="px-6 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center gap-2">
                                            <Download size={18} /> PDF
                                        </button>

                                    </>
                                )}
                            </div>
                        </div>

                        {/* --- PRINT TEMPLATE A4 --- */}
                        {/* --- PRINT TEMPLATE A4 --- */}
                        {/* --- PRINT TEMPLATE A4 - CUSTOM STYLE --- */}
                        {/* --- PRINT TEMPLATE A4 - CUSTOM STYLE --- */}
                        <div id="print-template-container" className="hidden print:block bg-white w-[210mm] min-h-[297mm] mx-auto p-[10mm_15mm] text-black leading-snug print:relative print:top-auto print:left-auto z-[100]" style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}>
                            {/* Header Row */}
                            <div className="flex items-center justify-between mb-8 border-b-0 pb-0">
                                {/* Left Logo */}
                                <div className="w-[30%]">
                                    <img src="/logo-becamex.png" alt="Becamex Logo" className="h-16 object-contain" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                                    {/* Fallback text if logo fails to load */}
                                    <div className="text-blue-600 font-bold uppercase text-xs mt-1 leading-tight tracking-tight hidden print:block">
                                        BỆNH VIỆN QUỐC TẾ<br />BECAMEX<br /><span className="text-[8px] font-normal tracking-wider">INTERNATIONAL HOSPITAL</span>
                                    </div>
                                </div>

                                {/* Center Title */}
                                <div className="w-[40%] text-center">
                                    <h1 className="text-2xl font-bold text-black uppercase">Dự trù mua hàng</h1>
                                </div>

                                {/* Right Code */}
                                <div className="w-[30%] text-right font-bold text-[10pt]">
                                    Mã: {selectedPlan.code || 'DTMH-20/01/2026-00621'}
                                </div>
                            </div>

                            {/* Meta Info */}
                            <div className="mb-6 text-[10pt] space-y-3">
                                <div className="flex justify-between">
                                    <p><span className="font-bold">Nội dung dự trù:</span> {selectedPlan.title}</p>
                                </div>
                                <div className="flex justify-between">
                                    <p><span className="font-bold">Người tạo:</span> {selectedPlan.createdBy?.fullName || 'Lê Minh Trí'}</p>
                                    <p><span className="font-bold">Ngày tạo:</span> {format(new Date(selectedPlan.createdAt), "dd/MM/yyyy")}</p>
                                </div>
                            </div>

                            {/* Table */}
                            <div className="mb-6">
                                <h3 className="font-bold text-[10pt] mb-2">Bảng kê chi tiết:</h3>
                                <table className="w-full border-collapse border border-slate-300 text-[9pt]">
                                    <thead>
                                        <tr className="bg-slate-100 text-black font-bold">
                                            <th className="border border-slate-300 p-2 text-left">Hạng mục</th>

                                            <th className="border border-slate-300 p-2 text-left w-[25mm]">NCC</th>
                                            <th className="border border-slate-300 p-2 text-center w-[15mm]">ĐVT</th>
                                            <th className="border border-slate-300 p-2 text-center w-[20mm]">Số lượng</th>
                                            <th className="border border-slate-300 p-2 text-right w-[25mm]">Đơn giá</th>
                                            <th className="border border-slate-300 p-2 text-center w-[15mm]">VAT (%)</th>
                                            <th className="border border-slate-300 p-2 text-right w-[30mm]">Thành tiền</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {selectedPlan.items.map((item, idx) => {
                                            // Map category to Display Type
                                            const typeMap: Record<string, string> = {
                                                'ELECTRICAL': 'KTVH',
                                                'PLUMBING': 'KTVH',
                                                'OFFICE': 'VPP',
                                                'MEDICAL': 'VTYT',
                                                'GENERAL': 'KTVH'
                                            };
                                            const typeDisplay = typeMap[item.category] || 'KTVH';

                                            return (
                                                <tr key={idx}>
                                                    <td className="border border-slate-300 p-2 font-medium">{item.itemName}</td>

                                                    <td className="border border-slate-300 p-2">{item.supplier || 'An Thịnh'}</td>
                                                    <td className="border border-slate-300 p-2 text-center">{item.unit}</td>
                                                    <td className="border border-slate-300 p-2 text-center">{item.quantity}</td>
                                                    <td className="border border-slate-300 p-2 text-right">{item.unitPrice ? item.unitPrice.toLocaleString('en-US') : '0'}</td>
                                                    <td className="border border-slate-300 p-2 text-center">{item.vat || 10}</td>
                                                    <td className="border border-slate-300 p-2 text-right font-bold">{calculateItemTotal(item).toLocaleString('en-US')}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colSpan={7} className="border-t border-slate-300 pt-3 text-right font-bold text-[11pt]">
                                                Tổng cộng: {calculatePlanTotal(selectedPlan.items).toLocaleString('en-US')}
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            {/* Note */}
                            <p className="mb-12 text-[10pt]"><span className="font-bold">Ghi chú (nếu có):</span> {selectedPlan.description || 'file danh mục sửa chữa'}</p>

                            {/* Signatures */}
                            <div className="text-[10pt] space-y-12 font-bold text-black break-inside-avoid px-2 pb-10">
                                <div className="flex justify-between items-end">
                                    <div className="w-[60%]">
                                        <p className="mb-2">Người lập bảng:</p>
                                        <p className="font-normal uppercase">{selectedPlan.createdBy?.fullName || 'Lê Minh Trí'}</p>
                                    </div>
                                    <div className="w-[40%] text-right font-normal italic text-slate-500">Chữ ký: ___________________</div>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div className="w-[60%]">
                                        <p className="mb-2">Phòng Tài chính Kế toán:</p>
                                        <p className="font-normal uppercase">Nguyễn Thị Bích Sơn</p>
                                    </div>
                                    <div className="w-[40%] text-right font-normal italic text-slate-500">Chữ ký: ___________________</div>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div className="w-[60%]">
                                        <p className="mb-2">Giám đốc Bệnh viện Quốc tế Becamex:</p>
                                        <p className="font-normal uppercase">Nguyễn Văn Trương</p>
                                    </div>
                                    <div className="w-[40%] text-right font-normal italic text-slate-500">Chữ ký: ___________________</div>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div className="w-[70%]">
                                        <p className="mb-2">CT Hội đồng Quản trị Công ty CP Bệnh viện Quốc tế Becamex:</p>
                                        <p className="font-normal uppercase">Nguyễn Tấn Lợi</p>
                                    </div>
                                    <div className="w-[30%] text-right font-normal italic text-slate-500">Chữ ký: ___________________</div>
                                </div>
                            </div>
                        </div>
                    </div>
                )
            }


            {/* --- LINK INVENTORY MODAL --- */}
            {
                isLinkModalOpen && linkRequest && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 print:hidden">
                        <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 flex flex-col max-h-[90vh]">
                            <div className="p-5 border-b bg-slate-50 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">Liên kết kho</h3>
                                    <p className="text-sm text-slate-500">Chọn vật tư để liên kết với yêu cầu: <b>{linkRequest.itemName}</b></p>
                                </div>
                                <button onClick={() => setIsLinkModalOpen(false)} className="p-1 rounded-full hover:bg-slate-200"><XCircle size={24} className="text-slate-400" /></button>
                            </div>

                            <div className="p-4 overflow-y-auto flex-1 space-y-2">
                                <input
                                    type="text"
                                    placeholder="Tìm kiếm vật tư..."
                                    className="w-full p-3 border rounded-xl bg-slate-50 focus:bg-white transition-all sticky top-0"
                                />
                                {inventory.map(item => (
                                    <div key={item.id} className="flex items-center justify-between p-3 border rounded-xl hover:bg-slate-50 cursor-pointer group"
                                        onClick={() => {
                                            openConfirm("Liên kết kho", `Liên kết yêu cầu với ${item.name}?`, async () => {
                                                try {
                                                    const res = await fetch(`/api/supply/requests/${linkRequest.id}`, {
                                                        method: 'PATCH',
                                                        body: JSON.stringify({ inventoryId: item.id }),
                                                        headers: { 'Content-Type': 'application/json' }
                                                    });
                                                    if (res.ok) {
                                                        setIsLinkModalOpen(false);
                                                        fetchRequests();
                                                        showToast("Đã liên kết thành công!", 'success');
                                                    } else {
                                                        showToast("Lỗi liên kết", 'error');
                                                    }
                                                } catch (e) { console.error(e); }
                                            }, 'info');
                                        }}
                                    >
                                        <div>
                                            <p className="font-bold text-slate-700">{item.name}</p>
                                            <p className="text-xs text-slate-500 font-mono">{item.sku} • Tồn: {item.quantity} {item.unit}</p>
                                        </div>
                                        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                            <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold">Chọn</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )
            }
        </div >
    );
}

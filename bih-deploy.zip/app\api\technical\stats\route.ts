import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// API thống kê cho Dashboard Kỹ thuật vận hành
export async function GET() {
    try {
        // 1. Tổng số ticket theo trạng thái
        const statusCounts = await prisma.maintenanceRequest.groupBy({
            by: ['status'],
            _count: { status: true }
        });

        // 2. Tổng số ticket theo mức độ ưu tiên
        const priorityCounts = await prisma.maintenanceRequest.groupBy({
            by: ['priority'],
            _count: { priority: true }
        });

        // 3. Top vị trí hay hư (tần suất cao nhất)
        const locationStats = await prisma.maintenanceRequest.groupBy({
            by: ['location'],
            _count: { location: true },
            orderBy: { _count: { location: 'desc' } },
            take: 10
        });

        // 4. Top nhân viên được giao việc nhiều nhất
        const staffAssignments = await prisma.maintenanceAssignment.groupBy({
            by: ['userId'],
            _count: { userId: true },
            orderBy: { _count: { userId: 'desc' } },
            take: 10
        });

        // Lấy thông tin chi tiết của nhân viên
        const staffIds = staffAssignments.map(s => s.userId);
        const staffDetails = await prisma.user.findMany({
            where: { id: { in: staffIds } },
            select: { id: true, fullName: true, position: true }
        });

        const topStaff = staffAssignments.map(s => ({
            ...staffDetails.find(u => u.id === s.userId),
            assignmentCount: s._count.userId
        }));

        // 5. Thống kê ticket theo tháng (6 tháng gần nhất)
        const sixMonthsAgo = new Date();
        sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

        const monthlyTickets = await prisma.maintenanceRequest.findMany({
            where: { createdAt: { gte: sixMonthsAgo } },
            select: { createdAt: true, status: true }
        });

        // Group by month
        const monthlyStats: Record<string, { total: number; completed: number }> = {};
        monthlyTickets.forEach(ticket => {
            const monthKey = `${ticket.createdAt.getFullYear()}-${String(ticket.createdAt.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyStats[monthKey]) {
                monthlyStats[monthKey] = { total: 0, completed: 0 };
            }
            monthlyStats[monthKey].total++;
            if (ticket.status === 'COMPLETED') {
                monthlyStats[monthKey].completed++;
            }
        });

        // 6. Thống kê ticket trong 7 ngày gần nhất
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

        const weeklyTickets = await prisma.maintenanceRequest.findMany({
            where: { createdAt: { gte: sevenDaysAgo } },
            select: { createdAt: true, status: true, priority: true }
        });

        // Group by day
        const dailyStats: Record<string, { total: number; completed: number; urgent: number }> = {};
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dayKey = date.toISOString().split('T')[0];
            dailyStats[dayKey] = { total: 0, completed: 0, urgent: 0 };
        }

        weeklyTickets.forEach(ticket => {
            const dayKey = ticket.createdAt.toISOString().split('T')[0];
            if (dailyStats[dayKey]) {
                dailyStats[dayKey].total++;
                if (ticket.status === 'COMPLETED') dailyStats[dayKey].completed++;
                if (ticket.priority === 'URGENT' || ticket.priority === 'HIGH') dailyStats[dayKey].urgent++;
            }
        });

        // 7. Tính hiệu suất xử lý (completion rate)
        const totalTickets = await prisma.maintenanceRequest.count();
        const completedTickets = await prisma.maintenanceRequest.count({
            where: { status: 'COMPLETED' }
        });
        const pendingTickets = await prisma.maintenanceRequest.count({
            where: { status: 'PENDING' }
        });

        const completionRate = totalTickets > 0 ? Math.round((completedTickets / totalTickets) * 100) : 0;

        // 8. Thống kê theo loại vị trí (phòng, khu, etc.)
        const locationTypeStatsRaw = await prisma.$queryRaw`
            SELECT 
                CASE 
                    WHEN location LIKE '%Phòng%' OR location LIKE '%Room%' THEN 'Phòng bệnh'
                    WHEN location LIKE '%WC%' OR location LIKE '%toilet%' THEN 'Nhà vệ sinh'
                    WHEN location LIKE '%Hành lang%' OR location LIKE '%Corridor%' THEN 'Hành lang'
                    WHEN location LIKE '%Sảnh%' OR location LIKE '%Lobby%' THEN 'Sảnh'
                    ELSE 'Khác'
                END as "locationType",
                COUNT(*) as count
            FROM "MaintenanceRequest"
            GROUP BY "locationType"
            ORDER BY count DESC
        ` as Array<{ locationType: string; count: bigint }>;

        // Convert BigInt to Number for JSON serialization
        const locationTypeStats = locationTypeStatsRaw.map(item => ({
            locationType: item.locationType,
            count: Number(item.count)
        }));

        return NextResponse.json({
            summary: {
                totalTickets,
                completedTickets,
                pendingTickets,
                completionRate,
                inProgressTickets: statusCounts.find(s => s.status === 'IN_PROGRESS')?._count?.status || 0,
                assignedTickets: statusCounts.find(s => s.status === 'ASSIGNED')?._count?.status || 0,
            },
            statusCounts: statusCounts.map(s => ({
                status: s.status,
                count: s._count.status
            })),
            priorityCounts: priorityCounts.map(p => ({
                priority: p.priority,
                count: p._count.priority
            })),
            topLocations: locationStats.map(l => ({
                location: l.location,
                count: l._count.location
            })),
            topStaff,
            monthlyStats: Object.entries(monthlyStats).map(([month, data]) => ({
                month,
                ...data
            })),
            dailyStats: Object.entries(dailyStats).map(([date, data]) => ({
                date,
                ...data
            })),
            locationTypeStats
        });

    } catch (error) {
        console.error("Error fetching technical stats:", error);
        return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
    }
}

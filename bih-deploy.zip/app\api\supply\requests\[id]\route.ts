import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

function canManageSupply(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SUPPLY' && ['MANAGER', 'LEADER'].includes(user.position)) return true;
    return false;
}

export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const requestDetail = await prisma.supplyRequest.findUnique({
            where: { id: parseInt(params.id) },
            include: { assignedTo: { select: { id: true, fullName: true } } }
        });

        if (!requestDetail) return NextResponse.json({ error: "Not found" }, { status: 404 });

        return NextResponse.json(requestDetail);
    } catch (error) {
        return NextResponse.json({ error: "Server Error" }, { status: 500 });
    }
}

export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        // Allow SUPPLY staff to update status, but only Managers to edit details?
        // User requested "edit" endpoint. We'll allow basic edits for now.
        if (user.role !== 'SUPPLY' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const body = await request.json();
        const { status, assignedToId, itemName, quantity, urgency, inventoryId, fulfill } = body;

        // Special handling for Fulfillment (Supply from Inventory)
        if (fulfill) {
            const req = await prisma.supplyRequest.findUnique({
                where: { id: parseInt(params.id) },
                include: { inventory: true }
            });

            if (!req) return NextResponse.json({ error: "Request not found" }, { status: 404 });
            if (!req.inventoryId) return NextResponse.json({ error: "No inventory item linked to this request" }, { status: 400 });
            // Check stock (InventoryItem might be null if ID exists but item deleted, though referential integrity usually prevents this)
            // Using req.inventory object
            if (!req.inventory) return NextResponse.json({ error: "Linked inventory item not found" }, { status: 404 });

            if (req.inventory.quantity < req.quantity) {
                return NextResponse.json({ error: `Not enough stock. Available: ${req.inventory.quantity}` }, { status: 400 });
            }

            // Ensure userId is an number
            const userId = parseInt(String(user.id));

            // Execute Transaction
            await prisma.$transaction([
                prisma.inventoryItem.update({
                    where: { id: req.inventory.id },
                    data: { quantity: { decrement: req.quantity } }
                }),
                prisma.inventoryTransaction.create({
                    data: {
                        inventoryId: req.inventory.id,
                        type: 'EXPORT',
                        quantity: req.quantity,
                        reason: `Cấp phát cho yêu cầu #${req.id} (${req.requester})`,
                        performedById: userId,
                        referenceId: `REQ-${req.id}`
                    }
                }),
                prisma.supplyRequest.update({
                    where: { id: req.id },
                    data: { status: 'COMPLETED' }
                })
            ]);

            return NextResponse.json({ success: true, message: "Fulfilled successfully" });
        }

        const updated = await prisma.supplyRequest.update({
            where: { id: parseInt(params.id) },
            data: {
                status,
                assignedToId: assignedToId ? parseInt(assignedToId) : undefined,
                itemName,
                quantity: quantity ? parseInt(quantity) : undefined,
                unit: body.unit,
                urgency,
                inventoryId: inventoryId ? parseInt(inventoryId) : undefined
            }
        });

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Supply Request Update Error:", error);
        return NextResponse.json({ error: `Update failed: ${(error as Error).message}` }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!canManageSupply(user)) {
            return NextResponse.json({ error: "Permission denied: Manager only" }, { status: 403 });
        }

        await prisma.supplyRequest.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Delete failed" }, { status: 500 });
    }
}

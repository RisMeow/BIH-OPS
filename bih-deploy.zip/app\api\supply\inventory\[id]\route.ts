import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// PATCH: Update Inventory Item
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();

        // Remove Transaction-specific fields if they exist, we only update Item details here
        // (Quantity is managed via transactions)
        const { quantity, ...updateData } = body;

        const updatedItem = await prisma.inventoryItem.update({
            where: { id },
            data: updateData
        });

        return NextResponse.json(updatedItem);
    } catch (error: any) {
        console.error("Update Inventory Item Error:", error);
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'Mã SKU đã tồn tại' }, { status: 400 });
        }
        return NextResponse.json({ error: error.message || 'Error updating item' }, { status: 500 });
    }
}

// DELETE: Delete Inventory Item
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);

        // Optional: Check if item has transactions? 
        // For now, allow delete. Prisma will likely fail if foreign keys (InventoryTransaction) exist 
        // unless cascade delete is on. 
        // Checking schema first would be good, but user wants functionality.
        // Usually, we should prevent deleting if transactions exist, or soft delete.
        // Let's try simple delete first.

        await prisma.inventoryItem.delete({
            where: { id }
        });

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error("Delete Inventory Item Error:", error);
        // P2003 is Foreign Key constraint failed
        if (error.code === 'P2003') {
            return NextResponse.json({ error: 'Không thể xóa vật tư đã có giao dịch kho' }, { status: 400 });
        }
        return NextResponse.json({ error: error.message || 'Error deleting item' }, { status: 500 });
    }
}

"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
    SendHorizontal, Wrench, HeartHandshake, Truck, ShieldAlert,
    Package, Leaf, CheckCircle, Loader2, AlertTriangle,
    MapPin, FileText, Clock, X, ChevronRight, Accessibility, Bed, Stethoscope, Users, Siren
} from "lucide-react";
import { clsx } from "clsx";
import LocationSelector from "@/app/components/LocationSelector";
import { useLanguage } from "@/app/context/LanguageContext";

interface RequestForm {
    department: string;
    title: string;
    description: string;
    location: string;
    priority: string;
}

export default function RequestPage() {
    const { t } = useLanguage();
    const { data: session } = useSession();
    const [selectedDept, setSelectedDept] = useState<string | null>(null);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(false);

    const [nursingMode, setNursingMode] = useState<'GENERAL' | 'TRANSPORT'>('GENERAL');
    const [form, setForm] = useState<RequestForm & {
        patientName?: string;
        destination?: string;
        transportMode?: string;
        pickupTime?: string;
        passengerCount?: number;
        tripType?: string;
        phoneNumber?: string;
        incidentType?: string;
        severity?: string;
        itemName?: string;
        unit?: string;
        category?: string;
        quantity?: number;
        taskType?: string;
    }>({
        department: "",
        title: "",
        description: "",
        location: "",
        priority: "MEDIUM",
        transportMode: "WHEELCHAIR",
        passengerCount: 1,
        tripType: "ONE_WAY",
        incidentType: "SUSPICIOUS",
        severity: "LOW",
        quantity: 1,
        unit: "Cái",
        category: "OFFICE",
        taskType: "CLEANING"
    });

    // Define departments inside component to use translations
    const departments = [
        {
            id: "TECHNICAL",
            name: t.request.deptTechnical,
            icon: Wrench,
            color: "bg-blue-500",
            lightColor: "bg-blue-50 text-blue-600 border-blue-200",
            description: t.request.descTechnical,
            examples: ["Điều hòa hỏng", "Bóng đèn cháy", "Ống nước rỉ", "Cửa kẹt"]
        },
        {
            id: "NURSING",
            name: t.request.deptNursing,
            icon: HeartHandshake,
            color: "bg-pink-500",
            lightColor: "bg-pink-50 text-pink-600 border-pink-200",
            description: t.request.descNursing,
            examples: ["Vệ sinh buồng bệnh", "Vận chuyển BN", "Đổi đồ vải"]
        },
        {
            id: "DRIVER",
            name: t.request.deptDriver,
            icon: Truck,
            color: "bg-amber-500",
            lightColor: "bg-amber-50 text-amber-600 border-amber-200",
            description: t.request.descDriver,
            examples: ["Đặt xe đưa đón", "Xe cấp cứu", "Vận chuyển vật tư"]
        },
        {
            id: "SECURITY",
            name: t.request.deptSecurity,
            icon: ShieldAlert,
            color: "bg-red-500",
            lightColor: "bg-red-50 text-red-600 border-red-200",
            description: t.request.descSecurity,
            examples: ["Gây rối trật tự", "Mất đồ", "Người lạ đáng ngờ"]
        },
        {
            id: "SUPPLY",
            name: t.request.deptSupply,
            icon: Package,
            color: "bg-emerald-500",
            lightColor: "bg-emerald-50 text-emerald-600 border-emerald-200",
            description: t.request.descSupply,
            examples: ["Cần bóng đèn", "Thiếu găng tay", "Dụng cụ vệ sinh"]
        },
        {
            id: "ENVIRONMENT",
            name: t.request.deptEnvironment,
            icon: Leaf,
            color: "bg-teal-500",
            lightColor: "bg-teal-50 text-teal-600 border-teal-200",
            description: t.request.descEnvironment,
            examples: ["Thu gom rác y tế", "Chăm sóc cây", "Mùi hôi"]
        },
    ];

    const priorities = [
        { id: "LOW", label: t.technical.priorityLow, color: "bg-slate-100 text-slate-600" },
        { id: "MEDIUM", label: t.technical.priorityMedium, color: "bg-blue-100 text-blue-600" },
        { id: "HIGH", label: t.technical.priorityHigh, color: "bg-amber-100 text-amber-600" },
        { id: "URGENT", label: t.technical.priorityUrgent, color: "bg-red-100 text-red-600" },
    ];

    const handleSelectDept = (deptId: string) => {
        setSelectedDept(deptId);
        setForm({ ...form, department: deptId, title: "", description: "", location: "", patientName: "", destination: "" });
        setNursingMode('GENERAL'); // Reset
        setIsFormOpen(true);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);

        // Client-side validation
        if (form.department === 'NURSING' && nursingMode === 'TRANSPORT') {
            if (!form.patientName || !form.location || !form.destination) {
                alert(t.request.errors.missingNursing);
                setSubmitting(false);
                return;
            }
        } else if (form.department === 'SECURITY') {
            if (!form.location || !form.description) {
                alert(t.request.errors.missingSecurity);
                setSubmitting(false);
                return;
            }
        }

        try {
            let apiEndpoint = getApiEndpoint(form.department);
            let payload: any = {};

            if (form.department === 'NURSING') {
                if (nursingMode === 'TRANSPORT') {
                    apiEndpoint = '/api/nursing/transport';
                    payload = {
                        patientName: form.patientName,
                        fromLocation: form.location,
                        toLocation: form.destination,
                        transportMode: form.transportMode,
                        priority: form.priority === 'URGENT' ? 'URGENT' : 'NORMAL',
                        notes: form.description,
                        requestedBy: session?.user?.name
                    };
                } else {
                    apiEndpoint = '/api/nursing/requests';
                    payload = {
                        roomNumber: form.location,
                        requestType: form.title,
                        description: form.description,
                        priority: form.priority,
                        status: "PENDING"
                    };
                }
            } else if (form.department === 'DRIVER') {
                apiEndpoint = '/api/driver/requests';
                payload = {
                    passengerName: form.patientName || session?.user?.name,
                    department: t.request.deptDriver, // Used readable name for department
                    destination: form.destination,
                    pickupLocation: form.location,
                    pickupTime: form.pickupTime ? new Date(form.pickupTime).toISOString() : new Date().toISOString(),
                    passengerCount: Number(form.passengerCount) || 1,
                    tripType: form.tripType || "ONE_WAY",
                    purpose: form.description || form.title,
                    note: form.description,
                    status: 'PENDING',
                    requestedBy: session?.user?.name
                };
            } else if (form.department === 'SECURITY') {
                apiEndpoint = '/api/security/requests';
                payload = {
                    location: form.location,
                    incidentType: form.incidentType || 'SUSPICIOUS',
                    description: form.description,
                    severity: form.priority === 'URGENT' ? 'CRITICAL' : (form.priority === 'HIGH' ? 'HIGH' : (form.priority === 'MEDIUM' ? 'MEDIUM' : 'LOW')),
                };
            } else if (form.department === 'SUPPLY') {
                if (!form.itemName || !form.quantity) {
                    alert(t.request.errors.missingSupply);
                    setSubmitting(false);
                    return;
                }
                apiEndpoint = '/api/supply/requests';
                payload = {
                    itemName: form.itemName,
                    category: form.category || 'GENERAL',
                    quantity: Number(form.quantity) || 1,
                    unit: form.unit || 'Cái',
                    urgency: form.priority === 'URGENT' ? 'URGENT' : (form.priority === 'HIGH' ? 'HIGH' : 'NORMAL'),
                    requester: `${session?.user?.name}${form.location ? ` - ${form.location}` : ''} ${form.description ? `(${form.description})` : ''}`,
                };
            } else if (form.department === 'ENVIRONMENT') {
                if (!form.location || !form.taskType) {
                    alert(t.request.errors.missingEnvironment);
                    setSubmitting(false);
                    return;
                }
                apiEndpoint = '/api/environment/requests';
                payload = {
                    location: form.location,
                    taskType: form.taskType || 'CLEANING',
                    description: form.description
                };
            } else {
                // Generic logic
                payload = {
                    title: form.title,
                    description: form.description,
                    location: form.location,
                    priority: form.priority,
                    status: "PENDING",
                    requestedBy: session?.user?.name,
                    requestedById: session?.user?.id,
                };
            }

            const res = await fetch(apiEndpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                setSuccess(true);
                setForm({
                    department: "",
                    title: "",
                    description: "",
                    location: "",
                    priority: "MEDIUM",
                    patientName: "",
                    destination: ""
                });
            } else {
                const data = await res.json();
                alert(data.error || t.request.errors.submitError);
            }
        } catch (error) {
            console.error(error);
            alert(t.request.errors.connectionError);
        } finally {
            setSubmitting(false);
        }
    };

    const getApiEndpoint = (dept: string): string => {
        switch (dept) {
            case "TECHNICAL": return "/api/technical/requests";
            case "NURSING": return "/api/nursing/requests";
            case "DRIVER": return "/api/driver/requests";
            case "SECURITY": return "/api/security/requests";
            case "SUPPLY": return "/api/supply/requests";
            case "ENVIRONMENT": return "/api/environment/requests";
            default: return "/api/technical/requests";
        }
    };

    const selectedDeptInfo = departments.find(d => d.id === selectedDept);

    return (
        <div className="max-w-6xl mx-auto space-y-8">
            {/* Header */}
            <div className="text-center">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="inline-flex items-center gap-3 mb-4"
                >
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                        <SendHorizontal className="text-white" size={28} />
                    </div>
                </motion.div>
                <h1 className="text-3xl font-black text-slate-800 mb-2">{t.request.title}</h1>
                <p className="text-slate-500 max-w-lg mx-auto">
                    {t.request.subtitle}
                </p>
            </div>

            {/* Department Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {departments.map((dept, index) => (
                    <motion.div
                        key={dept.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() => handleSelectDept(dept.id)}
                        className={clsx(
                            "bg-white rounded-2xl p-5 border-2 cursor-pointer transition-all hover:shadow-xl hover:-translate-y-1 group",
                            selectedDept === dept.id ? "border-emerald-500 shadow-lg" : "border-slate-100 hover:border-slate-200"
                        )}
                    >
                        <div className="flex items-start gap-4">
                            <div className={clsx("w-12 h-12 rounded-xl flex items-center justify-center text-white shrink-0", dept.color)}>
                                <dept.icon size={24} />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-slate-800 group-hover:text-emerald-600 transition-colors flex items-center gap-2">
                                    {dept.name}
                                    <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                                </h3>
                                <p className="text-sm text-slate-500 mt-1">{dept.description}</p>
                                <div className="mt-3 flex flex-wrap gap-1.5">
                                    {dept.examples.slice(0, 3).map((ex, i) => (
                                        <span key={i} className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full">
                                            {ex}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>

            {/* Request Form Modal */}
            <AnimatePresence>
                {isFormOpen && selectedDeptInfo && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
                        >
                            {/* Modal Header */}
                            <div className={clsx("p-5 text-white", selectedDeptInfo.color)}>
                                <div className="flex justify-between items-start">
                                    <div className="flex items-center gap-3">
                                        <selectedDeptInfo.icon size={28} />
                                        <div>
                                            <h3 className="font-bold text-lg">{selectedDeptInfo.name}</h3>
                                            <p className="text-sm opacity-80">{t.request.subtitle}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => { setIsFormOpen(false); setSelectedDept(null); }} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
                                        <X size={20} />
                                    </button>
                                </div>
                                {selectedDept === 'NURSING' && (
                                    <div className="flex bg-white/20 p-1 rounded-xl mt-4">
                                        <button
                                            onClick={() => setNursingMode('GENERAL')}
                                            className={clsx(
                                                "flex-1 py-1.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                nursingMode === 'GENERAL' ? "bg-white text-pink-600 shadow-sm" : "text-white hover:bg-white/10"
                                            )}
                                        >
                                            <Wrench size={16} /> Vệ sinh / Khác
                                        </button>
                                        <button
                                            onClick={() => setNursingMode('TRANSPORT')}
                                            className={clsx(
                                                "flex-1 py-1.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                nursingMode === 'TRANSPORT' ? "bg-white text-pink-600 shadow-sm" : "text-white hover:bg-white/10"
                                            )}
                                        >
                                            <Accessibility size={16} /> {t.orderly.taskTransport}
                                        </button>
                                    </div>
                                )}
                            </div>

                            {/* Success State */}
                            {success ? (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="p-10 text-center"
                                >
                                    <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                                        <CheckCircle className="text-emerald-600" size={40} />
                                    </div>
                                    <h4 className="text-xl font-bold text-slate-800 mb-2">{t.common.success}!</h4>
                                    <p className="text-slate-500 mb-6">{t.request.successMessage} {selectedDeptInfo.name}</p>
                                    <div className="flex justify-center gap-3">
                                        <button
                                            onClick={() => window.location.href = `/dashboard/${selectedDeptInfo.id.toLowerCase()}`}
                                            className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-lg hover:bg-slate-200 transition-colors"
                                        >
                                            {t.request.goToDashboard}
                                        </button>
                                        <button
                                            onClick={() => {
                                                setSuccess(false);
                                                setIsFormOpen(false);
                                                setSelectedDept(null);
                                            }}
                                            className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 transition-colors"
                                        >
                                            {t.request.btnClose}
                                        </button>
                                    </div>
                                </motion.div>
                            ) : (
                                /* Form */
                                <form onSubmit={handleSubmit} className="p-5 space-y-4">
                                    {/* Generic Fields */}
                                    {(selectedDept !== 'NURSING' || nursingMode === 'GENERAL') && selectedDept !== 'DRIVER' && selectedDept !== 'SECURITY' && selectedDept !== 'SUPPLY' && selectedDept !== 'ENVIRONMENT' ? (
                                        <>
                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <FileText size={14} /> {selectedDept === 'NURSING' ? t.orderly.colTask : t.technical.incidentTitle} <span className="text-red-500">*</span>
                                                </label>
                                                <input
                                                    required
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                                                    placeholder="VD: Điều hòa phòng 301 không lạnh..."
                                                    value={form.title}
                                                    onChange={e => setForm({ ...form, title: e.target.value })}
                                                />
                                            </div>

                                            <LocationSelector
                                                label={t.technical.location}
                                                value={form.location}
                                                onChange={(val) => setForm({ ...form, location: val })}
                                            />

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <Clock size={14} /> {t.common.priority}
                                                </label>
                                                <div className="grid grid-cols-4 gap-2">
                                                    {priorities.map(p => (
                                                        <button
                                                            key={p.id}
                                                            type="button"
                                                            onClick={() => setForm({ ...form, priority: p.id })}
                                                            className={clsx(
                                                                "py-2 px-3 rounded-lg text-sm font-bold border-2 transition-all",
                                                                form.priority === p.id
                                                                    ? `${p.color} border-current`
                                                                    : "bg-slate-50 text-slate-400 border-transparent hover:bg-slate-100"
                                                            )}
                                                        >
                                                            {p.label}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 block">
                                                    {t.common.description}
                                                </label>
                                                <textarea
                                                    rows={4}
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all resize-none"
                                                    placeholder={t.environment.placeholderNote}
                                                    value={form.description}
                                                    onChange={e => setForm({ ...form, description: e.target.value })}
                                                />
                                            </div>
                                        </>
                                    ) : selectedDept === 'DRIVER' ? (
                                        /* DRIVER SPECIFIC FIELDS */
                                        <>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <Users size={14} /> {t.orderly.colPatient} / Tên khách
                                                    </label>
                                                    <input
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none"
                                                        value={form.patientName}
                                                        onChange={e => setForm({ ...form, patientName: e.target.value })}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <Users size={14} /> {t.supply.colQuantity} (Người)
                                                    </label>
                                                    <input
                                                        type="number"
                                                        min={1}
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none"
                                                        value={form.passengerCount}
                                                        onChange={e => setForm({ ...form, passengerCount: parseInt(e.target.value) })}
                                                    />
                                                </div>
                                            </div>

                                            <div className="grid grid-cols-2 gap-4">
                                                <LocationSelector
                                                    label="Điểm đón"
                                                    value={form.location}
                                                    onChange={(val) => setForm({ ...form, location: val })}
                                                />
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <MapPin size={14} /> Điểm đến <span className="text-red-500">*</span>
                                                    </label>
                                                    <input
                                                        required
                                                        className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                                                        value={form.destination}
                                                        onChange={e => setForm({ ...form, destination: e.target.value })}
                                                    />
                                                </div>
                                            </div>

                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <Clock size={14} /> Giờ đón <span className="text-red-500">*</span>
                                                    </label>
                                                    <input
                                                        type="datetime-local"
                                                        lang="en-GB"
                                                        required
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none"
                                                        value={form.pickupTime}
                                                        onChange={e => setForm({ ...form, pickupTime: e.target.value })}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 block">Loại chuyến</label>
                                                    <select
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none bg-white"
                                                        value={form.tripType}
                                                        onChange={e => setForm({ ...form, tripType: e.target.value })}
                                                    >
                                                        <option value="ONE_WAY">Một chiều</option>
                                                        <option value="ROUND_TRIP">Khứ hồi</option>
                                                        <option value="EMERGENCY">Cấp cứu</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 block">{t.common.description}</label>
                                                <textarea
                                                    rows={2}
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all resize-none"
                                                    value={form.description}
                                                    onChange={e => setForm({ ...form, description: e.target.value })}
                                                />
                                            </div>
                                        </>
                                    ) : selectedDept === 'SECURITY' ? (
                                        /* SECURITY SPECIFIC FIELDS */
                                        <>
                                            <div className="bg-red-50 border border-red-100 rounded-xl p-3 mb-4 flex items-start gap-3">
                                                <ShieldAlert className="text-red-600 shrink-0 mt-0.5" size={20} />
                                                <div className="text-sm text-red-700">
                                                    <p className="font-bold">{t.request.deptSecurity}</p>
                                                    <p>{t.request.descSecurity}</p>
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <Siren size={14} /> Loại sự cố <span className="text-red-500">*</span>
                                                </label>
                                                <select
                                                    className="w-full p-3 border border-slate-200 rounded-xl outline-none bg-white"
                                                    value={form.incidentType}
                                                    onChange={e => setForm({ ...form, incidentType: e.target.value })}
                                                >
                                                    <option value="SUSPICIOUS">Đối tượng khả nghi</option>
                                                    <option value="THEFT">Trộm cắp / Mất đồ</option>
                                                    <option value="FIGHT">Gây rối / Xô xát</option>
                                                    <option value="ACCESS_CONTROL">Vi phạm ra vào</option>
                                                    <option value="OTHER">Khác</option>
                                                </select>
                                            </div>

                                            <LocationSelector
                                                label={t.technical.location}
                                                value={form.location}
                                                onChange={(val) => setForm({ ...form, location: val })}
                                            />

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <AlertTriangle size={14} /> {t.common.priority}
                                                </label>
                                                <div className="grid grid-cols-4 gap-2">
                                                    {priorities.map(p => (
                                                        <button
                                                            key={p.id}
                                                            type="button"
                                                            onClick={() => setForm({ ...form, priority: p.id })}
                                                            className={clsx(
                                                                "py-2 px-3 rounded-lg text-sm font-bold border-2 transition-all",
                                                                form.priority === p.id
                                                                    ? `${p.color} border-current`
                                                                    : "bg-slate-50 text-slate-400 border-transparent hover:bg-slate-100"
                                                            )}
                                                        >
                                                            {p.label}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 block">
                                                    {t.common.description} <span className="text-red-500">*</span>
                                                </label>
                                                <textarea
                                                    rows={4}
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition-all resize-none"
                                                    value={form.description}
                                                    onChange={e => setForm({ ...form, description: e.target.value })}
                                                />
                                            </div>
                                        </>

                                    ) : selectedDept === 'SUPPLY' ? (
                                        /* SUPPLY SPECIFIC FIELDS */
                                        <>
                                            <div className="bg-orange-50 border border-orange-100 rounded-xl p-3 mb-4 flex items-start gap-3">
                                                <Package className="text-orange-600 shrink-0 mt-0.5" size={20} />
                                                <div className="text-sm text-orange-700">
                                                    <p className="font-bold">{t.request.deptSupply}</p>
                                                    <p>{t.request.descSupply}</p>
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <Package size={14} /> {t.supply.colName} <span className="text-red-500">*</span>
                                                </label>
                                                <input
                                                    required
                                                    className="w-full p-3 border border-slate-200 rounded-xl outline-none"
                                                    value={form.itemName}
                                                    onChange={e => setForm({ ...form, itemName: e.target.value })}
                                                />
                                            </div>

                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <Users size={14} /> {t.supply.colQuantity} <span className="text-red-500">*</span>
                                                    </label>
                                                    <input
                                                        type="number"
                                                        min={1}
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none"
                                                        value={form.quantity}
                                                        onChange={e => setForm({ ...form, quantity: parseInt(e.target.value) })}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 block">Đơn vị tính</label>
                                                    <input
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none list-none"
                                                        list="unit-suggestions"
                                                        value={form.unit}
                                                        onChange={e => setForm({ ...form, unit: e.target.value })}
                                                    />
                                                    <datalist id="unit-suggestions">
                                                        <option value="Cái" />
                                                        <option value="Hộp" />
                                                        <option value="Thùng" />
                                                        <option value="Ram" />
                                                        <option value="Kg" />
                                                        <option value="Lít" />
                                                        <option value="Cuộn" />
                                                    </datalist>
                                                </div>
                                            </div>

                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 block">{t.supply.colCategory}</label>
                                                    <select
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none bg-white"
                                                        value={form.category}
                                                        onChange={e => setForm({ ...form, category: e.target.value })}
                                                    >
                                                        <option value="OFFICE">{t.supply.catOffice}</option>
                                                        <option value="MEDICAL">{t.supply.catMedical}</option>
                                                        <option value="TECHNICAL">Kỹ thuật</option>
                                                        <option value="CLEANING">Vệ sinh</option>
                                                        <option value="GENERAL">Khác</option>
                                                    </select>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                        <AlertTriangle size={14} /> {t.common.priority}
                                                    </label>
                                                    <select
                                                        className="w-full p-3 border border-slate-200 rounded-xl outline-none bg-white font-bold text-slate-600"
                                                        value={form.priority}
                                                        onChange={e => setForm({ ...form, priority: e.target.value })}
                                                    >
                                                        <option value="MEDIUM">{t.technical.priorityMedium}</option>
                                                        <option value="HIGH">{t.technical.priorityHigh}</option>
                                                        <option value="URGENT">{t.technical.priorityUrgent}</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <LocationSelector
                                                label={t.technical.location}
                                                value={form.location}
                                                onChange={(val) => setForm({ ...form, location: val })}
                                            />

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 block">
                                                    {t.common.description}
                                                </label>
                                                <textarea
                                                    rows={2}
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all resize-none"
                                                    value={form.description}
                                                    onChange={e => setForm({ ...form, description: e.target.value })}
                                                />
                                            </div>
                                        </>

                                    ) : selectedDept === 'ENVIRONMENT' ? (
                                        /* ENVIRONMENT SPECIFIC FIELDS */
                                        <>
                                            <div className="bg-teal-50 border border-teal-100 rounded-xl p-3 mb-4 flex items-start gap-3">
                                                <Leaf className="text-teal-600 shrink-0 mt-0.5" size={20} />
                                                <div className="text-sm text-teal-700">
                                                    <p className="font-bold">{t.request.deptEnvironment}</p>
                                                    <p>{t.request.descEnvironment}</p>
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 flex items-center gap-2">
                                                    <Wrench size={14} /> {t.environment.labelType} <span className="text-red-500">*</span>
                                                </label>
                                                <select
                                                    className="w-full p-3 border border-slate-200 rounded-xl outline-none bg-white"
                                                    value={form.taskType}
                                                    onChange={e => setForm({ ...form, taskType: e.target.value })}
                                                >
                                                    <option value="CLEANING">{t.environment.typeRoutine}</option>
                                                    <option value="WASTE">{t.environment.typeWaste}</option>
                                                    <option value="LANDSCAPE">{t.environment.typeLandscape}</option>
                                                    <option value="PEST_CONTROL">Diệt côn trùng</option>
                                                    <option value="REPAIR">Sửa chữa nhỏ (Môi trường)</option>
                                                    <option value="OTHER">{t.environment.labelType} Khác</option>
                                                </select>
                                            </div>

                                            <LocationSelector
                                                label={t.environment.labelArea}
                                                value={form.location}
                                                onChange={(val) => setForm({ ...form, location: val })}
                                            />

                                            <div>
                                                <label className="text-sm font-bold text-slate-700 mb-1.5 block">
                                                    {t.common.description}
                                                </label>
                                                <textarea
                                                    rows={4}
                                                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all resize-none"
                                                    placeholder={t.environment.placeholderNote}
                                                    value={form.description}
                                                    onChange={e => setForm({ ...form, description: e.target.value })}
                                                />
                                            </div>
                                        </>
                                    ) : null}

                                    <div className="flex justify-end pt-4 gap-2">
                                        <button
                                            type="button"
                                            onClick={() => setIsFormOpen(false)}
                                            className="px-5 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-bold transition-all"
                                        >
                                            {t.common.cancel}
                                        </button>
                                        <button
                                            type="submit"
                                            disabled={submitting}
                                            className={clsx(
                                                "px-6 py-2.5 rounded-xl text-white font-bold shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/30 transition-all flex items-center gap-2",
                                                submitting ? "opacity-70 cursor-not-allowed" : "",
                                                selectedDeptInfo.color.split(" ")[0] // Use dept bg color
                                            )}
                                        >
                                            {submitting && <Loader2 className="animate-spin" size={20} />}
                                            {t.request.btnSend}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

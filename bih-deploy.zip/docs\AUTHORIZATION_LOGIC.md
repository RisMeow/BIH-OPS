# AUTHORIZATION & PERMISSION LOGIC - BIH Administrative Management

## Tổng quan Hệ thống Phân quyền

### 1. Cấu trúc Role (Vai trò)

| Role | Mô tả | Quyền truy cập Dashboard |
|------|-------|-------------------------|
| `ADMIN` | Quản trị viên hệ thống | Tất cả các module |
| `TECHNICAL` | Tổ Kỹ thuật vận hành | `/dashboard/technical` |
| `NURSING` | Tổ Điều dưỡng/Hộ lý | `/dashboard/nursing` |
| `DRIVER` | Tổ Tài xế | `/dashboard/driver` |
| `SECURITY` | Tổ An ninh | `/dashboard/security` |
| `SUPPLY` | Tổ Cung ứng | `/dashboard/supply` |
| `ENVIRONMENT` | Tổ Môi trường | `/dashboard/environment` |

### 2. Cấu trúc Position (Chức vụ)

| Position | Mô tả | Quyền hạn |
|----------|-------|-----------|
| `MANAGER` | Quản lý cao nhất | Duyệt tất cả, phân công |
| `LEADER` | Tổ trưởng | Phân công, duyệt trong tổ |
| `SUPERVISOR` | Giám sát | Phân công, duyệt (tùy module) |
| `STAFF` | Nhân viên | Thực hiện công việc được phân |

---

## 3. Ma trận Phân quyền theo Module

### 3.1 Technical (Kỹ thuật)

| Hành động | ADMIN | TECHNICAL LEADER | TECHNICAL STAFF | Khoa phòng khác |
|-----------|-------|------------------|-----------------|-----------------|
| Xem danh sách yêu cầu | ✅ | ✅ | ✅ | ✅ |
| Tạo yêu cầu mới | ✅ | ✅ | ✅ | ✅ |
| Phân công người xử lý | ✅ | ✅ | ❌ | ❌ |
| Cập nhật trạng thái IN_PROGRESS | ✅ | ✅ | ✅ (nếu được phân) | ❌ |
| Đánh dấu COMPLETED | ✅ | ✅ | ✅ (nếu được phân) | ❌ |
| Duyệt (APPROVED) | ✅ | ✅ | ❌ | ❌ |
| Từ chối (REJECTED) | ✅ | ✅ | ❌ | ❌ |
| Xóa yêu cầu | ✅ | ✅ | ❌ | ❌ |

### 3.2 Driver (Tài xế)

| Hành động | ADMIN | DRIVER LEADER | DRIVER STAFF | Khoa phòng khác |
|-----------|-------|---------------|--------------|-----------------|
| Xem danh sách yêu cầu | ✅ | ✅ | ✅ | ✅ |
| Đặt xe (Tạo yêu cầu) | ✅ | ✅ | ✅ | ✅ |
| Phân công tài xế | ✅ | ✅ | ❌ | ❌ |
| Hoàn thành chuyến | ✅ | ✅ | ✅ (nếu được phân) | ❌ |
| Hủy yêu cầu | ✅ | ✅ | ❌ | ❌ |

### 3.3 Security (An ninh)

| Hành động | ADMIN | SECURITY LEADER | SECURITY STAFF | Khoa phòng khác |
|-----------|-------|-----------------|----------------|-----------------|
| Xem báo cáo sự cố | ✅ | ✅ | ✅ | ✅ (chỉ xem) |
| Báo cáo sự cố mới | ✅ | ✅ | ✅ | ✅ |
| Phân công xử lý | ✅ | ✅ | ❌ | ❌ |
| Đóng sự cố (CLOSED) | ✅ | ✅ | ✅ (nếu được phân) | ❌ |

### 3.4 Supply (Cung ứng)

#### 3.4.1 Yêu cầu vật tư lẻ (Supply Requests)

| Hành động | ADMIN | SUPPLY LEADER | SUPPLY STAFF | Khoa phòng khác |
|-----------|-------|---------------|--------------|-----------------|
| Xem danh sách | ✅ | ✅ | ✅ | ✅ |
| Tạo yêu cầu | ✅ | ✅ | ✅ | ✅ |
| Phân công xử lý | ✅ | ✅ | ❌ | ❌ |
| Duyệt yêu cầu | ✅ | ✅ | ❌ | ❌ |

#### 3.4.2 Phiếu Dự trù mua sắm (Procurement Plans)

| Hành động | ADMIN | SUPPLY LEADER | SUPPLY STAFF | Khoa phòng khác |
|-----------|-------|---------------|--------------|-----------------|
| Xem danh sách phiếu | ✅ | ✅ | ✅ | ❌ |
| Lập phiếu dự trù mới | ✅ | ✅ | ✅ | ❌ |
| Duyệt phiếu (APPROVED) | ✅ | ✅ | ❌ | ❌ |
| In phiếu đã duyệt | ✅ | ✅ | ✅ | ❌ |
| Xóa phiếu nháp | ✅ | ✅ | ✅ (nếu là người tạo) | ❌ |

### 3.5 Environment (Môi trường)

| Hành động | ADMIN | ENVIRONMENT LEADER | ENVIRONMENT STAFF | Khoa phòng khác |
|-----------|-------|-------------------|-------------------|-----------------|
| Xem danh sách | ✅ | ✅ | ✅ | ✅ |
| Tạo yêu cầu vệ sinh | ✅ | ✅ | ✅ | ✅ |
| Phân công | ✅ | ✅ | ❌ | ❌ |
| Hoàn thành | ✅ | ✅ | ✅ (nếu được phân) | ❌ |

---

## 4. Flow Trạng thái Công việc

```
┌─────────┐    Phân công     ┌──────────┐    Bắt đầu    ┌─────────────┐
│ PENDING │ ───────────────► │ ASSIGNED │ ────────────► │ IN_PROGRESS │
└─────────┘                  └──────────┘               └─────────────┘
     │                                                        │
     │ Hủy                                              Hoàn thành
     ▼                                                        │
┌───────────┐                                                 ▼
│ CANCELLED │                                          ┌───────────┐
└───────────┘                                          │ COMPLETED │
                                                       └───────────┘
                                                             │
                                        ┌────────────────────┼────────────────────┐
                                        │                    │                    │
                                        ▼                    ▼                    ▼
                                  ┌──────────┐        ┌──────────┐         ┌──────────┐
                                  │ APPROVED │        │ REJECTED │         │  ON_HOLD │
                                  └──────────┘        └──────────┘         └──────────┘
```

### Quy tắc chuyển trạng thái:

| Từ trạng thái | Có thể chuyển sang | Ai được phép? |
|---------------|-------------------|---------------|
| PENDING | ASSIGNED, CANCELLED | Leader |
| ASSIGNED | IN_PROGRESS, CANCELLED | Staff được phân hoặc Leader |
| IN_PROGRESS | COMPLETED, ON_HOLD | Staff đang xử lý hoặc Leader |
| ON_HOLD | IN_PROGRESS, CANCELLED | Leader |
| COMPLETED | APPROVED, REJECTED | Leader |
| APPROVED | - | (Trạng thái cuối) |
| REJECTED | PENDING | Leader (mở lại) |
| CANCELLED | - | (Trạng thái cuối) |

---

## 5. Middleware bảo vệ Routes

File: `middleware.ts`

```typescript
// Redirect logic khi truy cập /dashboard
if (path === '/dashboard') {
    switch (role) {
        case 'TECHNICAL': redirect('/dashboard/technical');
        case 'NURSING': redirect('/dashboard/nursing');
        case 'DRIVER': redirect('/dashboard/driver');
        case 'SECURITY': redirect('/dashboard/security');
        case 'SUPPLY': redirect('/dashboard/supply');
        case 'ENVIRONMENT': redirect('/dashboard/environment');
        case 'ADMIN': // Ở lại /dashboard (tổng quan)
    }
}

// Chặn truy cập trái phép
// VD: User TECHNICAL không được vào /dashboard/nursing (trừ ADMIN)
```

---

## 6. API Authorization Helper

File: `lib/auth.ts`

### Các hàm helper chính:

| Hàm | Mô tả |
|-----|-------|
| `getCurrentUser()` | Lấy thông tin user từ session |
| `hasRole(user, roles)` | Kiểm tra user có role chỉ định |
| `isLeaderOrAbove(user)` | Kiểm tra user là Leader/Manager/Supervisor |
| `isAdmin(user)` | Kiểm tra user là ADMIN |
| `canApprove(user, department)` | Kiểm tra user có quyền duyệt trong department |
| `canViewDepartment(user, department)` | Kiểm tra user có quyền xem dữ liệu department |
| `hasPermission(user, permission)` | Kiểm tra quyền cụ thể từ Permission Matrix |
| `canTransitionStatus(current, new)` | Kiểm tra chuyển trạng thái hợp lệ |

---

## 7. Ví dụ Sử dụng trong API

```typescript
// Trong API route
import { getCurrentUser, canApprove } from '@/lib/auth';

export async function PATCH(request: Request, { params }) {
    const user = await getCurrentUser();
    
    // Kiểm tra đăng nhập
    if (!user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    
    // Kiểm tra quyền duyệt
    if (status === 'APPROVED' && !canApprove(user, 'TECHNICAL')) {
        return NextResponse.json({ 
            error: "Permission denied: Only Technical Leader can approve" 
        }, { status: 403 });
    }
    
    // Tiếp tục xử lý...
}
```

---

## 8. Tài khoản Test

| Username | Password | Role | Position |
|----------|----------|------|----------|
| admin | admin123 | ADMIN | MANAGER |
| tech_leader | 123456 | TECHNICAL | LEADER |
| tech_staff1 | 123456 | TECHNICAL | STAFF |
| driver_leader | 123456 | DRIVER | LEADER |
| supply_leader | 123456 | SUPPLY | LEADER |
| ... | ... | ... | ... |

---

*Tài liệu này mô tả logic phân quyền hoàn chỉnh cho hệ thống BIH Administrative Management. Mọi thay đổi về phân quyền cần được cập nhật tại đây và trong file `lib/auth.ts`.*

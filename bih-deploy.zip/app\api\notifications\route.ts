import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    try {
        const notifications = await prisma.notification.findMany({
            where: { userId: parseInt(String(session.user.id)) },
            orderBy: { createdAt: 'desc' },
            take: 20
        });

        // Count unread
        const unreadCount = await prisma.notification.count({
            where: {
                userId: parseInt(String(session.user.id)),
                isRead: false
            }
        });

        return NextResponse.json({ notifications, unreadCount });
    } catch (error) {
        return NextResponse.json({ error: "Server error" }, { status: 500 });
    }
}

export async function PUT(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    try {
        const body = await req.json();

        // Mark all as read
        if (body.action === 'mark_all_read') {
            await prisma.notification.updateMany({
                where: { userId: parseInt(String(session.user.id)), isRead: false },
                data: { isRead: true }
            });
            return NextResponse.json({ success: true });
        }

        // Mark single as read
        if (body.id) {
            await prisma.notification.update({
                where: { id: body.id, userId: parseInt(String(session.user.id)) }, // Ensure ownership
                data: { isRead: true }
            });
            return NextResponse.json({ success: true });
        }

        return NextResponse.json({ error: "Invalid Action" }, { status: 400 });
    } catch (error) {
        return NextResponse.json({ error: "Server error" }, { status: 500 });
    }
}

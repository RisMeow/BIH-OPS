import { NextResponse } from 'next/server';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const data = await prisma.linenExchange.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                handledBy: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(data);
    } catch (error) {
        console.error("Fetch Linen Error:", error);
        return NextResponse.json({ error: 'Error fetching data' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();

        // Basic validation
        if (!body.location || !body.type || !body.items) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newData = await prisma.linenExchange.create({
            data: {
                location: body.location,
                type: body.type, // 'CLEAN_IN' | 'DIRTY_OUT'
                items: JSON.stringify(body.items), // Ensure items are stored as JSON string
                totalWeight: body.totalWeight ? parseFloat(body.totalWeight) : null,
                notes: body.notes,
                handledById: user.id
            },
        });

        return NextResponse.json(newData, { status: 201 });
    } catch (error) {
        console.error("Create Linen Log Error:", error);
        return NextResponse.json({ error: 'Error creating log' }, { status: 500 });
    }
}

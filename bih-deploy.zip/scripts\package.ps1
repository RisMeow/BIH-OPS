$exclude = @('node_modules', '.next', '.git', '.agent', '.vscode', 'tmp', 'local_data', 'bih-deploy.zip')
Get-ChildItem -Path . | Where-Object { $_.Name -notin $exclude } | Compress-Archive -DestinationPath bih-deploy.zip -Force
Write-Host "Package created at bih-deploy.zip"

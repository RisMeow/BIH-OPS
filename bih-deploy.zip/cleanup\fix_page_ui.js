
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // Regex to find the button with disabled={isGeneratingPdf}
    // and replace it with a clean button
    const regex = /<button onClick={handleDownloadPDF} disabled={isGeneratingPdf}[\s\S]*?<\/button>/m;

    const newButton = `<button onClick={handleDownloadPDF} className="px-6 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center gap-2">
                                            <Download size={18} /> PDF
                                        </button>`;

    if (regex.test(content)) {
        content = content.replace(regex, newButton);
        console.log("UI Button fixed.");
        fs.writeFileSync(path, content);
    } else {
        console.log("UI Button not found or already fixed.");
    }

} catch (e) { console.error(e); }

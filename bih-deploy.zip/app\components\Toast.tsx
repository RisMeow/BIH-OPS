import React, { useEffect } from 'react';
import { CheckCircle2, AlertCircle, X, Info } from 'lucide-react';
import { clsx } from "clsx";

export type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
    message: string;
    type: ToastType;
    isVisible: boolean;
    onClose: () => void;
}

export default function Toast({ message, type, isVisible, onClose }: ToastProps) {
    useEffect(() => {
        if (isVisible) {
            const timer = setTimeout(onClose, 3000); // Tự tắt sau 3 giây
            return () => clearTimeout(timer);
        }
    }, [isVisible, onClose]);

    if (!isVisible) return null;

    const icons = {
        success: CheckCircle2,
        error: AlertCircle,
        info: Info
    };
    const Icon = icons[type];

    return (
        <div className={clsx(
            "fixed top-4 right-4 z-[100] flex items-center gap-3 px-4 py-3 rounded-2xl shadow-2xl border transition-all duration-300 transform animate-in slide-in-from-right-8 fade-in",
            type === 'success' && "bg-white border-emerald-100 text-emerald-800 shadow-emerald-500/10",
            type === 'error' && "bg-white border-red-100 text-red-800 shadow-red-500/10",
            type === 'info' && "bg-white border-blue-100 text-blue-800 shadow-blue-500/10"
        )}>
            <div className={clsx(
                "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                type === 'success' && "bg-emerald-100 text-emerald-600",
                type === 'error' && "bg-red-100 text-red-600",
                type === 'info' && "bg-blue-100 text-blue-600"
            )}>
                <Icon size={18} />
            </div>
            <div className="flex-1 min-w-[200px]">
                <h4 className="text-xs font-bold uppercase opacity-70 tracking-wider mb-0.5">
                    {type === 'success' ? 'Thành công' : type === 'error' ? 'Lỗi' : 'Thông báo'}
                </h4>
                <p className="text-sm font-semibold">{message}</p>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-600">
                <X size={18} />
            </button>
        </div>
    );
}

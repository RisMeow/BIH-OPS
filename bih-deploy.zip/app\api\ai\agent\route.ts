import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { GoogleGenerativeAI } from '@google/generative-ai';
import OpenAI from 'openai';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Định nghĩa Tools (Chức năng Agent có thể làm)
const tools = [
    {
        name: "create_maintenance_request",
        description: "Tạo một yêu cầu sửa chữa/bảo trì kỹ thuật (Technical Request). Dùng khi người dùng báo hỏng hóc thiết bị, điện, nước, điều hòa, thang máy, v.v.",
        parameters: {
            type: "object",
            properties: {
                title: {
                    type: "string",
                    description: "Tên ngắn gọn của sự cố. Ví dụ: 'Hỏng máy lạnh phòng 201'"
                },
                description: {
                    type: "string",
                    description: "Mô tả chi tiết sự cố."
                },
                location: {
                    type: "string",
                    description: "Vị trí xảy ra sự cố (Phòng, Khoa, Tầng...)"
                },
                priority: {
                    type: "string",
                    enum: ["LOW", "MEDIUM", "HIGH", "URGENT"],
                    description: "Mức độ ưu tiên. Mặc định là MEDIUM nếu không rõ."
                }
            },
            required: ["title", "description", "location"]
        }
    },
    {
        name: "create_cleaning_request",
        description: "Tạo một yêu cầu vệ sinh (Cleaning/Environment Request). Dùng khi người dùng báo phòng dơ, cần dọn dẹp, thu gom rác, v.v.",
        parameters: {
            type: "object",
            properties: {
                location: {
                    type: "string",
                    description: "Vị trí cần vệ sinh"
                },
                taskType: {
                    type: "string",
                    enum: ["ROUTINE", "DEEP_CLEAN", "SPILLAGE", "WASTE", "OTHER"],
                    description: "Loại công việc. Nếu là dơ bẩn thông thường thì ROUTINE, rác thải thì WASTE."
                },
                description: {
                    type: "string",
                    description: "Mô tả chi tiết yêu cầu."
                }
            },
            required: ["location", "taskType"]
        }
    }
];

export async function POST(req: Request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session || !session.user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await req.json();
        const { messages, apiKey, provider, model } = body;

        if (!apiKey) {
            return NextResponse.json({ error: "API Key is required" }, { status: 401 });
        }

        const lastMessage = messages[messages.length - 1];
        const userPrompt = lastMessage.content;
        const userId = Number(session.user.id);
        const userName = session.user.name;

        // --- GOOGLE GEMINI HANDLER ---
        if (provider === 'google') {
            const genAI = new GoogleGenerativeAI(apiKey);
            const aiModel = genAI.getGenerativeModel({ model: model || "gemini-1.5-flash" });

            const systemPrompt = `
            Bạn là BIH Assistant - Trợ lý ảo thông minh của Bệnh viện Quốc tế Becamex.
            
            Bạn có thể tạo các loại phiếu sau:
            1. Yêu cầu Kỹ thuật (Technical): Hỏng hóc, sửa chữa điện nước... (Tools: create_maintenance_request)
            2. Yêu cầu Vệ sinh (Environment): Dọn dẹp, rác thải, bẩn... (Tools: create_cleaning_request)
            
            QUAN TRỌNG:
            - Phân tích kỹ yêu cầu của người dùng để chọn đúng Tool.
            - Nếu người dùng nói "dơ", "bẩn", "rác", "dọn dẹp" -> Dùng 'create_cleaning_request'.
            - Nếu người dùng nói "hỏng", "sửa", "không lạnh", "mất điện" -> Dùng 'create_maintenance_request'.
            
            Trả về format JSON function call CHÍNH XÁC như sau (trong code block json):
            \`\`\`json
            {
                "tool": "tên_tool",
                "args": { ... }
            }
            \`\`\`
            `;

            const chat = aiModel.startChat({
                history: [
                    {
                        role: "user",
                        parts: [{ text: systemPrompt }],
                    },
                    {
                        role: "model",
                        parts: [{ text: "Đã rõ. Tôi sẽ phân tích yêu cầu để tạo phiếu Kỹ thuật hoặc Vệ sinh phù hợp." }],
                    },
                ],
            });

            const result = await chat.sendMessage(userPrompt);
            const responseText = result.response.text();

            const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/);

            if (jsonMatch) {
                try {
                    const toolCall = JSON.parse(jsonMatch[1]);

                    if (toolCall.tool === 'create_maintenance_request') {
                        const ticket = await prisma.maintenanceRequest.create({
                            data: {
                                title: toolCall.args.title,
                                description: toolCall.args.description + " (Created via BIH AI Agent)",
                                location: toolCall.args.location,
                                priority: toolCall.args.priority || "MEDIUM",
                                status: "PENDING",
                                reportedById: userId,
                                reportedBy: userName,
                                image: null
                            }
                        });
                        return NextResponse.json({
                            role: 'assistant',
                            content: `✅ Đã tạo phiếu Kỹ thuật thành công!\n\n**Mã phiếu:** #${ticket.id}\n**Vị trí:** ${ticket.location}\n**Nội dung:** ${ticket.title}`,
                            toolExecuted: true
                        });
                    }

                    if (toolCall.tool === 'create_cleaning_request') {
                        const ticket = await prisma.cleaningRequest.create({
                            data: {
                                location: toolCall.args.location,
                                taskType: toolCall.args.taskType || "ROUTINE",
                                description: toolCall.args.description + " (Created via BIH AI Agent)",
                                status: "PENDING",
                                requestedById: userId,
                                requestedBy: userName
                            }
                        });
                        return NextResponse.json({
                            role: 'assistant',
                            content: `✅ Đã tạo phiếu Vệ sinh môi trường thành công!\n\n**Mã phiếu:** #${ticket.id}\n**Vị trí:** ${ticket.location}\n**Công việc:** ${ticket.taskType}`,
                            toolExecuted: true
                        });
                    }

                } catch (e) {
                    console.error("Tool execution failed", e);
                    return NextResponse.json({
                        role: 'assistant',
                        content: "Lỗi hệ thống khi tạo phiếu. Vui lòng thử lại."
                    });
                }
            }

            return NextResponse.json({
                role: 'assistant',
                content: responseText
            });
        }

        // --- OPENAI HANDLER ---
        if (provider === 'openai') {
            const openai = new OpenAI({ apiKey: apiKey });

            const completion = await openai.chat.completions.create({
                messages: [
                    { role: "system", content: "Bạn là trợ lý BIH. Dùng function calling để tạo phiếu Kỹ thuật hoặc Vệ sinh." },
                    // @ts-ignore
                    ...messages
                ],
                model: model || "gpt-3.5-turbo",
                // @ts-ignore
                tools: tools.map(t => ({ type: "function", function: t }))
            });

            const choice = completion.choices[0];

            if (choice.message.tool_calls) {
                // @ts-ignore
                const toolCall: any = choice.message.tool_calls[0];
                const args = JSON.parse(toolCall.function.arguments);

                if (toolCall.function.name === "create_maintenance_request") {
                    const ticket = await prisma.maintenanceRequest.create({
                        data: {
                            title: args.title,
                            description: args.description + " (Created via BIH AI Agent)",
                            location: args.location,
                            priority: args.priority || "MEDIUM",
                            status: "PENDING",
                            reportedById: userId,
                            reportedBy: userName
                        }
                    });
                    return NextResponse.json({
                        role: 'assistant',
                        content: `✅ Đã tạo phiếu Kỹ thuật thành công!\n\n**Mã phiếu:** #${ticket.id}\n**Vị trí:** ${ticket.location}\n**Nội dung:** ${ticket.title}`,
                        toolExecuted: true
                    });
                }

                if (toolCall.function.name === "create_cleaning_request") {
                    const ticket = await prisma.cleaningRequest.create({
                        data: {
                            location: args.location,
                            taskType: args.taskType || "ROUTINE",
                            description: args.description + " (Created via BIH AI Agent)",
                            status: "PENDING",
                            requestedById: userId,
                            requestedBy: userName
                        }
                    });
                    return NextResponse.json({
                        role: 'assistant',
                        content: `✅ Đã tạo phiếu Vệ sinh thành công!\n\n**Mã phiếu:** #${ticket.id}\n**Vị trí:** ${ticket.location}\n**Công việc:** ${ticket.taskType}`,
                        toolExecuted: true
                    });
                }
            }

            return NextResponse.json({
                role: 'assistant',
                content: choice.message.content
            });
        }

        return NextResponse.json({ error: "Invalid provider" }, { status: 400 });

    } catch (error: any) {
        console.error("AI Agent Error:", error);
        return NextResponse.json({
            error: error.message || "Something went wrong",
            isQuotaError: error.message?.includes("quota") || error.status === 429
        }, { status: 500 });
    }
}

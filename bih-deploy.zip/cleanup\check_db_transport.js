
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkData() {
    try {
        const count = await prisma.patientTransport.count();
        console.log(`Total PatientTransport records: ${count}`);

        const items = await prisma.patientTransport.findMany({
            orderBy: { requestedAt: 'desc' },
            take: 5
        });
        console.log("Latest 5 records:", JSON.stringify(items, null, 2));

        const users = await prisma.user.findMany({ take: 2 });
        console.log("Sample Users:", JSON.stringify(users, null, 2));

    } catch (error) {
        console.error("Error accessing DB:", error);
    } finally {
        await prisma.$disconnect();
    }
}

checkData();

import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; fullName: string } | null;
}

// GET: Chi tiết khách
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const visitor = await prisma.visitor.findUnique({
            where: { id: parseInt(params.id) }
        });

        if (!visitor) {
            return NextResponse.json({ error: "Visitor not found" }, { status: 404 });
        }

        return NextResponse.json(visitor);
    } catch (error) {
        console.error("Get Visitor Error:", error);
        return NextResponse.json({ error: "Failed to get visitor" }, { status: 500 });
    }
}

// PATCH: Checkout khách
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Chỉ SECURITY mới được checkout
        if (user.role !== 'SECURITY' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Chỉ nhân viên An ninh mới được checkout khách" }, { status: 403 });
        }

        const visitor = await prisma.visitor.update({
            where: { id: parseInt(params.id) },
            data: {
                status: 'CHECKED_OUT',
                checkOutTime: new Date()
            }
        });

        return NextResponse.json(visitor);
    } catch (error) {
        console.error("Checkout Visitor Error:", error);
        return NextResponse.json({ error: "Failed to checkout visitor" }, { status: 500 });
    }
}

// DELETE: Xóa bản ghi khách
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Chỉ SECURITY hoặc ADMIN mới được xóa
        if (user.role !== 'SECURITY' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Không có quyền xóa" }, { status: 403 });
        }

        await prisma.visitor.delete({
            where: { id: parseInt(params.id) }
        });

        return NextResponse.json({ message: "Deleted successfully" });
    } catch (error) {
        console.error("Delete Visitor Error:", error);
        return NextResponse.json({ error: "Failed to delete visitor" }, { status: 500 });
    }
}

"use client";

import { useParams } from "next/navigation";

const TITLES: Record<string, string> = {
    technical: "Tổ Kỹ thuật vận hành",
    nursing: "Tổ Hộ lý",
    driver: "Tổ Lái xe",
    security: "Tổ Bảo vệ",
    supply: "Tổ Cung ứng (Vật tư ngoài y tế)",
    environment: "Tổ Môi trường (Cảnh quan, cây xanh)",
};

export default function DepartmentPage() {
    const params = useParams();
    const slug = params.slug as string;
    const title = TITLES[slug] || "Chi tiết tổ";

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h2 className="text-2xl font-bold text-[var(--bih-blue-dark)]">{title}</h2>
                <button className="btn btn-primary">
                    + Tạo báo cáo mới
                </button>
            </div>

            <div className="card" style={{ minHeight: '400px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ width: '64px', height: '64px', background: 'var(--bih-gray-100)', borderRadius: '50%' }} />
                <p style={{ color: 'var(--bih-gray-700)' }}>
                    Khu vực quản lý dữ liệu cho <strong>{title}</strong>
                </p>
                <p style={{ fontSize: '0.875rem', color: 'var(--bih-gray-500)' }}>
                    Hệ thống đang được cập nhật module này.
                </p>
            </div>
        </div>
    );
}

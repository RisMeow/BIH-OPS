
import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function POST(request: Request) {
    try {
        const body = await request.json();
        // taskId là optional (nếu kiểm tra từ một task được giao)
        const { locationId, inspectorId, status, note, taskId } = body;

        if (!locationId || !inspectorId || !status) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        // 1. Tạo Inspection Log
        const newLog = await prisma.inspectionLog.create({
            data: {
                locationId,
                inspectorId: parseInt(inspectorId.toString()),
                status, // 'PASS' | 'FAIL'
                note
            }
        });

        // 2. Nếu việc này đến từ một Task, đánh dấu Task là DONE
        if (taskId) {
            await prisma.orderlyTask.update({
                where: { id: parseInt(taskId) },
                data: { status: 'DONE' }
            });
        }

        return NextResponse.json(newLog, { status: 201 });
    } catch (error) {
        console.error("Inspection Save Error:", error);
        return NextResponse.json({ error: "Failed to save inspection" }, { status: 500 });
    }
}

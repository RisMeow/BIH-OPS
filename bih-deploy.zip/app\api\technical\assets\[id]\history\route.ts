import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = parseInt(params.id);
        if (isNaN(id)) return NextResponse.json({ error: "Invalid ID" }, { status: 400 });

        const history = await prisma.maintenanceHistory.findMany({
            where: { assetId: id },
            orderBy: { performedAt: 'desc' },
            include: {
                asset: {
                    select: { name: true, code: true }
                }
            }
        });

        return NextResponse.json(history);
    } catch (error) {
        return NextResponse.json({ error: "Failed to fetch history" }, { status: 500 });
    }
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// Helper: Kiểm tra quyền Admin
async function checkAdminAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user || session.user.role !== 'ADMIN') {
        return false;
    }
    return true;
}

// GET: Lấy danh sách users kèm thông tin manager
export async function GET() {
    // Kiểm tra quyền Admin
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const users = await prisma.user.findMany({
            select: {
                id: true,
                username: true,
                fullName: true,
                email: true,
                phoneNumber: true,
                department: true,
                role: true,
                position: true,
                manager: {
                    select: { id: true, fullName: true, username: true }
                },
                createdAt: true,
            },
            orderBy: { createdAt: 'desc' },
        });
        return NextResponse.json(users);
    } catch (error) {
        console.error("Fetch users error:", error);
        return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
    }
}

// POST: Tạo user mới với hierarchy (CHỈ ADMIN)
export async function POST(request: Request) {
    // Kiểm tra quyền Admin
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const body = await request.json();
        const { username, password, fullName, email, phoneNumber, department, role, position, managerId } = body;

        // Validate required fields
        if (!username || !password || !fullName || !role) {
            return NextResponse.json({ error: 'Missing required fields: username, password, fullName, role' }, { status: 400 });
        }

        // Check if username already exists
        const existing = await prisma.user.findUnique({ where: { username } });
        if (existing) {
            return NextResponse.json({ error: 'Tên đăng nhập đã tồn tại' }, { status: 400 });
        }

        // Check if email already exists (if provided)
        if (email) {
            const emailExists = await prisma.user.findUnique({ where: { email } });
            if (emailExists) {
                return NextResponse.json({ error: 'Email đã được sử dụng' }, { status: 400 });
            }
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = await prisma.user.create({
            data: {
                username,
                password: hashedPassword,
                fullName,
                email: email || null,
                phoneNumber: phoneNumber || null,
                department: department || null,
                role,
                position: position || 'STAFF',
                managerId: managerId ? parseInt(managerId) : null,
            },
        });

        // Remove password from response
        const { password: _, ...userWithoutPassword } = newUser;

        return NextResponse.json(userWithoutPassword, { status: 201 });

    } catch (error: any) {
        console.error("Create User Error:", error);
        return NextResponse.json({
            error: error.message || 'Failed to create user',
            details: error.meta || {}
        }, { status: 500 });
    }
}


import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// GET: Lấy danh sách nhiệm vụ đang chờ (PENDING)
export async function GET() {
    try {
        const tasks = await prisma.orderlyTask.findMany({
            where: { status: 'PENDING' },
            include: {
                location: true // Để lấy tên phòng
            },
            orderBy: { createdAt: 'desc' }
        });

        const formattedTasks = tasks.map(t => ({
            id: t.id,
            locationId: t.locationId,
            locationName: t.location.name,
            reason: t.reason,
            status: t.status
        }));

        return NextResponse.json(formattedTasks);
    } catch (error) {
        return NextResponse.json({ error: "Failed to fetch tasks" }, { status: 500 });
    }
}

// POST: Sinh nhiệm vụ tự động (Smart Audit Algorithm)
export async function POST() {
    try {
        // Thực tế: Xóa các task cũ chưa làm (hoặc giữ lại tùy nghiệp vụ)
        // Ở đây ta đơn giản hóa: Tạo mới danh sách đề xuất
        await prisma.orderlyTask.deleteMany({ where: { status: 'PENDING' } });

        // 1. Tìm các phòng có lịch sử FAIL gần đây (trong 3 ngày qua)
        const recentFails = await prisma.inspectionLog.findMany({
            where: {
                status: 'FAIL',
                createdAt: { gte: new Date(new Date().setDate(new Date().getDate() - 3)) }
            },
            select: { locationId: true }
        });

        // 2. Tìm ngẫu nhiên một số phòng (Random)
        const allLocations = await prisma.location.findMany({
            where: { type: 'ROOM' },
            take: 5
        });

        const newTasksData: { locationId: string; reason: string; status: string }[] = [];

        // Logic 1: Ưu tiên phòng Fail
        for (const log of recentFails) {
            // Tránh trùng lặp
            if (!newTasksData.find(t => t.locationId === log.locationId)) {
                newTasksData.push({
                    locationId: log.locationId,
                    reason: 'HISTORY_FAIL',
                    status: 'PENDING'
                });
            }
        }

        // Logic 2: Ngẫu nhiên (Fill cho đủ 3 task nếu thiếu)
        for (const loc of allLocations) {
            if (newTasksData.length >= 5) break;
            if (!newTasksData.find(t => t.locationId === loc.id)) {
                newTasksData.push({
                    locationId: loc.id,
                    reason: Math.random() > 0.5 ? 'RANDOM' : 'LONG_TIME',
                    status: 'PENDING'
                });
            }
        }

        // Lưu vào DB
        await prisma.orderlyTask.createMany({
            data: newTasksData
        });

        return NextResponse.json({ message: "Generated", count: newTasksData.length });
    } catch (error) {
        console.error("Smart Audit Error:", error);
        return NextResponse.json({ error: "Failed to generate tasks" }, { status: 500 });
    }
}

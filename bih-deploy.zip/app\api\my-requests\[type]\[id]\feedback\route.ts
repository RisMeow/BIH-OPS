"use server";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

interface RouteParams {
    params: { type: string; id: string };
}

// GET: Lấy feedback/comments cho một ticket cụ thể
export async function GET(req: NextRequest, { params }: RouteParams) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const ticketType = params.type.toUpperCase();
        const ticketId = parseInt(params.id);

        if (isNaN(ticketId)) {
            return NextResponse.json({ error: "Invalid ticket ID" }, { status: 400 });
        }

        const feedback = await prisma.ticketFeedback.findMany({
            where: {
                ticketType,
                ticketId
            },
            orderBy: { createdAt: "asc" }
        });

        return NextResponse.json({ feedback });
    } catch (error) {
        console.error("Error fetching feedback:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

// POST: Thêm feedback mới cho ticket (chỉ ADMIN, MANAGER, LEADER)
export async function POST(req: NextRequest, { params }: RouteParams) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const userPosition = session.user.position || "STAFF";
        const userRole = session.user.role || "STAFF";

        // Chỉ cho phép ADMIN, MANAGER, LEADER phản hồi
        const allowedPositions = ["ADMIN", "MANAGER", "LEADER"];
        if (!allowedPositions.includes(userPosition) && userRole !== "ADMIN") {
            return NextResponse.json({ error: "Không có quyền phản hồi" }, { status: 403 });
        }

        const ticketType = params.type.toUpperCase();
        const ticketId = parseInt(params.id);

        if (isNaN(ticketId)) {
            return NextResponse.json({ error: "Invalid ticket ID" }, { status: 400 });
        }

        const body = await req.json();
        const { content, type = "REPLY", statusSnapshot } = body;

        if (!content || content.trim() === "") {
            return NextResponse.json({ error: "Nội dung không được để trống" }, { status: 400 });
        }

        const feedback = await prisma.ticketFeedback.create({
            data: {
                ticketType,
                ticketId,
                authorId: parseInt(String(session.user.id)),
                authorName: session.user.name || "Unknown",
                authorRole: userRole === "ADMIN" ? "ADMIN" : userPosition,
                content: content.trim(),
                type,
                statusSnapshot
            }
        });

        return NextResponse.json({ feedback }, { status: 201 });
    } catch (error) {
        console.error("Error creating feedback:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

"use server";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Type definitions for Prisma results
interface MaintenanceRequestResult {
    id: number;
    title: string;
    description: string;
    location: string;
    priority: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    requestType: string;
    reportedBy: string | null;
}

interface NursingRequestResult {
    id: number;
    roomNumber: string;
    patientName: string | null;
    requestType: string;
    description: string | null;
    priority: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    requestedBy: string | null;
}

interface TransportRequestResult {
    id: number;
    passengerName: string;
    department: string;
    destination: string;
    pickupLocation: string | null;
    pickupTime: Date;
    tripType: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    requestedBy: string | null;
}

interface SecurityReportResult {
    id: number;
    location: string;
    incidentType: string;
    description: string;
    severity: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    reportedBy: string | null;
}

interface SupplyRequestResult {
    id: number;
    itemName: string;
    category: string;
    quantity: number;
    unit: string;
    urgency: string;
    requester: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
}

interface CleaningRequestResult {
    id: number;
    location: string;
    taskType: string;
    description: string | null;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    requestedBy: string | null;
}

interface PatientTransportResult {
    id: number;
    patientName: string;
    fromLocation: string;
    toLocation: string;
    transportMode: string;
    priority: string;
    status: string;
    requestedAt: Date;
    completedAt: Date | null;
    requestedBy: string | null;
}

// GET: Lấy tất cả các yêu cầu mà user hiện tại đã gửi
export async function GET(req: NextRequest) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const userId = parseInt(String(session.user.id));
        const userName = session.user.name || "";

        // Fetch parallel từ tất cả các bảng ticket
        const [
            technicalRequests,
            nursingRequests,
            driverRequests,
            securityReports,
            supplyRequests,
            environmentRequests,
            patientTransports
        ] = await Promise.all([
            // Technical - check reportedById
            prisma.maintenanceRequest.findMany({
                where: { reportedById: userId },
                select: {
                    id: true,
                    title: true,
                    description: true,
                    location: true,
                    priority: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    requestType: true,
                    reportedBy: true,
                }
            }),
            // Nursing - check requestedById
            prisma.nursingRequest.findMany({
                where: { requestedById: userId },
                select: {
                    id: true,
                    roomNumber: true,
                    patientName: true,
                    requestType: true,
                    description: true,
                    priority: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    requestedBy: true,
                }
            }),
            // Driver - check requestedById
            prisma.transportRequest.findMany({
                where: { requestedById: userId },
                select: {
                    id: true,
                    passengerName: true,
                    department: true,
                    destination: true,
                    pickupLocation: true,
                    pickupTime: true,
                    tripType: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    requestedBy: true,
                }
            }),
            // Security - check reportedById  
            prisma.securityReport.findMany({
                where: { reportedById: userId },
                select: {
                    id: true,
                    location: true,
                    incidentType: true,
                    description: true,
                    severity: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    reportedBy: true,
                }
            }),
            // Supply - check requestedById
            prisma.supplyRequest.findMany({
                where: { requestedById: userId },
                select: {
                    id: true,
                    itemName: true,
                    category: true,
                    quantity: true,
                    unit: true,
                    urgency: true,
                    requester: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true
                }
            }),
            // Environment (CleaningRequest) - check requestedById
            prisma.cleaningRequest.findMany({
                where: { requestedById: userId },
                select: {
                    id: true,
                    location: true,
                    taskType: true,
                    description: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    requestedBy: true
                }
            }),
            // Patient Transport (Nursing subfolder)
            prisma.patientTransport.findMany({
                where: {
                    requestedBy: { contains: userName }
                },
                select: {
                    id: true,
                    patientName: true,
                    fromLocation: true,
                    toLocation: true,
                    transportMode: true,
                    priority: true,
                    status: true,
                    requestedAt: true,
                    completedAt: true,
                    requestedBy: true,
                }
            })
        ]);

        // Normalize data into unified format
        const allRequests = [
            ...(technicalRequests as MaintenanceRequestResult[]).map(r => ({
                id: r.id,
                type: "TECHNICAL" as const,
                typeName: "Kỹ thuật",
                title: r.title,
                description: r.description,
                location: r.location,
                priority: r.priority,
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { requestType: r.requestType }
            })),
            ...(nursingRequests as NursingRequestResult[]).map(r => ({
                id: r.id,
                type: "NURSING" as const,
                typeName: "Hộ lý",
                title: `${getNursingTypeLabel(r.requestType)} - ${r.roomNumber}`,
                description: r.description || `Bệnh nhân: ${r.patientName || 'N/A'}`,
                location: r.roomNumber,
                priority: r.priority,
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { requestType: r.requestType, patientName: r.patientName }
            })),
            ...(driverRequests as TransportRequestResult[]).map(r => ({
                id: r.id,
                type: "DRIVER" as const,
                typeName: "Đội xe",
                title: `Đưa đón: ${r.passengerName}`,
                description: r.pickupLocation ? `Từ ${r.pickupLocation} đến ${r.destination}` : `Đến ${r.destination}`,
                location: r.pickupLocation || r.department,
                priority: r.tripType === 'EMERGENCY' ? 'URGENT' : 'MEDIUM',
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { tripType: r.tripType, pickupTime: r.pickupTime }
            })),
            ...(securityReports as SecurityReportResult[]).map(r => ({
                id: r.id,
                type: "SECURITY" as const,
                typeName: "An ninh",
                title: `Sự cố: ${getIncidentTypeLabel(r.incidentType)}`,
                description: r.description,
                location: r.location,
                priority: r.severity,
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { incidentType: r.incidentType }
            })),
            ...(supplyRequests as SupplyRequestResult[]).map(r => ({
                id: r.id,
                type: "SUPPLY" as const,
                typeName: "Vật tư",
                title: `${r.itemName} (${r.quantity} ${r.unit})`,
                description: `Danh mục: ${r.category}`,
                location: "",
                priority: r.urgency,
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { category: r.category }
            })),
            ...(environmentRequests as CleaningRequestResult[]).map(r => ({
                id: r.id,
                type: "ENVIRONMENT" as const,
                typeName: "Môi trường",
                title: `${getTaskTypeLabel(r.taskType)}`,
                description: r.description || "",
                location: r.location,
                priority: "MEDIUM",
                status: r.status,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                meta: { taskType: r.taskType }
            })),
            ...(patientTransports as PatientTransportResult[]).map(r => ({
                id: r.id,
                type: "NURSING_TRANSPORT" as const,
                typeName: "Vận chuyển BN",
                title: `Vận chuyển: ${r.patientName}`,
                description: `Từ ${r.fromLocation} đến ${r.toLocation}`,
                location: r.fromLocation,
                priority: r.priority,
                status: r.status,
                createdAt: r.requestedAt,
                updatedAt: r.completedAt || r.requestedAt,
                meta: { transportMode: r.transportMode }
            })),
        ];

        // Sort by createdAt descending
        allRequests.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

        return NextResponse.json({
            requests: allRequests,
            total: allRequests.length
        });
    } catch (error) {
        console.error("Error fetching my requests:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

function getIncidentTypeLabel(type: string): string {
    const labels: Record<string, string> = {
        "SUSPICIOUS": "Đối tượng khả nghi",
        "THEFT": "Trộm cắp / Mất đồ",
        "FIGHT": "Gây rối / Xô xát",
        "ACCESS_CONTROL": "Vi phạm ra vào",
        "OTHER": "Khác"
    };
    return labels[type] || type;
}

function getTaskTypeLabel(type: string): string {
    const labels: Record<string, string> = {
        "CLEANING": "Vệ sinh / Làm sạch",
        "WASTE": "Thu gom rác thải",
        "LANDSCAPE": "Chăm sóc cây xanh",
        "PEST_CONTROL": "Diệt côn trùng",
        "REPAIR": "Sửa chữa nhỏ",
        "OTHER": "Khác"
    };
    return labels[type] || type;
}

function getNursingTypeLabel(type: string): string {
    const labels: Record<string, string> = {
        "ASSISTANCE": "Hỗ trợ Hộ lý",
        "CLEANING": "Vệ sinh phòng",
        "TRANSPORT": "Vận chuyển BN",
        "MEAL": "Phân phát bữa ăn",
        "LINEN": "Thay ga trải",
        "OTHER": "Khác"
    };
    return labels[type] || type;
}

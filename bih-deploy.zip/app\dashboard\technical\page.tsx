"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    Wrench, Plus, Search, Filter, MoreVertical,
    Clock, CheckCircle2, AlertTriangle, User,
    ArrowRight, AlertCircle, FileText, X, UserPlus,
    Edit, Trash2, BarChart3, TrendingUp, MapPin, Users, Activity,
    Box, Calendar, Settings, Cpu, Eye, MessageCircle, Send,
    ToggleLeft, ToggleRight
} from "lucide-react";
import { clsx } from "clsx";
import { useLanguage } from "@/app/context/LanguageContext";
import LocationSelector from "@/app/components/LocationSelector";
import { useSession } from "next-auth/react";
import Toast, { ToastType } from "@/app/components/Toast";
import ConfirmModal from "@/app/components/ConfirmModal";
import DateInput from "@/app/components/DateInput";

// Types
interface Ticket {
    id: number;
    title: string;
    location: string;
    priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
    status: 'PENDING' | 'ASSIGNED' | 'IN_PROGRESS' | 'COMPLETED';
    assignedTo?: { id: number; name: string; avatar: string };
    assignees?: { id: number; name: string; avatar: string }[];
    createdAt: string;
    description: string;
    quantity?: number;
    unit?: string;
}

interface StaffMember {
    id: number;
    fullName: string;
    position: string;
}

interface Stats {
    summary: {
        totalTickets: number;
        completedTickets: number;
        pendingTickets: number;
        completionRate: number;
        inProgressTickets: number;
        assignedTickets: number;
    };
    topLocations: { location: string; count: number }[];
    topStaff: { id: number; fullName: string; position: string; assignmentCount: number }[];
    dailyStats: { date: string; total: number; completed: number; urgent: number }[];
    priorityCounts: { priority: string; count: number }[];
}

export default function TechnicalDashboard() {
    const { t } = useLanguage();
    const { data: session } = useSession();
    const [activeTab, setActiveTab] = useState<'kanban' | 'assets' | 'maintenance' | 'stats'>('kanban');

    // UI Feedback States
    const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
        message: '', type: 'info', isVisible: false
    });
    const showToast = (message: string, type: ToastType = 'success') => {
        setToast({ message, type, isVisible: true });
    };

    const [confirmConfig, setConfirmConfig] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
        variant: 'danger' | 'info';
    }>({ isOpen: false, title: '', message: '', onConfirm: () => { }, variant: 'info' });

    const openConfirm = (title: string, message: string, onConfirm: () => void, variant: 'danger' | 'info' = 'danger') => {
        setConfirmConfig({ isOpen: true, title, message, onConfirm, variant });
    };
    const [tickets, setTickets] = useState<Ticket[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [stats, setStats] = useState<Stats | null>(null);
    const [statsLoading, setStatsLoading] = useState(false);

    // Assign Modal State
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [selectedTicketForAssign, setSelectedTicketForAssign] = useState<Ticket | null>(null);
    const [staffList, setStaffList] = useState<StaffMember[]>([]);
    const [selectedStaffIds, setSelectedStaffIds] = useState<number[]>([]);

    // Edit Modal State
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingTicket, setEditingTicket] = useState<Ticket | null>(null);
    const [editFormData, setEditFormData] = useState({
        title: '',
        location: '',
        priority: 'MEDIUM',
        description: '',
        quantity: 1,
        unit: 'Lần'
    });

    // Form Data
    const [newTicket, setNewTicket] = useState({
        title: '',
        location: '',
        priority: 'MEDIUM',
        description: '',
        quantity: 1,
        unit: 'Lần'
    });

    // Asset Management States
    interface Asset {
        id: number;
        code: string;
        name: string;
        category: string;
        location: string;
        manufacturer?: string;
        model?: string;
        status: string;
        warrantyExpiry?: string;
        _count?: { maintenanceHistory: number };
    }

    interface MaintenanceSchedule {
        id: number;
        assetId: number;
        title: string;
        frequency: string;
        nextDueAt?: string;
        lastExecutedAt?: string;
        asset?: { id: number; code: string; name: string; location: string; category: string };
    }

    const [assets, setAssets] = useState<Asset[]>([]);
    const [schedules, setSchedules] = useState<MaintenanceSchedule[]>([]);
    const [assetsLoading, setAssetsLoading] = useState(false);
    const [isAddAssetModalOpen, setIsAddAssetModalOpen] = useState(false);
    const [isAddScheduleModalOpen, setIsAddScheduleModalOpen] = useState(false);
    const [newAsset, setNewAsset] = useState({
        code: '', name: '', category: 'HVAC', location: '', manufacturer: '', model: ''
    });

    // History Modal
    const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
    const [assetHistory, setAssetHistory] = useState<any[]>([]);
    const [selectedAssetForHistory, setSelectedAssetForHistory] = useState<Asset | null>(null);

    // Edit Asset State
    const [isEditAssetModalOpen, setIsEditAssetModalOpen] = useState(false);
    const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
    const [editAssetFormData, setEditAssetFormData] = useState({
        code: '', name: '', category: 'HVAC', location: '', manufacturer: '', model: ''
    });

    const [selectedAssetForSchedule, setSelectedAssetForSchedule] = useState<number | null>(null);
    const [newSchedule, setNewSchedule] = useState({
        title: '', frequency: 'MONTHLY', checklistItems: '', nextDueAt: new Date().toISOString().split('T')[0]
    });

    // Comment/Command System States
    interface Comment {
        id: number;
        authorId: number;
        authorName: string;
        authorRole: string;
        content: string;
        type: string;
        parentId: number | null;
        createdAt: string;
    }
    const [selectedTicketForDetail, setSelectedTicketForDetail] = useState<Ticket | null>(null);
    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [ticketComments, setTicketComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [commandForAssign, setCommandForAssign] = useState(''); // Command khi phân công


    // --- FETCH DATA ---
    const fetchTickets = async () => {
        setIsLoading(true);
        try {
            const res = await fetch('/api/technical/requests');
            if (res.ok) {
                const data = await res.json();
                setTickets(data);
            }
        } catch (error) {
            console.error("Failed to fetch tickets", error);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchStaff = async () => {
        try {
            const res = await fetch('/api/technical/staff');
            if (res.ok) {
                const data = await res.json();
                setStaffList(data);
            }
        } catch (error) {
            console.error("Failed to fetch staff", error);
        }
    };

    const fetchStats = async () => {
        setStatsLoading(true);
        try {
            const res = await fetch('/api/technical/stats');
            if (res.ok) {
                const data = await res.json();
                setStats(data);
            }
        } catch (error) {
            console.error("Failed to fetch stats", error);
        } finally {
            setStatsLoading(false);
        }
    };

    useEffect(() => {
        fetchTickets();
        fetchStaff();
    }, []);

    useEffect(() => {
        if (activeTab === 'stats' && !stats) {
            fetchStats();
        }
        if (activeTab === 'assets' && assets.length === 0) {
            fetchAssets();
        }
        if (activeTab === 'maintenance' && schedules.length === 0) {
            fetchSchedules();
        }
    }, [activeTab]);

    const fetchAssets = async () => {
        setAssetsLoading(true);
        try {
            const res = await fetch('/api/technical/assets');
            const data = await res.json();
            if (Array.isArray(data)) setAssets(data);
        } catch (e) { console.error("Failed to fetch assets", e); }
        finally { setAssetsLoading(false); }
    };

    const fetchSchedules = async () => {
        try {
            const res = await fetch('/api/technical/maintenance');
            const data = await res.json();
            if (Array.isArray(data)) setSchedules(data);
        } catch (e) { console.error("Failed to fetch schedules", e); }
    };

    const fetchHistory = async (assetId: number) => {
        try {
            const res = await fetch(`/api/technical/assets/${assetId}/history`);
            if (res.ok) {
                const data = await res.json();
                setAssetHistory(data);
            }
        } catch (e) { console.error("Failed to fetch history", e); }
    };

    const openHistoryModal = (asset: Asset) => {
        setSelectedAssetForHistory(asset);
        setIsHistoryModalOpen(true);
        fetchHistory(asset.id);
    };

    const handleCreateAsset = async () => {
        if (!newAsset.code || !newAsset.name || !newAsset.location) {
            showToast("Vui lòng điền đầy đủ: Mã, Tên, Vị trí", 'error'); return;
        }
        try {
            const res = await fetch('/api/technical/assets', {
                method: 'POST', body: JSON.stringify(newAsset),
                headers: { 'Content-Type': 'application/json' }
            });
            if (res.ok) {
                setIsAddAssetModalOpen(false);
                fetchAssets();
                setNewAsset({ code: '', name: '', category: 'HVAC', location: '', manufacturer: '', model: '' });
                showToast("Đã thêm thiết bị!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + data.error, 'error');
            }
        } catch (e) { showToast("Lỗi kết nối", 'error'); }
    };

    const handleDeleteAsset = (id: number, name: string) => {
        openConfirm("Xóa thiết bị", `Bạn có chắc muốn xóa thiết bị "${name}"? Hành động này sẽ xóa cả lịch bảo trì và lịch sử sửa chữa.`, async () => {
            try {
                const res = await fetch(`/api/technical/assets/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    showToast("Đã xóa thiết bị.", 'success');
                    fetchAssets();
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { showToast("Lỗi kết nối", 'error'); }
        });
    };

    const handleToggleAssetStatus = (asset: Asset) => {
        const newStatus = asset.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
        openConfirm("Chuyển trạng thái", `Xác nhận chuyển trạng thái thiết bị thành ${newStatus}?`, async () => {
            try {
                const res = await fetch(`/api/technical/assets/${asset.id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: newStatus }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    fetchAssets();
                    showToast("Cập nhật trạng thái thành công");
                }
            } catch (e) { console.error(e); }
        }, 'info');
    };

    const openEditAssetModal = (asset: Asset) => {
        setEditingAsset(asset);
        setEditAssetFormData({
            code: asset.code,
            name: asset.name,
            category: asset.category,
            location: asset.location,
            manufacturer: asset.manufacturer || '',
            model: asset.model || ''
        });
        setIsEditAssetModalOpen(true);
    };

    const handleUpdateAsset = async () => {
        if (!editingAsset) return;
        try {
            const res = await fetch(`/api/technical/assets/${editingAsset.id}`, {
                method: 'PATCH',
                body: JSON.stringify(editAssetFormData),
                headers: { 'Content-Type': 'application/json' }
            });
            if (res.ok) {
                setIsEditAssetModalOpen(false);
                setEditingAsset(null);
                fetchAssets();
                showToast("Đã cập nhật thiết bị!", 'success');
            }
        } catch (e) { showToast("Lỗi kết nối", 'error'); }
    };

    const handleCreateSchedule = async () => {
        if (!selectedAssetForSchedule || !newSchedule.title) {
            showToast("Vui lòng chọn thiết bị và nhập công việc bảo trì", 'error'); return;
        }
        try {
            const res = await fetch('/api/technical/maintenance', {
                method: 'POST',
                body: JSON.stringify({ ...newSchedule, assetId: selectedAssetForSchedule }),
                headers: { 'Content-Type': 'application/json' }
            });
            if (res.ok) {
                setIsAddScheduleModalOpen(false);
                fetchSchedules();
                setNewSchedule({ title: '', frequency: 'MONTHLY', checklistItems: '', nextDueAt: new Date().toISOString().split('T')[0] });
                setSelectedAssetForSchedule(null);
                showToast("Đã tạo lịch bảo trì!", 'success');
            } else {
                const data = await res.json();
                showToast("Lỗi: " + data.error, 'error');
            }
        } catch (e) { showToast("Lỗi kết nối", 'error'); }
    };

    const handleCompleteSchedule = (id: number) => {
        openConfirm("Xác nhận hoàn thành", "Xác nhận đã hoàn thành bảo trì này?", async () => {
            try {
                const res = await fetch(`/api/technical/maintenance/${id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ action: 'complete' }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    fetchSchedules();
                    showToast("Đã ghi nhận hoàn thành!", 'success');
                }
            } catch (e) { showToast("Lỗi kết nối", 'error'); }
        });
    };

    const handleGenerateTickets = async () => {
        try {
            const res = await fetch('/api/technical/maintenance/generate', { method: 'POST' });
            if (res.ok) {
                const data = await res.json();
                fetchSchedules();
                showToast(`Đã tạo ${data.generatedCount} ticket bảo trì mới!`, 'success');
            } else {
                showToast("Lỗi khi tạo ticket", 'error');
            }
        } catch (e) { showToast("Lỗi kết nối", 'error'); }
    };

    const getCategoryLabel = (cat: string) => {
        const map: Record<string, string> = {
            'HVAC': 'Điều hòa/Thông gió', 'ELECTRICAL': 'Điện', 'PLUMBING': 'Nước/Ống nước',
            'FIRE_SAFETY': 'PCCC', 'ELEVATOR': 'Thang máy', 'GENERATOR': 'Máy phát điện', 'OTHER': 'Khác'
        };
        return map[cat] || cat;
    };

    const getFrequencyLabel = (freq: string) => {
        const map: Record<string, string> = {
            'DAILY': 'Hàng ngày', 'WEEKLY': 'Hàng tuần', 'MONTHLY': 'Hàng tháng',
            'QUARTERLY': 'Hàng quý', 'YEARLY': 'Hàng năm'
        };
        return map[freq] || freq;
    };

    // Comment System Functions
    const fetchComments = async (requestId: number) => {
        try {
            const res = await fetch(`/api/technical/comments?requestId=${requestId}`);
            if (res.ok) {
                const data = await res.json();
                setTicketComments(data);
            }
        } catch (e) { console.error("Failed to fetch comments", e); }
    };

    const handleAddComment = async () => {
        if (!selectedTicketForDetail || !newComment.trim()) return;
        try {
            const res = await fetch('/api/technical/comments', {
                method: 'POST',
                body: JSON.stringify({
                    requestId: selectedTicketForDetail.id,
                    content: newComment
                }),
                headers: { 'Content-Type': 'application/json' }
            });
            if (res.ok) {
                setNewComment('');
                fetchComments(selectedTicketForDetail.id);
            }
        } catch (e) { showToast("Lỗi khi gửi comment", 'error'); }
    };

    const openTicketDetail = (ticket: Ticket) => {
        setSelectedTicketForDetail(ticket);
        setIsDetailModalOpen(true);
        fetchComments(ticket.id);
    };

    // --- ACTIONS ---
    const handleCreateTicket = async () => {
        if (!newTicket.title || !newTicket.location) return;

        try {
            const res = await fetch('/api/technical/requests', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTicket)
            });
            if (res.ok) {
                fetchTickets();
                setIsCreateModalOpen(false);
                fetchTickets();
                setIsCreateModalOpen(false);
                setNewTicket({ title: '', location: '', priority: 'MEDIUM', description: '', quantity: 1, unit: 'Lần' });
            }
        } catch (error) {
            console.error(error);
        }
    };

    const openAssignModal = (ticket: Ticket) => {
        setSelectedTicketForAssign(ticket);
        const currentAssigneeIds = ticket.assignees?.map(a => a.id) || (ticket.assignedTo ? [ticket.assignedTo.id] : []);
        setSelectedStaffIds(currentAssigneeIds);
        setIsAssignModalOpen(true);
    };

    const handleAssignStaff = async () => {
        if (!selectedTicketForAssign) return;

        try {
            const res = await fetch(`/api/technical/requests/${selectedTicketForAssign.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    assigneeIds: selectedStaffIds,
                    status: selectedStaffIds.length > 0 ? 'ASSIGNED' : 'PENDING'
                })
            });
            if (res.ok) {
                fetchTickets();
                setIsAssignModalOpen(false);
                setSelectedTicketForAssign(null);
                setSelectedStaffIds([]);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const handleDeleteTicket = (id: number) => {
        openConfirm("Xóa yêu cầu", "Bạn có chắc chắn muốn xóa ticket này không?", async () => {
            try {
                const res = await fetch(`/api/technical/requests/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchTickets();
                    showToast("Đã xóa ticket", 'success');
                }
            } catch (error) {
                console.error(error);
                showToast("Lỗi xóa ticket", 'error');
            }
        });
    };

    const openEditModal = (ticket: Ticket) => {
        setEditingTicket(ticket);
        setEditFormData({
            title: ticket.title,
            location: ticket.location,
            priority: ticket.priority,
            description: ticket.description,
            quantity: ticket.quantity || 1,
            unit: ticket.unit || 'Lần'
        });
        setIsEditModalOpen(true);
    };

    const handleUpdateTicket = async () => {
        if (!editingTicket) return;
        try {
            const res = await fetch(`/api/technical/requests/${editingTicket.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(editFormData)
            });
            if (res.ok) {
                fetchTickets();
                setIsEditModalOpen(false);
                setEditingTicket(null);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const handleUpdateStatus = async (id: number, currentStatus: string) => {
        if (currentStatus === 'PENDING') {
            const ticket = tickets.find(t => t.id === id);
            if (ticket) {
                openAssignModal(ticket);
            }
            return;
        }

        let nextStatus = 'PENDING';
        if (currentStatus === 'ASSIGNED') nextStatus = 'IN_PROGRESS';
        else if (currentStatus === 'IN_PROGRESS') nextStatus = 'COMPLETED';
        else return;

        try {
            const res = await fetch(`/api/technical/requests/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: nextStatus })
            });
            if (res.ok) {
                fetchTickets();
            }
        } catch (error) {
            console.error(error);
        }
    };

    const getPriorityColor = (p: string) => {
        switch (p) {
            case 'URGENT': return 'bg-red-100 text-red-700 border-red-200';
            case 'HIGH': return 'bg-orange-100 text-orange-700 border-orange-200';
            case 'MEDIUM': return 'bg-blue-100 text-blue-700 border-blue-200';
            default: return 'bg-slate-100 text-slate-700 border-slate-200';
        }
    };

    const columns = [
        { id: 'PENDING', title: t.technical.statusPending, icon: AlertCircle, color: 'text-red-500' },
        { id: 'ASSIGNED', title: t.technical.statusAssigned, icon: User, color: 'text-blue-500' },
        { id: 'IN_PROGRESS', title: t.technical.statusInProgress, icon: Clock, color: 'text-amber-500' },
        { id: 'COMPLETED', title: t.technical.statusCompleted, icon: CheckCircle2, color: 'text-emerald-500' },
    ];

    if (isLoading && tickets.length === 0) {
        return <div className="h-full flex items-center justify-center text-slate-400">Loading tickets...</div>;
    }

    return (
        <div className="h-[calc(100vh-8rem)] flex flex-col">
            {/* Header Controls */}
            <div className="mb-6 flex justify-between items-center shrink-0">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">{t.technical.title}</h1>
                    <p className="text-slate-500">{t.technical.subtitle}</p>
                </div>
                <div className="flex gap-3">
                    {/* Tab switcher */}
                    <div className="flex bg-slate-100 rounded-xl p-1">
                        <button
                            onClick={() => setActiveTab('kanban')}
                            className={clsx(
                                "px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2",
                                activeTab === 'kanban' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                            )}
                        >
                            <Wrench size={16} /> {t.technical.list}
                        </button>
                        <button
                            onClick={() => setActiveTab('assets')}
                            className={clsx(
                                "px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2",
                                activeTab === 'assets' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                            )}
                        >
                            <Box size={16} /> {t.technical.tabAssets}
                        </button>
                        <button
                            onClick={() => setActiveTab('maintenance')}
                            className={clsx(
                                "px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2",
                                activeTab === 'maintenance' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                            )}
                        >
                            <Calendar size={16} /> {t.technical.tabMaintenance}
                        </button>
                        <button
                            onClick={() => setActiveTab('stats')}
                            className={clsx(
                                "px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2",
                                activeTab === 'stats' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                            )}
                        >
                            <BarChart3 size={16} /> {t.technical.stats}
                        </button>
                    </div>

                    {activeTab === 'kanban' && (
                        <>
                            <div className="relative">
                                <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                                <input className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20" placeholder={t.technical.list + "..."} />
                            </div>
                            <button onClick={() => setIsCreateModalOpen(true)} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-bold transition-colors shadow-lg shadow-blue-600/20">
                                <Plus size={18} /> {t.technical.createTicket}
                            </button>
                        </>
                    )}
                </div>
            </div>

            {/* Tab Content */}
            {activeTab === 'kanban' && (
                /* Kanban Board */
                <div className="flex-1 overflow-x-auto overflow-y-hidden pb-4">
                    <div className="flex bg-slate-100/50 p-1.5 rounded-2xl h-full w-max min-w-full gap-4">
                        {columns.map(col => (
                            <div key={col.id} className="w-80 flex flex-col bg-slate-100/50 rounded-xl overflow-hidden">
                                {/* Column Header */}
                                <div className="p-3 flex items-center justify-between bg-white border-b border-slate-100 shadow-sm z-10">
                                    <h3 className="font-bold text-slate-700 flex items-center gap-2 text-sm">
                                        <col.icon size={16} className={col.color} />
                                        {col.title}
                                    </h3>
                                    <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-lg text-xs font-bold">
                                        {tickets.filter(t => t.status === col.id).length}
                                    </span>
                                </div>

                                {/* Column Content */}
                                <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
                                    {tickets.filter(t => t.status === col.id).map(ticket => (
                                        <motion.div
                                            layoutId={`ticket-${ticket.id}`}
                                            key={ticket.id}
                                            className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-grab active:cursor-grabbing group relative"
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <span className={clsx("text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider", getPriorityColor(ticket.priority))}>
                                                    {ticket.priority}
                                                </span>
                                                <button className="text-slate-300 hover:text-slate-600">
                                                    <MoreVertical size={16} />
                                                </button>
                                            </div>
                                            <h4 className="font-bold text-slate-800 text-sm mb-1 leading-snug">{ticket.title}</h4>
                                            <p className="text-xs text-slate-500 flex items-center gap-1 mb-3">
                                                <Wrench size={12} /> {ticket.location}
                                            </p>

                                            <div className="flex items-center justify-between pt-3 border-t border-slate-50">
                                                {(ticket.assignees && ticket.assignees.length > 0) ? (
                                                    <div className="flex -space-x-2 overflow-hidden">
                                                        {ticket.assignees.map((assignee) => (
                                                            <div key={assignee.id} className="inline-block h-6 w-6 rounded-full ring-2 ring-white bg-blue-100 flex items-center justify-center text-[9px] font-bold text-blue-600" title={assignee.name}>
                                                                {assignee.name.charAt(0)}
                                                            </div>
                                                        ))}
                                                        {ticket.assignees.length > 3 && (
                                                            <div className="inline-block h-6 w-6 rounded-full ring-2 ring-white bg-slate-100 flex items-center justify-center text-[9px] font-bold text-slate-500">
                                                                +{ticket.assignees.length - 3}
                                                            </div>
                                                        )}
                                                    </div>
                                                ) : (
                                                    ticket.assignedTo ? (
                                                        <div className="flex items-center gap-1.5" title={ticket.assignedTo.name}>
                                                            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                                                                {ticket.assignedTo.name.charAt(0)}
                                                            </div>
                                                            <span className="text-xs text-slate-600 font-medium truncate max-w-[80px]">{ticket.assignedTo.name}</span>
                                                        </div>
                                                    ) : (
                                                        <span className="text-xs text-slate-400 italic">{t.technical.unassigned}</span>
                                                    )
                                                )}
                                                <span className="text-[10px] text-slate-400">{new Date(ticket.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                            </div>

                                            {/* Hover Actions */}
                                            <div className="absolute inset-0 bg-white/95 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 rounded-xl z-20">
                                                <button onClick={() => openTicketDetail(ticket)} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100" title={t.technical.tooltipDetail}>
                                                    <Eye size={18} />
                                                </button>
                                                {ticket.status !== 'COMPLETED' && (
                                                    <button onClick={() => openEditModal(ticket)} className="p-2 bg-amber-50 text-amber-600 rounded-lg hover:bg-amber-100" title={t.technical.tooltipEdit}>
                                                        <Edit size={18} />
                                                    </button>
                                                )}
                                                <button onClick={() => handleDeleteTicket(ticket.id)} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100" title={t.technical.tooltipDelete}>
                                                    <Trash2 size={18} />
                                                </button>
                                                {ticket.status === 'PENDING' || ticket.status === 'ASSIGNED' ? (
                                                    <button
                                                        onClick={() => openAssignModal(ticket)}
                                                        className="p-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100" title={t.technical.tooltipAssign}>
                                                        <UserPlus size={18} />
                                                    </button>
                                                ) : null}
                                                {ticket.status !== 'COMPLETED' && ticket.status !== 'PENDING' && (
                                                    <button
                                                        onClick={() => handleUpdateStatus(ticket.id, ticket.status)}
                                                        className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100" title={t.technical.tooltipForward}>
                                                        <ArrowRight size={18} />
                                                    </button>
                                                )}
                                            </div>
                                        </motion.div>
                                    ))}
                                    {tickets.filter(t => t.status === col.id).length === 0 && (
                                        <div className="text-center py-8 text-slate-400 text-xs italic opacity-70">
                                            Trống
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Stats Dashboard */}
            {activeTab === 'stats' && (
                <div className="flex-1 overflow-y-auto">
                    {statsLoading ? (
                        <div className="flex items-center justify-center h-64 text-slate-400">Đang tải thống kê...</div>
                    ) : stats ? (
                        <div className="space-y-6">
                            {/* Summary Cards */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                                            <FileText className="text-blue-600" size={20} />
                                        </div>
                                        <span className="text-slate-500 text-sm font-medium">{t.technical.statsTotal}</span>
                                    </div>
                                    <p className="text-3xl font-black text-slate-800">{stats.summary.totalTickets}</p>
                                </motion.div>

                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
                                            <AlertCircle className="text-red-600" size={20} />
                                        </div>
                                        <span className="text-slate-500 text-sm font-medium">{t.technical.statsPending}</span>
                                    </div>
                                    <p className="text-3xl font-black text-slate-800">{stats.summary.pendingTickets}</p>
                                </motion.div>

                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                                            <Clock className="text-amber-600" size={20} />
                                        </div>
                                        <span className="text-slate-500 text-sm font-medium">{t.technical.statsProcessing}</span>
                                    </div>
                                    <p className="text-3xl font-black text-slate-800">{stats.summary.inProgressTickets + stats.summary.assignedTickets}</p>
                                </motion.div>

                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                                            <CheckCircle2 className="text-emerald-600" size={20} />
                                        </div>
                                        <span className="text-slate-500 text-sm font-medium">{t.technical.statsCompleted}</span>
                                    </div>
                                    <p className="text-3xl font-black text-slate-800">{stats.summary.completedTickets}</p>
                                    <p className="text-sm text-emerald-600 font-bold">{stats.summary.completionRate}% hoàn thành</p>
                                </motion.div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Top Locations - Tần suất hư hỏng */}
                                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                                    <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                                        <MapPin className="text-red-500" size={20} />
                                        Vị trí hay hư hỏng (Top 10)
                                    </h3>
                                    <div className="space-y-3">
                                        {stats.topLocations.map((loc, idx) => (
                                            <div key={loc.location} className="flex items-center gap-3">
                                                <span className={clsx(
                                                    "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold",
                                                    idx === 0 ? "bg-red-100 text-red-600" :
                                                        idx === 1 ? "bg-orange-100 text-orange-600" :
                                                            idx === 2 ? "bg-yellow-100 text-yellow-600" :
                                                                "bg-slate-100 text-slate-600"
                                                )}>
                                                    {idx + 1}
                                                </span>
                                                <div className="flex-1">
                                                    <p className="text-sm font-medium text-slate-700 truncate">{loc.location}</p>
                                                    <div className="h-2 bg-slate-100 rounded-full mt-1 overflow-hidden">
                                                        <div
                                                            className={clsx(
                                                                "h-full rounded-full transition-all",
                                                                idx === 0 ? "bg-red-500" :
                                                                    idx === 1 ? "bg-orange-500" :
                                                                        idx === 2 ? "bg-yellow-500" :
                                                                            "bg-slate-400"
                                                            )}
                                                            style={{ width: `${(loc.count / (stats.topLocations[0]?.count || 1)) * 100}%` }}
                                                        />
                                                    </div>
                                                </div>
                                                <span className="text-sm font-bold text-slate-600">{loc.count}</span>
                                            </div>
                                        ))}
                                        {stats.topLocations.length === 0 && (
                                            <p className="text-slate-400 text-sm text-center py-4">Chưa có dữ liệu</p>
                                        )}
                                    </div>
                                </motion.div>

                                {/* Top Staff - Nhân viên được giao việc nhiều */}
                                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                                    <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                                        <Users className="text-blue-500" size={20} />
                                        {t.technical.topStaff}
                                    </h3>
                                    <div className="space-y-3">
                                        {stats.topStaff.map((staff, idx) => (
                                            <div key={staff.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                                                <div className={clsx(
                                                    "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm",
                                                    idx === 0 ? "bg-yellow-400 text-yellow-900" :
                                                        idx === 1 ? "bg-slate-300 text-slate-700" :
                                                            idx === 2 ? "bg-amber-600 text-white" :
                                                                "bg-blue-100 text-blue-600"
                                                )}>
                                                    {staff.fullName?.charAt(0) || '?'}
                                                </div>
                                                <div className="flex-1">
                                                    <p className="font-bold text-slate-800">{staff.fullName}</p>
                                                    <p className="text-xs text-slate-500">{staff.position}</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-2xl font-black text-blue-600">{staff.assignmentCount}</p>
                                                    <p className="text-[10px] text-slate-400 uppercase">công việc</p>
                                                </div>
                                            </div>
                                        ))}
                                        {stats.topStaff.length === 0 && (
                                            <p className="text-slate-400 text-sm text-center py-4">Chưa có dữ liệu</p>
                                        )}
                                    </div>
                                </motion.div>
                            </div>

                            {/* Weekly Activity Chart */}
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                                <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                                    <Activity className="text-indigo-500" size={20} />
                                    Hoạt động 7 ngày qua
                                </h3>
                                <div className="flex items-end justify-between gap-2 h-40">
                                    {stats.dailyStats.map((day, idx) => {
                                        const maxTotal = Math.max(...stats.dailyStats.map(d => d.total), 1);
                                        const barHeight = (day.total / maxTotal) * 100;
                                        const completedHeight = day.total > 0 ? (day.completed / day.total) * barHeight : 0;
                                        const dayLabel = new Date(day.date).toLocaleDateString('vi-VN', { weekday: 'short' });

                                        return (
                                            <div key={day.date} className="flex-1 flex flex-col items-center">
                                                <div className="relative w-full h-32 flex items-end justify-center">
                                                    <div
                                                        className="w-full max-w-[40px] bg-slate-200 rounded-t-lg relative overflow-hidden transition-all"
                                                        style={{ height: `${barHeight}%` }}
                                                    >
                                                        <div
                                                            className="absolute bottom-0 w-full bg-emerald-500 transition-all"
                                                            style={{ height: `${completedHeight}%` }}
                                                        />
                                                    </div>
                                                    {day.urgent > 0 && (
                                                        <div className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full animate-pulse" title={`${day.urgent} khẩn cấp`} />
                                                    )}
                                                </div>
                                                <p className="text-xs text-slate-500 mt-2 font-medium">{dayLabel}</p>
                                                <p className="text-xs text-slate-800 font-bold">{day.total}</p>
                                            </div>
                                        );
                                    })}
                                </div>
                                <div className="flex justify-center gap-6 mt-4 pt-4 border-t border-slate-100">
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded bg-slate-200" />
                                        <span className="text-xs text-slate-500">Tổng ticket</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded bg-emerald-500" />
                                        <span className="text-xs text-slate-500">Đã hoàn thành</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded-full bg-red-500" />
                                        <span className="text-xs text-slate-500">Khẩn cấp/Cao</span>
                                    </div>
                                </div>
                            </motion.div>

                            {/* Priority Distribution */}
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                                <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                                    <TrendingUp className="text-purple-500" size={20} />
                                    Phân bố theo mức độ ưu tiên
                                </h3>
                                <div className="flex gap-4">
                                    {stats.priorityCounts.map(p => {
                                        const total = stats.priorityCounts.reduce((acc, curr) => acc + curr.count, 0);
                                        const percentage = total > 0 ? Math.round((p.count / total) * 100) : 0;
                                        const colorClass = p.priority === 'URGENT' ? 'bg-red-500' :
                                            p.priority === 'HIGH' ? 'bg-orange-500' :
                                                p.priority === 'MEDIUM' ? 'bg-blue-500' : 'bg-slate-400';
                                        return (
                                            <div key={p.priority} className="flex-1 text-center">
                                                <div className="relative pt-1">
                                                    <div className="flex mb-2 items-center justify-center">
                                                        <span className={clsx("text-2xl font-black",
                                                            p.priority === 'URGENT' ? 'text-red-600' :
                                                                p.priority === 'HIGH' ? 'text-orange-600' :
                                                                    p.priority === 'MEDIUM' ? 'text-blue-600' : 'text-slate-600'
                                                        )}>
                                                            {p.count}
                                                        </span>
                                                    </div>
                                                    <div className="overflow-hidden h-3 text-xs flex rounded-full bg-slate-100">
                                                        <div style={{ width: `${percentage}%` }} className={clsx("shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center rounded-full transition-all", colorClass)} />
                                                    </div>
                                                    <p className="text-xs text-slate-500 mt-2 font-medium uppercase">{p.priority}</p>
                                                    <p className="text-xs text-slate-400">{percentage}%</p>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </motion.div>
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-64 text-slate-400">Không có dữ liệu thống kê</div>
                    )}
                </div>
            )}

            {/* Assets Tab */}
            {activeTab === 'assets' && (
                <div className="flex-1 overflow-y-auto">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-lg font-bold text-slate-800">Danh sách thiết bị ({assets.length})</h2>
                        <button onClick={() => setIsAddAssetModalOpen(true)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/20">
                            <Plus size={18} /> Thêm thiết bị
                        </button>
                    </div>

                    {assetsLoading ? (
                        <div className="text-center py-10 text-slate-400">Đang tải...</div>
                    ) : assets.length === 0 ? (
                        <div className="text-center py-20 text-slate-400">
                            <Box size={48} className="mx-auto mb-4 opacity-50" />
                            <p>Chưa có thiết bị nào. Hãy thêm thiết bị đầu tiên!</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {assets.map(asset => (
                                <motion.div key={asset.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                                    className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm hover:shadow-md transition-shadow"
                                >
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex items-center gap-3">
                                            <div className={clsx("w-10 h-10 rounded-xl flex items-center justify-center",
                                                asset.category === 'HVAC' ? "bg-blue-100 text-blue-600" :
                                                    asset.category === 'ELECTRICAL' ? "bg-amber-100 text-amber-600" :
                                                        asset.category === 'PLUMBING' ? "bg-cyan-100 text-cyan-600" :
                                                            "bg-slate-100 text-slate-600"
                                            )}>
                                                <Cpu size={20} />
                                            </div>
                                            <div>
                                                <p className="font-bold text-slate-800">{asset.name}</p>
                                                <p className="text-xs text-slate-500">{asset.code}</p>
                                            </div>
                                        </div>
                                        <div className="flex flex-col items-end gap-2">
                                            <span className={clsx("px-2 py-0.5 rounded-full text-xs font-bold",
                                                asset.status === 'ACTIVE' ? "bg-emerald-100 text-emerald-600" :
                                                    asset.status === 'UNDER_REPAIR' ? "bg-amber-100 text-amber-600" :
                                                        "bg-red-100 text-red-500"
                                            )}>{asset.status}</span>

                                            {(session?.user?.position === 'LEADER' || session?.user?.role === 'ADMIN') && (
                                                <div className="flex gap-1">
                                                    <button onClick={() => handleToggleAssetStatus(asset)} title={asset.status === 'ACTIVE' ? "Tắt" : "Bật"} className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
                                                        {asset.status === 'ACTIVE' ? <ToggleRight className="text-emerald-500" size={18} /> : <ToggleLeft className="text-slate-400" size={18} />}
                                                    </button>
                                                    <button onClick={() => openEditAssetModal(asset)} title="Sửa" className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-400 hover:text-blue-500 transition-colors">
                                                        <Edit size={16} />
                                                    </button>
                                                    <button onClick={() => handleDeleteAsset(asset.id, asset.name)} title="Xóa" className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-400 hover:text-red-500 transition-colors">
                                                        <Trash2 size={16} />
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    <div className="space-y-1 text-sm">
                                        <p className="text-slate-600"><MapPin size={14} className="inline mr-1" />{asset.location}</p>
                                        <p className="text-slate-500">Loại: {getCategoryLabel(asset.category)}</p>
                                        {asset.manufacturer && <p className="text-slate-400 text-xs">Hãng: {asset.manufacturer} {asset.model && `- ${asset.model}`}</p>}
                                    </div>
                                    <div className="mt-3 pt-3 border-t border-slate-100 flex justify-between items-center">
                                        <button onClick={() => openHistoryModal(asset)} className="text-xs text-slate-500 hover:text-blue-600 flex items-center gap-1">
                                            <Clock size={12} /> Lịch sử ({asset._count?.maintenanceHistory || 0})
                                        </button>
                                        <button onClick={() => { setSelectedAssetForSchedule(asset.id); setIsAddScheduleModalOpen(true); }}
                                            className="text-xs text-blue-600 font-bold hover:underline">+ Lịch bảo trì</button>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* Maintenance Tab */}
            {activeTab === 'maintenance' && (
                <div className="flex-1 overflow-y-auto">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-lg font-bold text-slate-800">Lịch bảo trì định kỳ ({schedules.length})</h2>
                        <div className="flex gap-2">
                            <button onClick={handleGenerateTickets} className="flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-xl font-bold hover:bg-blue-200">
                                <Cpu size={18} /> Kiểm tra & Tạo Ticket
                            </button>
                            <button onClick={() => setIsAddScheduleModalOpen(true)} className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-600/20">
                                <Plus size={18} /> Tạo lịch bảo trì
                            </button>
                        </div>
                    </div>

                    {schedules.length === 0 ? (
                        <div className="text-center py-20 text-slate-400">
                            <Calendar size={48} className="mx-auto mb-4 opacity-50" />
                            <p>Chưa có lịch bảo trì. Hãy tạo lịch cho các thiết bị!</p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {schedules.map(schedule => {
                                const isDue = schedule.nextDueAt && new Date(schedule.nextDueAt) <= new Date();
                                return (
                                    <motion.div key={schedule.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                                        className={clsx("bg-white rounded-xl p-4 border shadow-sm flex items-center justify-between",
                                            isDue ? "border-red-200 bg-red-50/50" : "border-slate-100"
                                        )}
                                    >
                                        <div className="flex items-center gap-4">
                                            <div className={clsx("w-12 h-12 rounded-xl flex items-center justify-center",
                                                isDue ? "bg-red-100 text-red-600" : "bg-emerald-100 text-emerald-600"
                                            )}>
                                                {isDue ? <AlertTriangle size={24} /> : <CheckCircle2 size={24} />}
                                            </div>
                                            <div>
                                                <p className="font-bold text-slate-800">{schedule.title}</p>
                                                <p className="text-sm text-slate-500">
                                                    <Cpu size={12} className="inline mr-1" />
                                                    {schedule.asset?.name} ({schedule.asset?.code}) - {schedule.asset?.location}
                                                </p>
                                                <p className="text-xs text-slate-400 mt-1">
                                                    Tần suất: <span className="font-medium">{getFrequencyLabel(schedule.frequency)}</span>
                                                    {schedule.lastExecutedAt && ` | Lần cuối: ${new Date(schedule.lastExecutedAt).toLocaleDateString('en-GB')}`}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            {schedule.nextDueAt && (
                                                <p className={clsx("text-sm font-bold", isDue ? "text-red-600" : "text-slate-600")}>
                                                    {isDue ? "QUÁ HẠN!" : `Đến hạn: ${new Date(schedule.nextDueAt).toLocaleDateString('en-GB')}`}
                                                </p>
                                            )}
                                            <button onClick={() => handleCompleteSchedule(schedule.id)}
                                                className="mt-2 text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-emerald-700">
                                                ✓ Hoàn thành
                                            </button>
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </div>
                    )}
                </div>
            )}

            {/* Modal Create Ticket */}
            <AnimatePresence>
                {isCreateModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800">{t.technical.createTicket}</h3>
                                <button onClick={() => setIsCreateModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="space-y-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Tiêu đề sự cố</label>
                                    <input value={newTicket.title} onChange={e => setNewTicket({ ...newTicket, title: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none font-medium" placeholder="VD: Hỏng bóng đèn" />
                                </div>

                                <div className="mb-2">
                                    <LocationSelector
                                        value={newTicket.location}
                                        onChange={(val) => setNewTicket({ ...newTicket, location: val })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Mức độ ưu tiên</label>
                                        <select value={newTicket.priority} onChange={e => setNewTicket({ ...newTicket, priority: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none bg-white">
                                            <option value="LOW">Thấp</option>
                                            <option value="MEDIUM">Trung bình</option>
                                            <option value="HIGH">Cao</option>
                                            <option value="URGENT">Khẩn cấp</option>
                                        </select>
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Số lượng</label>
                                        <input type="number" min="1" value={newTicket.quantity || 1} onChange={e => setNewTicket({ ...newTicket, quantity: parseInt(e.target.value) || 1 })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none" />
                                    </div>
                                    <div className="space-y-1 col-span-2">
                                        <label className="text-xs font-bold text-slate-500">Đơn vị tính</label>
                                        <input value={newTicket.unit || ''} onChange={e => setNewTicket({ ...newTicket, unit: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none" placeholder="VD: Cái, Bộ, Lần" />
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Mô tả chi tiết</label>
                                    <textarea value={newTicket.description} onChange={e => setNewTicket({ ...newTicket, description: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none" rows={3} placeholder="Mô tả kỹ hơn..." />
                                </div>
                            </div>
                            <div className="mt-6 flex gap-3">
                                <button onClick={() => setIsCreateModalOpen(false)} className="flex-1 py-2.5 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200">{t.common.cancel}</button>
                                <button onClick={handleCreateTicket} className="flex-1 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Edit Ticket */}
            <AnimatePresence>
                {isEditModalOpen && editingTicket && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <Edit size={20} className="text-amber-500" /> Chỉnh sửa sự cố
                                </h3>
                                <button onClick={() => setIsEditModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="space-y-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Tiêu đề sự cố</label>
                                    <input value={editFormData.title} onChange={e => setEditFormData({ ...editFormData, title: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none font-medium" />
                                </div>

                                <div className="mb-2">
                                    <LocationSelector
                                        value={editFormData.location}
                                        onChange={(val) => setEditFormData({ ...editFormData, location: val })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Mức độ ưu tiên</label>
                                        <select value={editFormData.priority} onChange={e => setEditFormData({ ...editFormData, priority: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none bg-white">
                                            <option value="LOW">Thấp</option>
                                            <option value="MEDIUM">Trung bình</option>
                                            <option value="HIGH">Cao</option>
                                            <option value="URGENT">Khẩn cấp</option>
                                        </select>
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Số lượng</label>
                                        <input type="number" min="1" value={editFormData.quantity || 1} onChange={e => setEditFormData({ ...editFormData, quantity: parseInt(e.target.value) || 1 })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none" />
                                    </div>
                                    <div className="space-y-1 col-span-2">
                                        <label className="text-xs font-bold text-slate-500">Đơn vị tính</label>
                                        <input value={editFormData.unit || ''} onChange={e => setEditFormData({ ...editFormData, unit: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none" placeholder="VD: Cái, Bộ, Lần" />
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Mô tả chi tiết</label>
                                    <textarea value={editFormData.description} onChange={e => setEditFormData({ ...editFormData, description: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none" rows={3} />
                                </div>
                            </div>
                            <div className="mt-6 flex gap-3">
                                <button onClick={() => setIsEditModalOpen(false)} className="flex-1 py-2.5 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200">{t.common.cancel}</button>
                                <button onClick={handleUpdateTicket} className="flex-1 py-2.5 bg-amber-500 text-white font-bold rounded-xl hover:bg-amber-600 shadow-lg shadow-amber-500/20">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Assign Staff */}
            <AnimatePresence>
                {isAssignModalOpen && selectedTicketForAssign && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <UserPlus className="text-blue-500" size={20} />
                                    Phân công nhân viên
                                </h3>
                                <button onClick={() => setIsAssignModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>

                            <div className="mb-4 p-3 bg-slate-50 rounded-xl">
                                <p className="text-sm text-slate-500">Ticket:</p>
                                <p className="font-bold text-slate-800">{selectedTicketForAssign.title}</p>
                                <p className="text-xs text-slate-500">{selectedTicketForAssign.location}</p>
                            </div>

                            <div className="space-y-2 max-h-60 overflow-y-auto">
                                <p className="text-xs font-bold text-slate-500 uppercase mb-2">Chọn nhân viên kỹ thuật {selectedStaffIds.length > 0 && `(${selectedStaffIds.length})`}:</p>
                                {staffList.length === 0 ? (
                                    <p className="text-slate-400 text-sm">Không có nhân viên kỹ thuật nào.</p>
                                ) : (
                                    staffList.map(staff => (
                                        <div
                                            key={staff.id}
                                            onClick={() => {
                                                if (selectedStaffIds.includes(staff.id)) {
                                                    setSelectedStaffIds(selectedStaffIds.filter(id => id !== staff.id));
                                                } else {
                                                    setSelectedStaffIds([...selectedStaffIds, staff.id]);
                                                }
                                            }}
                                            className={clsx(
                                                "p-3 rounded-xl border cursor-pointer transition-all flex items-center gap-3",
                                                selectedStaffIds.includes(staff.id)
                                                    ? "border-blue-500 bg-blue-50 ring-1 ring-blue-500"
                                                    : "border-slate-200 hover:bg-slate-50"
                                            )}
                                        >
                                            <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                                                {staff.fullName.charAt(0)}
                                            </div>
                                            <div>
                                                <p className="font-bold text-slate-800">{staff.fullName}</p>
                                                <p className="text-xs text-slate-500">{staff.position}</p>
                                            </div>
                                            {selectedStaffIds.includes(staff.id) && (
                                                <CheckCircle2 className="ml-auto text-blue-500" size={20} />
                                            )}
                                        </div>
                                    ))
                                )}
                            </div>

                            <div className="mt-6 flex gap-3">
                                <button onClick={() => setIsAssignModalOpen(false)} className="flex-1 py-2.5 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200">{t.common.cancel}</button>
                                <button
                                    onClick={handleAssignStaff}
                                    disabled={selectedStaffIds.length === 0}
                                    className={clsx(
                                        "flex-1 py-2.5 font-bold rounded-xl shadow-lg transition-all",
                                        selectedStaffIds.length > 0
                                            ? "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20"
                                            : "bg-slate-200 text-slate-400 cursor-not-allowed"
                                    )}
                                >
                                    Phân công
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Add Asset */}
            <AnimatePresence>
                {isAddAssetModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800">Thêm thiết bị mới</h3>
                                <button onClick={() => setIsAddAssetModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Mã thiết bị *</label>
                                        <input value={newAsset.code} onChange={e => setNewAsset({ ...newAsset, code: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="VD: AC-B1-001" />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Loại thiết bị *</label>
                                        <select value={newAsset.category} onChange={e => setNewAsset({ ...newAsset, category: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl">
                                            <option value="HVAC">Điều hòa/Thông gió</option>
                                            <option value="ELECTRICAL">Điện</option>
                                            <option value="PLUMBING">Nước/Ống nước</option>
                                            <option value="FIRE_SAFETY">PCCC</option>
                                            <option value="ELEVATOR">Thang máy</option>
                                            <option value="GENERATOR">Máy phát điện</option>
                                            <option value="OTHER">Khác</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Tên thiết bị *</label>
                                    <input value={newAsset.name} onChange={e => setNewAsset({ ...newAsset, name: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="VD: Điều hòa Daikin 2HP" />
                                </div>

                                <div className="mb-2">
                                    <LocationSelector
                                        value={newAsset.location}
                                        onChange={(val) => setNewAsset({ ...newAsset, location: val })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Hãng sản xuất</label>
                                        <input value={newAsset.manufacturer} onChange={e => setNewAsset({ ...newAsset, manufacturer: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="VD: Daikin" />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Model</label>
                                        <input value={newAsset.model} onChange={e => setNewAsset({ ...newAsset, model: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="VD: FTXM35" />
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsAddAssetModalOpen(false)} className="px-4 py-2 text-slate-500 font-bold hover:bg-slate-100 rounded-xl">Hủy</button>
                                <button onClick={handleCreateAsset} className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-600/20">Thêm thiết bị</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Edit Asset */}
            <AnimatePresence>
                {isEditAssetModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <Edit size={20} className="text-blue-500" /> Chỉnh sửa thiết bị
                                </h3>
                                <button onClick={() => setIsEditAssetModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Mã thiết bị *</label>
                                        <input value={editAssetFormData.code} onChange={e => setEditAssetFormData({ ...editAssetFormData, code: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Loại thiết bị *</label>
                                        <select value={editAssetFormData.category} onChange={e => setEditAssetFormData({ ...editAssetFormData, category: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl">
                                            <option value="HVAC">Điều hòa/Thông gió</option>
                                            <option value="ELECTRICAL">Điện</option>
                                            <option value="PLUMBING">Nước/Ống nước</option>
                                            <option value="FIRE_SAFETY">PCCC</option>
                                            <option value="ELEVATOR">Thang máy</option>
                                            <option value="GENERATOR">Máy phát điện</option>
                                            <option value="OTHER">Khác</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Tên thiết bị *</label>
                                    <input value={editAssetFormData.name} onChange={e => setEditAssetFormData({ ...editAssetFormData, name: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" />
                                </div>

                                <div className="mb-2">
                                    <LocationSelector
                                        value={editAssetFormData.location}
                                        onChange={(val) => setEditAssetFormData({ ...editAssetFormData, location: val })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Hãng sản xuất</label>
                                        <input value={editAssetFormData.manufacturer} onChange={e => setEditAssetFormData({ ...editAssetFormData, manufacturer: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-500">Model</label>
                                        <input value={editAssetFormData.model} onChange={e => setEditAssetFormData({ ...editAssetFormData, model: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" />
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsEditAssetModalOpen(false)} className="px-4 py-2 text-slate-500 font-bold hover:bg-slate-100 rounded-xl">Hủy</button>
                                <button onClick={handleUpdateAsset} className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-600/20">Cập nhật</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Add Schedule */}
            <AnimatePresence>
                {isAddScheduleModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl">
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800">Tạo lịch bảo trì định kỳ</h3>
                                <button onClick={() => { setIsAddScheduleModalOpen(false); setSelectedAssetForSchedule(null); }}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="space-y-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Chọn thiết bị *</label>
                                    <select value={selectedAssetForSchedule || ''} onChange={e => setSelectedAssetForSchedule(parseInt(e.target.value))} className="w-full p-2.5 border border-slate-200 rounded-xl">
                                        <option value="">-- Chọn thiết bị --</option>
                                        {assets.map(a => <option key={a.id} value={a.id}>{a.code} - {a.name} ({a.location})</option>)}
                                    </select>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Công việc bảo trì *</label>
                                    <input value={newSchedule.title} onChange={e => setNewSchedule({ ...newSchedule, title: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="VD: Vệ sinh filter điều hòa" />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Tần suất *</label>
                                    <select value={newSchedule.frequency} onChange={e => setNewSchedule({ ...newSchedule, frequency: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl">
                                        <option value="DAILY">Hàng ngày</option>
                                        <option value="WEEKLY">Hàng tuần</option>
                                        <option value="MONTHLY">Hàng tháng</option>
                                        <option value="QUARTERLY">Hàng quý (3 tháng)</option>
                                        <option value="YEARLY">Hàng năm</option>
                                    </select>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Người thực hiện/Checklist</label>
                                    <textarea value={newSchedule.checklistItems} onChange={e => setNewSchedule({ ...newSchedule, checklistItems: e.target.value })} rows={3} className="w-full p-2.5 border border-slate-200 rounded-xl" placeholder="Kiểm tra gas&#10;Vệ sinh filter&#10;Kiểm tra dàn lạnh" />
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-bold text-slate-500">Ngày bắt đầu / Lần tới</label>
                                    <DateInput
                                        value={newSchedule.nextDueAt}
                                        onChange={(e: any) => setNewSchedule({ ...newSchedule, nextDueAt: e.target.value })}
                                        className="w-full p-2.5 border border-slate-200 rounded-xl"
                                    />
                                    <p className="text-[10px] text-slate-400 italic">Mặc định là hôm nay nếu không chọn</p>
                                </div>
                            </div>
                            <div className="mt-6 flex gap-3">
                                <button onClick={() => { setIsAddScheduleModalOpen(false); setSelectedAssetForSchedule(null); }} className="flex-1 py-2.5 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200">{t.common.cancel}</button>
                                <button onClick={handleCreateSchedule} className="flex-1 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-500/20">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Ticket Detail */}
            <AnimatePresence>
                {isDetailModalOpen && selectedTicketForDetail && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">{selectedTicketForDetail.title}</h3>
                                    <p className="text-xs text-slate-500 flex items-center gap-1"><MapPin size={12} /> {selectedTicketForDetail.location}</p>
                                </div>
                                <button onClick={() => { setIsDetailModalOpen(false); setSelectedTicketForDetail(null); setTicketComments([]); }}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-5 space-y-6">
                                {/* Info Section */}
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <p className="text-slate-500 text-xs font-bold uppercase">Trạng thái</p>
                                        <span className={clsx("inline-flex items-center gap-1 font-bold mt-1",
                                            selectedTicketForDetail.status === 'PENDING' ? "text-red-500" :
                                                selectedTicketForDetail.status === 'ASSIGNED' ? "text-blue-500" :
                                                    selectedTicketForDetail.status === 'IN_PROGRESS' ? "text-amber-500" : "text-emerald-500"
                                        )}>
                                            {selectedTicketForDetail.status === 'PENDING' && <AlertCircle size={14} />}
                                            {selectedTicketForDetail.status === 'ASSIGNED' && <User size={14} />}
                                            {selectedTicketForDetail.status === 'IN_PROGRESS' && <Clock size={14} />}
                                            {selectedTicketForDetail.status === 'COMPLETED' && <CheckCircle2 size={14} />}
                                            {selectedTicketForDetail.status}
                                        </span>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs font-bold uppercase">Mức độ</p>
                                        <span className={clsx("inline-block mt-1 px-2 py-0.5 rounded text-xs font-bold border", getPriorityColor(selectedTicketForDetail.priority))}>
                                            {selectedTicketForDetail.priority}
                                        </span>
                                    </div>
                                    <div className="col-span-2">
                                        <p className="text-slate-500 text-xs font-bold uppercase mb-1">Mô tả</p>
                                        <div className="bg-slate-50 p-3 rounded-xl text-slate-700 border border-slate-100">
                                            {selectedTicketForDetail.description || "Không có mô tả chi tiết."}
                                        </div>
                                    </div>
                                    <div className="col-span-2">
                                        <p className="text-slate-500 text-xs font-bold uppercase mb-2">Người được phân công</p>
                                        {(selectedTicketForDetail.assignees && selectedTicketForDetail.assignees.length > 0) ? (
                                            <div className="flex flex-wrap gap-2">
                                                {selectedTicketForDetail.assignees.map(u => (
                                                    <div key={u.id} className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1.5 rounded-lg border border-blue-100">
                                                        <div className="w-5 h-5 rounded-full bg-blue-200 flex items-center justify-center text-[10px] font-bold">
                                                            {u.name.charAt(0)}
                                                        </div>
                                                        <span className="text-xs font-bold">{u.name}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <p className="text-slate-400 italic text-xs">Chưa phân công</p>
                                        )}
                                    </div>
                                </div>

                                {/* Comments Section */}
                                <div className="border-t border-slate-100 pt-4">
                                    <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                                        <MessageCircle size={18} className="text-blue-500" /> Trao đổi công việc
                                    </h4>

                                    <div className="space-y-4 mb-4">
                                        {ticketComments.length === 0 ? (
                                            <div className="text-center py-6 text-slate-400 text-xs italic">Chưa có trao đổi nào.</div>
                                        ) : (
                                            ticketComments.map(comment => (
                                                <div key={comment.id} className={clsx("flex gap-3", comment.authorRole === 'LEADER' ? "flex-row-reverse" : "")}>
                                                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 border-2 border-white shadow-sm bg-blue-100 text-blue-600">
                                                        {comment.authorName.charAt(0)}
                                                    </div>
                                                    <div className={clsx("max-w-[80%]", comment.authorRole === 'LEADER' ? "text-right" : "")}>
                                                        <div className={clsx("text-xs font-bold mb-1", comment.authorRole === 'LEADER' ? "text-amber-600" : "text-blue-600")}>
                                                            {comment.authorName} <span className="opacity-50 font-normal text-[10px]"> • {new Date(comment.createdAt).toLocaleString('en-GB')}</span>
                                                        </div>
                                                        <div className={clsx("p-3 rounded-2xl text-sm shadow-sm inline-block text-left",
                                                            comment.authorRole === 'LEADER' ? "bg-amber-50 text-slate-800 rounded-tr-none border border-amber-100" : "bg-white text-slate-800 rounded-tl-none border border-slate-100"
                                                        )}>
                                                            {comment.content}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>

                                    <div className="flex gap-2">
                                        <input
                                            value={newComment}
                                            onChange={(e) => setNewComment(e.target.value)}
                                            onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                                            className="flex-1 p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 outline-none text-sm"
                                            placeholder="Nhập nội dung trao đổi..."
                                        />
                                        <button onClick={handleAddComment} disabled={!newComment.trim()} className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed">
                                            <Send size={18} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Asset History */}
            <AnimatePresence>
                {isHistoryModalOpen && selectedAssetForHistory && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl w-full max-w-lg shadow-2xl flex flex-col max-h-[80vh]">
                            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">Lịch sử thiết bị</h3>
                                    <p className="text-xs text-slate-500">{selectedAssetForHistory.name} ({selectedAssetForHistory.code})</p>
                                </div>
                                <button onClick={() => setIsHistoryModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-5">
                                {assetHistory.length === 0 ? (
                                    <div className="text-center py-10 text-slate-400">
                                        <Clock size={48} className="mx-auto mb-3 opacity-30" />
                                        <p>Chưa có lịch sử sửa chữa/bảo trì nào.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-4">
                                        {assetHistory.map((h: any) => (
                                            <div key={h.id} className="relative pl-6 border-l-2 border-slate-200 pb-2 last:pb-0">
                                                <div className={clsx("absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 border-white",
                                                    h.type === 'PREVENTIVE' ? "bg-emerald-500" :
                                                        h.type === 'CORRECTIVE' ? "bg-amber-500" : "bg-red-500"
                                                )}></div>
                                                <p className="text-xs text-slate-400 font-bold mb-1">{new Date(h.performedAt).toLocaleDateString('vi-VN')}</p>
                                                <p className="font-bold text-slate-800 text-sm">{h.description}</p>
                                                <div className="flex gap-2 mt-1">
                                                    <span className="text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-medium">
                                                        {h.type === 'PREVENTIVE' && 'Bảo trì định kỳ'}
                                                        {h.type === 'CORRECTIVE' && 'Sửa chữa'}
                                                        {h.type === 'EMERGENCY' && 'Khẩn cấp'}
                                                    </span>
                                                    {h.cost > 0 && <span className="text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-medium">{h.cost.toLocaleString()} đ</span>}
                                                </div>
                                                {h.notes && <p className="text-xs text-slate-500 mt-1 italic">"{h.notes}"</p>}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            <Toast
                message={toast.message}
                type={toast.type}
                isVisible={toast.isVisible}
                onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
            />

            <ConfirmModal
                isOpen={confirmConfig.isOpen}
                onClose={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
                onConfirm={confirmConfig.onConfirm}
                title={confirmConfig.title}
                message={confirmConfig.message}
                variant={confirmConfig.variant}
            />
        </div>
    );
}

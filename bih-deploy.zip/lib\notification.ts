import { prisma } from "./prisma";

/**
 * @deprecated Use createNotification from lib/notifications.ts instead
 * Legacy helper - kept for backward compatibility
 */
export async function createNotification(
    userId: number,
    title: string,
    message: string,
    linkType?: string,
    linkId?: number,
    type: "INFO" | "SUCCESS" | "WARNING" | "URGENT" = "INFO"
) {
    try {
        await prisma.notification.create({
            data: {
                userId,
                title,
                message,
                type,
                ...(linkType && { linkType }),
                ...(linkId && { linkId })
            }
        });
    } catch (error) {
        console.error("Failed to create notification:", error);
    }
}

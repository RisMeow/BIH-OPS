import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(request: Request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Fetch last 100 transactions
        const transactions = await prisma.inventoryTransaction.findMany({
            take: 100,
            orderBy: {
                createdAt: 'desc'
            },
            include: {
                item: {
                    select: {
                        name: true,
                        sku: true,
                        unit: true
                    }
                },
                performedBy: {
                    select: {
                        fullName: true,
                        email: true
                    }
                }
            }
        });

        const formattedTransactions = transactions.map(t => ({
            id: t.id,
            date: t.createdAt,
            itemName: t.item.name,
            sku: t.item.sku,
            type: t.type,
            quantity: t.quantity,
            unit: t.item.unit,
            reason: t.reason,
            performedBy: t.performedBy?.fullName || "N/A",
            referenceId: t.referenceId
        }));

        return NextResponse.json(formattedTransactions);
    } catch (error) {
        console.error("Error fetching transactions:", error);
        return NextResponse.json({ error: "Failed to fetch transactions" }, { status: 500 });
    }
}

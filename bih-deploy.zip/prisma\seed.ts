import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
    // Create mock Users
    const techUser = await prisma.user.upsert({
        where: { username: 'tech_admin' },
        update: {},
        create: {
            username: 'tech_admin',
            password: 'password123',
            fullName: 'Trưởng phòng Kỹ thuật',
            role: 'TECHNICAL',
        },
    })

    // SEED LOCATIONS (BIH Standard Map)
    console.log('Seeding Locations...');

    // 1. BLOCK A (MAIN BUILDING)
    const blockA = await prisma.location.create({
        data: { name: 'Khu A (Block A)', code: 'BLK-A', type: 'BLOCK', description: 'Tòa nhà chính' }
    });

    // Floors for Block A
    const floorsA = ['Tầng 1', 'Tầng 2', 'Tầng 3', 'Tầng 4'];
    for (const floorName of floorsA) {
        const floor = await prisma.location.create({
            data: { name: floorName, type: 'FLOOR', parentId: blockA.id }
        });

        // Rooms per floor
        const rooms = [
            { name: `Phòng Khám ${floorName}-01`, type: 'ROOM' },
            { name: `Phòng Khám ${floorName}-02`, type: 'ROOM' },
            { name: `Sảnh Chờ ${floorName}`, type: 'PUBLIC' },
            { name: `WC Nam ${floorName}`, type: 'WC' },
            { name: `WC Nữ ${floorName}`, type: 'WC' },
        ];

        for (const r of rooms) {
            await prisma.location.create({
                data: { name: r.name, type: r.type, parentId: floor.id }
            });
        }
    }

    // 2. BLOCK B (EMERGENCY & INPATIENT)
    const blockB = await prisma.location.create({
        data: { name: 'Khu B (Cấp Cứu & Nội Trú)', code: 'BLK-B', type: 'BLOCK', description: 'Khu điều trị' }
    });

    const floorsB = ['Tầng G (Cấp Cứu)', 'Tầng 1', 'Tầng 2'];
    for (const floorName of floorsB) {
        const floor = await prisma.location.create({
            data: { name: floorName, type: 'FLOOR', parentId: blockB.id }
        });

        const rooms = [
            { name: `Phòng Bệnh ${floorName}-01`, type: 'ROOM' },
            { name: `Phòng Bệnh ${floorName}-02`, type: 'ROOM' },
            { name: `Trực Điều Dưỡng ${floorName}`, type: 'ROOM' },
        ];
        for (const r of rooms) {
            await prisma.location.create({
                data: { name: r.name, type: r.type, parentId: floor.id }
            });
        }
    }

    // 3. OUTDOOR (Environment)
    const outdoor = await prisma.location.create({
        data: { name: 'Khu Vực Ngoài Trời', code: 'OUT', type: 'BLOCK' }
    });

    await prisma.location.create({ data: { name: 'Cổng Chính', type: 'PUBLIC', parentId: outdoor.id } });
    await prisma.location.create({ data: { name: 'Nhà Xe Nhân Viên', type: 'PUBLIC', parentId: outdoor.id } });
    await prisma.location.create({ data: { name: 'Vườn Hoa Trung Tâm', type: 'PUBLIC', parentId: outdoor.id } });
    await prisma.location.create({ data: { name: 'Khu Xử Lý Rác', type: 'RESTRICTED', parentId: outdoor.id } });

    console.log('Seed data created successfully.')
}

main()
    .then(async () => {
        await prisma.$disconnect()
    })
    .catch(async (e) => {
        console.error(e)
        await prisma.$disconnect()
        process.exit(1)
    })

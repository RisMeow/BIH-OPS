import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { format } from "date-fns";
import { vi } from "date-fns/locale";

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session || !["ADMIN", "MANAGER", "LEADER"].includes(session.user.role)) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const moduleName = searchParams.get("module") || "ALL";

    try {
        let csvContent = "";
        const header = ["ID", "Loại yêu cầu", "Mô tả", "Vị trí", "Người yêu cầu", "Trạng thái", "Ngày tạo", "Người xử lý"].join(",") + "\n";
        csvContent += header;

        const formatDate = (date: Date) => format(date, "dd/MM/yyyy HH:mm", { locale: vi });
        const escapeCsv = (str: string | null | undefined) => {
            if (!str) return "";
            return `"${str.replace(/"/g, '""').replace(/\n/g, ' ')}"`;
        };

        const limit = 1000; // Limit records to prevent timeouts

        // Promise array to fetch data from selected modules
        const promises = [];

        if (moduleName === "ALL" || moduleName === "TECHNICAL") {
            promises.push(prisma.maintenanceRequest.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `TECH-${r.id}`, "Kỹ thuật", r.title, r.location, "N/A", r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        if (moduleName === "ALL" || moduleName === "NURSING") {
            promises.push(prisma.nursingRequest.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `NUR-${r.id}`, "Hộ lý", r.requestType, r.roomNumber, r.patientName, r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        if (moduleName === "ALL" || moduleName === "DRIVER") {
            promises.push(prisma.transportRequest.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `DRV-${r.id}`, "Đội xe", r.tripType, `${r.destination} (Đón: ${r.pickupLocation})`, r.passengerName, r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        if (moduleName === "ALL" || moduleName === "SECURITY") {
            promises.push(prisma.securityReport.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `SEC-${r.id}`, "An ninh", r.incidentType, r.location, r.reportedBy, r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        if (moduleName === "ALL" || moduleName === "SUPPLY") {
            promises.push(prisma.supplyRequest.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `SUP-${r.id}`, "Vật tư", r.itemName, "N/A", r.requester, r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        if (moduleName === "ALL" || moduleName === "ENVIRONMENT") {
            promises.push(prisma.cleaningRequest.findMany({
                take: limit, orderBy: { createdAt: 'desc' },
                include: { assignedTo: { select: { fullName: true } } }
            }).then(rows => rows.map(r => [
                `ENV-${r.id}`, "Môi trường", r.taskType, r.location, r.requestedBy, r.status, formatDate(r.createdAt), r.assignedTo?.fullName
            ])));
        }

        const results = await Promise.all(promises);
        const flattenedRows = results.flat();

        // Sort by date descending (approximate since IDs are mixed, but good enough for report)
        // ideally we would sort flattenedRows by date column, but string date is hard to sort.

        flattenedRows.forEach(row => {
            // Map row to CSV string
            const csvRow = row.map(cell => escapeCsv(cell || "")).join(",");
            csvContent += csvRow + "\n";
        });

        // Add BOM for Excel UTF-8 compatibility
        const bom = "\uFEFF";

        return new NextResponse(bom + csvContent, {
            headers: {
                "Content-Type": "text/csv; charset=utf-8",
                "Content-Disposition": `attachment; filename="baocao_${moduleName.toLowerCase()}_${format(new Date(), "ddMMyyyy")}.csv"`,
            },
        });

    } catch (error) {
        console.error("Export error:", error);
        return NextResponse.json({ error: "Export failed" }, { status: 500 });
    }
}

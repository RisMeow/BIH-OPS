import { NextResponse } from 'next/server';
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can manage driver tasks
function canManageDriver(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    const role = user.role?.toUpperCase();
    const position = user.position?.toUpperCase();

    if (role === 'ADMIN') return true;
    if (role === 'DRIVER' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(position)) return true;
    return false;
}

// GET: Get single request detail
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const requestDetail = await prisma.transportRequest.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                vehicle: { select: { id: true, vehicleType: true, licensePlate: true } }
            }
        });

        if (!requestDetail) return NextResponse.json({ error: "Not found" }, { status: 404 });
        return NextResponse.json(requestDetail);
    } catch (error) {
        return NextResponse.json({ error: "Server Error" }, { status: 500 });
    }
}

// PATCH: Cập nhật trạng thái hoặc phân công
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { assignedToId, status, isArchived, rejectReason } = body;

        const updateData: Record<string, unknown> = {};

        // ARCHIVE: Leader/Admin OR Assigned Driver can archive
        if (isArchived !== undefined) {
            const currentRequest = await prisma.transportRequest.findUnique({ where: { id } });

            const userId = parseInt(String(user.id));
            const currentAssignedId = currentRequest?.assignedToId ? parseInt(String(currentRequest.assignedToId)) : null;

            const isManager = canManageDriver(user);
            const isAssigned = currentAssignedId === userId;
            const isDriver = (user.role?.toUpperCase() === 'DRIVER');
            const isCompleted = currentRequest?.status === 'COMPLETED';

            if (!isManager && !isAssigned && !(isDriver && isCompleted)) {
                return NextResponse.json({ error: "Permission denied" }, { status: 403 });
            }
            updateData.isArchived = isArchived;
        }

        // ASSIGN: Only leaders/admin can assign
        if (assignedToId !== undefined || (body.vehicleId !== undefined)) {
            if (!canManageDriver(user)) {
                return NextResponse.json({ error: "Permission denied: Only Driver Leader can assign tasks" }, { status: 403 });
            }
            if (assignedToId !== undefined) updateData.assignedToId = assignedToId ? parseInt(assignedToId) : null;
            if (body.vehicleId !== undefined) updateData.vehicleId = body.vehicleId ? parseInt(body.vehicleId) : null;

            if (!status || status === 'PENDING') {
                updateData.status = 'ASSIGNED';
            }
        }

        // STATUS CHANGE
        if (status) {
            // APPROVE/REJECT: Only leaders can do this
            if (['APPROVED', 'REJECTED'].includes(status)) {
                if (!canManageDriver(user)) return NextResponse.json({ error: "Permission denied" }, { status: 403 });
            }
            if (status === 'COMPLETED') {
                const currentRequest = await prisma.transportRequest.findUnique({ where: { id } });
                if (currentRequest?.assignedToId !== user.id && !canManageDriver(user)) {
                    return NextResponse.json({ error: "Permission denied" }, { status: 403 });
                }
                updateData.completedAt = new Date();
            }

            updateData.status = status;

            // SYNC VEHICLE STATUS
            let targetVehicleId: number | null = body.vehicleId ? parseInt(body.vehicleId) : null;
            if (!targetVehicleId) {
                const currentReq = await prisma.transportRequest.findUnique({ where: { id } });
                targetVehicleId = currentReq?.vehicleId || null;
            }

            if (targetVehicleId) {
                if (['APPROVED', 'IN_PROGRESS'].includes(status)) {
                    await prisma.vehicle.update({
                        where: { id: targetVehicleId },
                        data: { status: 'IN_USE' }
                    });
                } else if (['COMPLETED', 'CANCELLED', 'REJECTED'].includes(status)) {
                    await prisma.vehicle.update({
                        where: { id: targetVehicleId },
                        data: { status: 'AVAILABLE' }
                    });
                }
            }
        }

        const updatedRequest = await prisma.transportRequest.update({
            where: { id },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                vehicle: { select: { id: true, vehicleType: true, licensePlate: true } }
            }
        });

        // === WORKFLOW TRACKING ===
        // Nếu REJECTED, tạo TicketFeedback để người yêu cầu biết lý do
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'DRIVER',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Ghi nhận timeline khi thay đổi trạng thái quan trọng
        if (status && !['PENDING'].includes(status)) {
            const statusLabels: Record<string, string> = {
                'ASSIGNED': 'Đã phân công',
                'APPROVED': 'Đã duyệt',
                'IN_PROGRESS': 'Đang thực hiện',
                'COMPLETED': 'Hoàn thành',
                'CANCELLED': 'Đã hủy',
                'REJECTED': 'Từ chối'
            };

            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'DRIVER',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái: ${statusLabels[status] || status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updatedRequest);
    } catch (error) {
        console.error("Update Transport Request Error:", error);
        return NextResponse.json({ error: 'Failed to update request' }, { status: 500 });
    }
}

// DELETE: Xóa yêu cầu (Only admin)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Only ADMIN can hard delete
        if (user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Permission denied: Only Admin can delete history" }, { status: 403 });
        }

        // Also delete related feedback
        await prisma.ticketFeedback.deleteMany({
            where: { ticketType: 'DRIVER', ticketId: parseInt(params.id) }
        });

        await prisma.transportRequest.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted' });
    } catch (error) {
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

import { NextResponse } from 'next/server';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const data = await prisma.patientTransport.findMany({
            orderBy: { requestedAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(data);
    } catch (error) {
        console.error("Fetch Transport Error:", error);
        return NextResponse.json({ error: 'Error fetching data' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();

        // Basic validation
        if (!body.patientName || !body.fromLocation || !body.toLocation) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newData = await prisma.patientTransport.create({
            data: {
                patientName: body.patientName,
                fromLocation: body.fromLocation,
                toLocation: body.toLocation,
                transportMode: body.transportMode || 'WHEELCHAIR',
                priority: body.priority || 'NORMAL',
                requestedBy: body.requestedBy || user.fullName, // Default to current user if not specified
                notes: body.notes,
                status: 'PENDING',
            },
        });


        return NextResponse.json(newData, { status: 201 });
    } catch (error) {
        console.error("Create Transport Error:", error);
        return NextResponse.json({ error: 'Error creating request' }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const user = await getCurrentUser();
        // Permission check: Supervisor/Leader check could be added here

        const body = await request.json();
        const { id, status, assignedToId } = body;

        if (!id) {
            return NextResponse.json({ error: "Missing ID" }, { status: 400 });
        }

        const updateData: any = {};
        if (status) updateData.status = status;
        if (assignedToId) updateData.assignedToId = parseInt(assignedToId);

        const updated = await prisma.patientTransport.update({
            where: { id: parseInt(id) },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Update Transport Error:", error);
        return NextResponse.json({ error: 'Error updating request' }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const user = await getCurrentUser();
        // Permission check: Should be Admin or Manager

        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');

        if (!id) {
            return NextResponse.json({ error: "Missing ID" }, { status: 400 });
        }

        await prisma.patientTransport.delete({
            where: { id: parseInt(id) }
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Delete Transport Error:", error);
        return NextResponse.json({ error: 'Error deleting request' }, { status: 500 });
    }
}

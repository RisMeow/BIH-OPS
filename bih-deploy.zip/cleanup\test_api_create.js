
async function testCreate() {
    const payload = {
        patientName: "TEST_API_PATIENT",
        fromLocation: "TEST_FROM_API",
        toLocation: "TEST_TO_API",
        transportMode: "WHEELCHAIR",
        priority: "NORMAL",
        notes: "Created by JS Script",
        requestedBy: "SCRIPT_USER"
    };

    try {
        // Native fetch in Node 18+
        const response = await fetch('http://localhost:3001/api/nursing/transport', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const text = await response.text();
        console.log("Status:", response.status);
        console.log("Response:", text);
    } catch (e) {
        console.error("Fetch Error:", e);
    }
}

testCreate();

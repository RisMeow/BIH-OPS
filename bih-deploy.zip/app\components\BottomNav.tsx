"use client";

import { useSession } from "next-auth/react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
    Wrench, Stethoscope, Car, Shield, Package, Leaf,
    User, Home, Settings
} from "lucide-react";
import { clsx } from "clsx";
import { useLanguage } from "@/app/context/LanguageContext";

export default function BottomNav() {
    const { data: session } = useSession();
    const pathname = usePathname();
    const { t } = useLanguage();

    if (!session) return null;

    const userRole = session.user?.role as string || "ADMIN";

    // Core icons map
    const roleIcons: Record<string, React.ElementType> = {
        TECHNICAL: Wrench,
        NURSING: Stethoscope,
        DRIVER: Car,
        SECURITY: Shield,
        SUPPLY: Package,
        ENVIRONMENT: Leaf,
        ADMIN: Settings,
    };

    const DeptIcon = roleIcons[userRole] || roleIcons.ADMIN;

    // Define items
    const navItems = [
        {
            href: "/dashboard/my-requests",
            icon: Home,
            label: "Trang chủ"
        },
        {
            href: userRole === 'ADMIN' ? '/dashboard/admin' : `/dashboard/${userRole.toLowerCase()}`,
            icon: DeptIcon,
            label: "Tổ của tôi", // Or "Quản trị" for admin
            highlight: true
        },
        {
            href: "/dashboard/profile",
            icon: User,
            label: "Cá nhân"
        }
    ];

    return (
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-2 pb-safe z-50 flex justify-between items-center shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
            {navItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
                return (
                    <Link
                        key={item.href}
                        href={item.href}
                        className={clsx(
                            "flex flex-col items-center gap-1 transition-colors relative min-w-[64px]",
                            isActive ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                        )}
                    >
                        {item.highlight ? (
                            <div className={clsx(
                                "absolute -top-8 p-3 rounded-full shadow-lg transition-transform",
                                isActive ? "bg-blue-600 text-white scale-110" : "bg-white text-blue-600 border border-slate-100"
                            )}>
                                <item.icon size={24} />
                            </div>
                        ) : (
                            <item.icon size={24} />
                        )}
                        <span className={clsx(
                            "text-[10px] font-medium",
                            item.highlight && "mt-6"
                        )}>
                            {item.label}
                        </span>
                    </Link>
                );
            })}
        </div>
    );
}

"use client";

import { useState, useEffect, useCallback } from "react";
import { useSession } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
    ClipboardList, Wrench, HeartHandshake, Truck, ShieldAlert, Package, Leaf,
    Clock, CheckCircle2, AlertCircle, XCircle, Loader2, ChevronRight,
    Filter, Search, RefreshCw, MessageSquare, Eye, Calendar, MapPin,
    ArrowRight, TrendingUp, X, Send, User, ChevronDown
} from "lucide-react";
import { clsx } from "clsx";

interface TicketRequest {
    id: number;
    type: string;
    typeName: string;
    title: string;
    description: string;
    location: string;
    priority: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    meta?: Record<string, any>;
}

interface Feedback {
    id: number;
    ticketType: string;
    ticketId: number;
    authorId: number;
    authorName: string;
    authorRole: string;
    content: string;
    type: string;
    statusSnapshot: string | null;
    createdAt: string;
}

const typeConfig: Record<string, { icon: any; color: string; bgColor: string }> = {
    TECHNICAL: { icon: Wrench, color: "text-blue-600", bgColor: "bg-blue-100" },
    NURSING: { icon: HeartHandshake, color: "text-pink-600", bgColor: "bg-pink-100" },
    NURSING_TRANSPORT: { icon: HeartHandshake, color: "text-pink-600", bgColor: "bg-pink-100" },
    DRIVER: { icon: Truck, color: "text-amber-600", bgColor: "bg-amber-100" },
    SECURITY: { icon: ShieldAlert, color: "text-red-600", bgColor: "bg-red-100" },
    SUPPLY: { icon: Package, color: "text-emerald-600", bgColor: "bg-emerald-100" },
    ENVIRONMENT: { icon: Leaf, color: "text-teal-600", bgColor: "bg-teal-100" },
};

const statusConfig: Record<string, { label: string; icon: any; color: string; bgColor: string }> = {
    PENDING: { label: "Chờ xử lý", icon: Clock, color: "text-amber-600", bgColor: "bg-amber-50 border-amber-200" },
    APPROVED: { label: "Đã duyệt", icon: CheckCircle2, color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" },
    ASSIGNED: { label: "Đã phân công", icon: User, color: "text-indigo-600", bgColor: "bg-indigo-50 border-indigo-200" },
    IN_PROGRESS: { label: "Đang xử lý", icon: TrendingUp, color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" },
    COMPLETED: { label: "Hoàn thành", icon: CheckCircle2, color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" },
    REJECTED: { label: "Từ chối", icon: XCircle, color: "text-red-600", bgColor: "bg-red-50 border-red-200" },
    CANCELLED: { label: "Đã hủy", icon: XCircle, color: "text-slate-600", bgColor: "bg-slate-50 border-slate-200" },
    OPEN: { label: "Mở", icon: AlertCircle, color: "text-amber-600", bgColor: "bg-amber-50 border-amber-200" },
    RESOLVED: { label: "Đã giải quyết", icon: CheckCircle2, color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" },
    NORMAL: { label: "Bình thường", icon: Clock, color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" },
    URGENT: { label: "Khẩn cấp", icon: AlertCircle, color: "text-red-600", bgColor: "bg-red-50 border-red-200" },
};

const priorityConfig: Record<string, { label: string; color: string }> = {
    LOW: { label: "Thấp", color: "bg-slate-100 text-slate-600" },
    MEDIUM: { label: "Trung bình", color: "bg-blue-100 text-blue-600" },
    NORMAL: { label: "Bình thường", color: "bg-blue-100 text-blue-600" },
    HIGH: { label: "Cao", color: "bg-amber-100 text-amber-600" },
    URGENT: { label: "Khẩn cấp", color: "bg-red-100 text-red-600" },
    CRITICAL: { label: "Nguy hiểm", color: "bg-red-100 text-red-700" },
};

export default function MyRequestsPage() {
    const { data: session } = useSession();
    const [requests, setRequests] = useState<TicketRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [filterType, setFilterType] = useState("ALL");
    const [filterStatus, setFilterStatus] = useState("ALL");

    // Detail modal
    const [selectedRequest, setSelectedRequest] = useState<TicketRequest | null>(null);
    const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
    const [loadingFeedback, setLoadingFeedback] = useState(false);

    const fetchRequests = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch("/api/my-requests");
            if (res.ok) {
                const data = await res.json();
                setRequests(data.requests || []);
            }
        } catch (error) {
            console.error("Error fetching requests:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchRequests();
    }, [fetchRequests]);

    const fetchFeedbacks = async (type: string, id: number) => {
        setLoadingFeedback(true);
        try {
            const res = await fetch(`/api/my-requests/${type.toLowerCase()}/${id}/feedback`);
            if (res.ok) {
                const data = await res.json();
                setFeedbacks(data.feedback || []);
            }
        } catch (error) {
            console.error("Error fetching feedback:", error);
        } finally {
            setLoadingFeedback(false);
        }
    };

    const handleViewDetail = (request: TicketRequest) => {
        setSelectedRequest(request);
        fetchFeedbacks(request.type, request.id);
    };

    // Filter logic
    const filteredRequests = requests.filter(r => {
        const matchSearch =
            r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.location.toLowerCase().includes(searchTerm.toLowerCase());
        const matchType = filterType === "ALL" || r.type === filterType;
        const matchStatus = filterStatus === "ALL" || r.status === filterStatus;
        return matchSearch && matchType && matchStatus;
    });

    // Stats
    const stats = {
        total: requests.length,
        pending: requests.filter(r => ["PENDING", "OPEN"].includes(r.status)).length,
        inProgress: requests.filter(r => ["ASSIGNED", "IN_PROGRESS", "APPROVED"].includes(r.status)).length,
        completed: requests.filter(r => ["COMPLETED", "RESOLVED"].includes(r.status)).length,
        rejected: requests.filter(r => ["REJECTED", "CANCELLED"].includes(r.status)).length,
    };

    const formatDate = (dateStr: string) => {
        const date = new Date(dateStr);
        return date.toLocaleDateString("vi-VN", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    };

    const getRelativeTime = (dateStr: string) => {
        const date = new Date(dateStr);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return "Vừa xong";
        if (diffMins < 60) return `${diffMins} phút trước`;
        if (diffHours < 24) return `${diffHours} giờ trước`;
        if (diffDays < 7) return `${diffDays} ngày trước`;
        return formatDate(dateStr);
    };

    return (
        <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/30">
                            <ClipboardList className="text-white" size={24} />
                        </div>
                        <div>
                            <h1 className="text-2xl font-black text-slate-800">Yêu cầu của tôi</h1>
                            <p className="text-slate-500 text-sm">Theo dõi trạng thái các yêu cầu đã gửi</p>
                        </div>
                    </div>
                </div>
                <button
                    onClick={fetchRequests}
                    disabled={loading}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors font-medium"
                >
                    <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
                    Làm mới
                </button>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {[
                    { label: "Tổng cộng", value: stats.total, color: "from-slate-500 to-slate-600", icon: ClipboardList },
                    { label: "Chờ xử lý", value: stats.pending, color: "from-amber-500 to-orange-500", icon: Clock },
                    { label: "Đang xử lý", value: stats.inProgress, color: "from-blue-500 to-indigo-500", icon: TrendingUp },
                    { label: "Hoàn thành", value: stats.completed, color: "from-emerald-500 to-green-500", icon: CheckCircle2 },
                    { label: "Từ chối", value: stats.rejected, color: "from-red-500 to-rose-500", icon: XCircle },
                ].map((stat, i) => (
                    <motion.div
                        key={stat.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm"
                    >
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                                <stat.icon className="text-white" size={18} />
                            </div>
                            <div>
                                <p className="text-2xl font-black text-slate-800">{stat.value}</p>
                                <p className="text-xs text-slate-500">{stat.label}</p>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>

            {/* Filters */}
            <div className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                <div className="flex flex-col md:flex-row gap-3">
                    {/* Search */}
                    <div className="flex-1 relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input
                            type="text"
                            placeholder="Tìm kiếm yêu cầu..."
                            className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>

                    {/* Type Filter */}
                    <div className="relative">
                        <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        <select
                            className="pl-9 pr-8 py-2.5 border border-slate-200 rounded-xl outline-none focus:border-violet-500 bg-white appearance-none cursor-pointer font-medium text-slate-700"
                            value={filterType}
                            onChange={e => setFilterType(e.target.value)}
                        >
                            <option value="ALL">Tất cả loại</option>
                            <option value="TECHNICAL">Kỹ thuật</option>
                            <option value="NURSING">Hộ lý</option>
                            <option value="DRIVER">Đội xe</option>
                            <option value="SECURITY">An ninh</option>
                            <option value="SUPPLY">Vật tư</option>
                            <option value="ENVIRONMENT">Môi trường</option>
                            <option value="NURSING_TRANSPORT">Vận chuyển BN</option>
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                    </div>

                    {/* Status Filter */}
                    <div className="relative">
                        <select
                            className="px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:border-violet-500 bg-white appearance-none cursor-pointer font-medium text-slate-700 pr-8"
                            value={filterStatus}
                            onChange={e => setFilterStatus(e.target.value)}
                        >
                            <option value="ALL">Tất cả trạng thái</option>
                            <option value="PENDING">Chờ xử lý</option>
                            <option value="ASSIGNED">Đã phân công</option>
                            <option value="IN_PROGRESS">Đang xử lý</option>
                            <option value="COMPLETED">Hoàn thành</option>
                            <option value="REJECTED">Từ chối</option>
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                    </div>
                </div>
            </div>

            {/* Requests List */}
            <div className="space-y-3">
                {loading ? (
                    <div className="bg-white rounded-xl p-12 text-center border border-slate-100">
                        <Loader2 className="animate-spin mx-auto text-violet-500 mb-3" size={32} />
                        <p className="text-slate-500">Đang tải dữ liệu...</p>
                    </div>
                ) : filteredRequests.length === 0 ? (
                    <div className="bg-white rounded-xl p-12 text-center border border-slate-100">
                        <ClipboardList className="mx-auto text-slate-300 mb-3" size={48} />
                        <p className="text-slate-500 font-medium">Không tìm thấy yêu cầu nào</p>
                        <p className="text-slate-400 text-sm mt-1">Thử thay đổi bộ lọc hoặc tìm kiếm khác</p>
                    </div>
                ) : (
                    filteredRequests.map((request, index) => {
                        const TypeIcon = typeConfig[request.type]?.icon || ClipboardList;
                        const status = statusConfig[request.status] || statusConfig.PENDING;
                        const priority = priorityConfig[request.priority] || priorityConfig.MEDIUM;

                        return (
                            <motion.div
                                key={`${request.type}-${request.id}`}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.03 }}
                                className="bg-white rounded-xl border border-slate-100 hover:border-violet-200 hover:shadow-lg transition-all group cursor-pointer"
                                onClick={() => handleViewDetail(request)}
                            >
                                <div className="p-4">
                                    <div className="flex items-start gap-4">
                                        {/* Type Icon */}
                                        <div className={clsx(
                                            "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                                            typeConfig[request.type]?.bgColor || "bg-slate-100"
                                        )}>
                                            <TypeIcon className={typeConfig[request.type]?.color || "text-slate-600"} size={22} />
                                        </div>

                                        {/* Content */}
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-start justify-between gap-3">
                                                <div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <span className={clsx(
                                                            "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase",
                                                            typeConfig[request.type]?.bgColor,
                                                            typeConfig[request.type]?.color
                                                        )}>
                                                            {request.typeName}
                                                        </span>
                                                        <span className={clsx(
                                                            "text-[10px] font-bold px-2 py-0.5 rounded-full",
                                                            priority.color
                                                        )}>
                                                            {priority.label}
                                                        </span>
                                                    </div>
                                                    <h3 className="font-bold text-slate-800 group-hover:text-violet-600 transition-colors line-clamp-1">
                                                        {request.title}
                                                    </h3>
                                                    {request.description && (
                                                        <p className="text-sm text-slate-500 line-clamp-1 mt-0.5">
                                                            {request.description}
                                                        </p>
                                                    )}
                                                </div>

                                                {/* Status Badge */}
                                                <div className={clsx(
                                                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm font-bold shrink-0",
                                                    status.bgColor
                                                )}>
                                                    <status.icon size={14} className={status.color} />
                                                    <span className={status.color}>{status.label}</span>
                                                </div>
                                            </div>

                                            {/* Meta info */}
                                            <div className="flex items-center gap-4 mt-3 text-xs text-slate-400">
                                                {request.location && (
                                                    <div className="flex items-center gap-1">
                                                        <MapPin size={12} />
                                                        <span className="truncate max-w-[150px]">{request.location}</span>
                                                    </div>
                                                )}
                                                <div className="flex items-center gap-1">
                                                    <Calendar size={12} />
                                                    <span>{getRelativeTime(request.createdAt)}</span>
                                                </div>
                                                <div className="flex items-center gap-1 ml-auto text-violet-500 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <span>Xem chi tiết</span>
                                                    <ChevronRight size={14} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Warning stripe for rejected */}
                                {request.status === "REJECTED" && (
                                    <div className="bg-red-50 border-t border-red-100 px-4 py-2 flex items-center gap-2 text-red-600 text-sm">
                                        <AlertCircle size={14} />
                                        <span className="font-medium">Yêu cầu này đã bị từ chối - Xem phản hồi</span>
                                    </div>
                                )}
                            </motion.div>
                        );
                    })
                )}
            </div>

            {/* Detail Modal */}
            <AnimatePresence>
                {selectedRequest && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95, y: 20 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, y: 20 }}
                            className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
                        >
                            {/* Modal Header */}
                            <div className={clsx(
                                "p-5 text-white",
                                `bg-gradient-to-r`,
                                selectedRequest.type === "TECHNICAL" && "from-blue-500 to-blue-600",
                                selectedRequest.type === "DRIVER" && "from-amber-500 to-amber-600",
                                selectedRequest.type === "SECURITY" && "from-red-500 to-red-600",
                                selectedRequest.type === "SUPPLY" && "from-emerald-500 to-emerald-600",
                                selectedRequest.type === "ENVIRONMENT" && "from-teal-500 to-teal-600",
                                (selectedRequest.type === "NURSING" || selectedRequest.type === "NURSING_TRANSPORT") && "from-pink-500 to-pink-600"
                            )}>
                                <div className="flex justify-between items-start">
                                    <div className="flex items-center gap-3">
                                        {(() => {
                                            const TypeIcon = typeConfig[selectedRequest.type]?.icon || ClipboardList;
                                            return <TypeIcon size={28} />;
                                        })()}
                                        <div>
                                            <p className="text-sm opacity-80">{selectedRequest.typeName} • #{selectedRequest.id}</p>
                                            <h3 className="font-bold text-lg">{selectedRequest.title}</h3>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => setSelectedRequest(null)}
                                        className="p-1.5 hover:bg-white/20 rounded-lg transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>
                            </div>

                            {/* Modal Body */}
                            <div className="flex-1 overflow-y-auto p-5 space-y-5">
                                {/* Status & Priority */}
                                <div className="flex flex-wrap gap-3">
                                    <div className={clsx(
                                        "flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-bold",
                                        statusConfig[selectedRequest.status]?.bgColor || "bg-slate-50 border-slate-200"
                                    )}>
                                        {(() => {
                                            const StatusIcon = statusConfig[selectedRequest.status]?.icon || Clock;
                                            return <StatusIcon size={16} className={statusConfig[selectedRequest.status]?.color} />;
                                        })()}
                                        <span className={statusConfig[selectedRequest.status]?.color}>
                                            {statusConfig[selectedRequest.status]?.label || selectedRequest.status}
                                        </span>
                                    </div>
                                    <div className={clsx(
                                        "px-4 py-2 rounded-xl text-sm font-bold",
                                        priorityConfig[selectedRequest.priority]?.color || "bg-slate-100 text-slate-600"
                                    )}>
                                        Ưu tiên: {priorityConfig[selectedRequest.priority]?.label || selectedRequest.priority}
                                    </div>
                                </div>

                                {/* Details */}
                                <div className="bg-slate-50 rounded-xl p-4 space-y-3">
                                    {selectedRequest.description && (
                                        <div>
                                            <p className="text-xs font-bold text-slate-500 uppercase mb-1">Mô tả</p>
                                            <p className="text-slate-700">{selectedRequest.description}</p>
                                        </div>
                                    )}
                                    {selectedRequest.location && (
                                        <div className="flex items-center gap-2 text-slate-600">
                                            <MapPin size={16} className="text-slate-400" />
                                            <span>{selectedRequest.location}</span>
                                        </div>
                                    )}
                                    <div className="flex items-center gap-2 text-slate-600">
                                        <Calendar size={16} className="text-slate-400" />
                                        <span>Tạo lúc: {formatDate(selectedRequest.createdAt)}</span>
                                    </div>
                                </div>

                                {/* Timeline / Feedback Section */}
                                <div>
                                    <h4 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                                        <MessageSquare size={18} />
                                        Phản hồi & Tiến độ
                                    </h4>

                                    {loadingFeedback ? (
                                        <div className="text-center py-6">
                                            <Loader2 className="animate-spin mx-auto text-violet-500" size={24} />
                                        </div>
                                    ) : feedbacks.length === 0 ? (
                                        <div className="bg-slate-50 rounded-xl p-6 text-center">
                                            <MessageSquare className="mx-auto text-slate-300 mb-2" size={32} />
                                            <p className="text-slate-500 text-sm">Chưa có phản hồi nào</p>
                                            <p className="text-slate-400 text-xs mt-1">Phản hồi từ người xử lý sẽ hiển thị ở đây</p>
                                        </div>
                                    ) : (
                                        <div className="space-y-3">
                                            {feedbacks.map((fb) => (
                                                <div
                                                    key={fb.id}
                                                    className={clsx(
                                                        "rounded-xl p-4 border",
                                                        fb.type === "REJECT_REASON"
                                                            ? "bg-red-50 border-red-200"
                                                            : fb.type === "STATUS_CHANGE"
                                                                ? "bg-blue-50 border-blue-200"
                                                                : "bg-white border-slate-200"
                                                    )}
                                                >
                                                    <div className="flex items-start gap-3">
                                                        <div className={clsx(
                                                            "w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0",
                                                            fb.authorRole === "ADMIN" && "bg-red-500",
                                                            fb.authorRole === "MANAGER" && "bg-purple-500",
                                                            fb.authorRole === "LEADER" && "bg-blue-500",
                                                            fb.authorRole === "STAFF" && "bg-slate-500"
                                                        )}>
                                                            {fb.authorName.charAt(0).toUpperCase()}
                                                        </div>
                                                        <div className="flex-1">
                                                            <div className="flex items-center gap-2 mb-1">
                                                                <span className="font-bold text-slate-800">{fb.authorName}</span>
                                                                <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full uppercase font-bold">
                                                                    {fb.authorRole}
                                                                </span>
                                                            </div>
                                                            <p className={clsx(
                                                                "text-sm",
                                                                fb.type === "REJECT_REASON" ? "text-red-700" : "text-slate-600"
                                                            )}>
                                                                {fb.content}
                                                            </p>
                                                            <p className="text-xs text-slate-400 mt-2">
                                                                {getRelativeTime(fb.createdAt)}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Modal Footer */}
                            <div className="border-t border-slate-100 p-4">
                                <button
                                    onClick={() => setSelectedRequest(null)}
                                    className="w-full py-3 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-colors"
                                >
                                    Đóng
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

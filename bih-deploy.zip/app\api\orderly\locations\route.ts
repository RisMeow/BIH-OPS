
import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Helper để xây dựng cây thư mục (Recursive)
function buildLocationTree(locations: any[], parentId: string | null = null): any[] {
    return locations
        .filter(loc => loc.parentId === parentId)
        .map(loc => ({
            ...loc,
            children: buildLocationTree(locations, loc.id)
        }));
}

export async function GET() {
    try {
        const locations = await prisma.location.findMany({
            orderBy: { name: 'asc' }
        });

        // Nếu chưa có dữ liệu, trả về mảng rỗng hoặc seed data mặc định từ code (tùy chọn)
        // Ở đây ta trả về cây
        const tree = buildLocationTree(locations);

        return NextResponse.json(tree);
    } catch (error) {
        console.error("Error fetching locations:", error);
        return NextResponse.json({ error: "Failed to fetch locations" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { name, code, type, parentId, description } = body;

        // Validation cơ bản
        if (!name || !type) {
            return NextResponse.json({ error: "Name and Type are required" }, { status: 400 });
        }

        const newLocation = await prisma.location.create({
            data: {
                name,
                code,
                type, // 'BLOCK', 'FLOOR', 'ROOM', ...
                parentId: parentId || null,
                description
            }
        });

        return NextResponse.json(newLocation, { status: 201 });
    } catch (error) {
        console.error("Error creating location:", error);
        return NextResponse.json({ error: "Failed to create location" }, { status: 500 });
    }
}

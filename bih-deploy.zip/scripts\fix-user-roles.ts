// Script to fix user roles - Move female Environment staff to Nursing
// Run with: npx ts-node scripts/fix-user-roles.ts

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';

const prisma = new PrismaClient();

async function fixUserRoles() {
    // ESM compatible path resolution
    const scriptDir = new URL('.', import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1');
    const csvPath = scriptDir.replace(/scripts\/$/, 'cleanup/ttlylich.csv');
    console.log('Reading CSV from:', csvPath);

    const content = fs.readFileSync(csvPath, 'utf-8');
    const lines = content.split('\n').filter(line => line.trim());

    // Build a map of female staff members from Environment department
    const femaleEnvStaff: Map<string, { fullName: string; genderCode: string; dept: string }> = new Map();

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        if (values.length < 10) continue;

        const fullName = values[1].trim();
        const genderCode = values[4]?.trim(); // PHAI column (1 = Female)
        const genderText = values[5]?.trim();  // TPHAI column (Nữ/Nam)
        const department = values[8]?.trim();

        if (!fullName) continue;

        // Check if this is environment department
        const deptLower = department.toLowerCase();
        const isEnvironment = deptLower.includes('môi') || deptLower.includes('m?i') || deptLower.includes('moi');

        // Check if female - using genderCode column (1 = Female) or genderText contains 'N' (Nữ)
        const isFemale = genderCode === '1' ||
            genderText?.toLowerCase().includes('n') ||
            genderText?.includes('ữ');

        if (isEnvironment && isFemale) {
            femaleEnvStaff.set(fullName, {
                fullName,
                genderCode: genderCode || genderText || '',
                dept: department
            });
        }
    }

    console.log(`\nFound ${femaleEnvStaff.size} female staff in Environment department to update to NURSING\n`);

    // Sample
    console.log('Sample names to update:');
    Array.from(femaleEnvStaff.values()).slice(0, 10).forEach(s => {
        console.log(`  - ${s.fullName} (gender: ${s.genderCode})`);
    });

    // Find matching users in database and update
    console.log('\n=== UPDATING USERS ===');
    let updated = 0;
    let notFound = 0;

    for (const entry of Array.from(femaleEnvStaff.entries())) {
        const fullName = entry[0];
        const info = entry[1];
        try {
            // Find user by fullName and current role ENVIRONMENT
            const users = await prisma.user.findMany({
                where: {
                    fullName: fullName,
                    role: 'ENVIRONMENT'
                }
            });

            if (users.length === 0) {
                console.log(`NOT FOUND: ${fullName}`);
                notFound++;
                continue;
            }

            for (const user of users) {
                await prisma.user.update({
                    where: { id: user.id },
                    data: { role: 'NURSING' }
                });
                console.log(`UPDATED: ${user.username} (${fullName}) -> NURSING`);
                updated++;
            }
        } catch (error: any) {
            console.error(`ERROR: ${fullName} - ${error.message}`);
        }
    }

    console.log(`\n=== DONE ===`);
    console.log(`Updated: ${updated}`);
    console.log(`Not found: ${notFound}`);

    // Show final counts
    const counts = await prisma.user.groupBy({
        by: ['role'],
        _count: { id: true }
    });

    console.log('\nFinal user counts by role:');
    counts.forEach(c => {
        console.log(`  ${c.role}: ${c._count.id}`);
    });

    await prisma.$disconnect();
}

fixUserRoles().catch(console.error);

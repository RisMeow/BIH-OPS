import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

function canManageEnv(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'ENVIRONMENT' && ['MANAGER', 'LEADER'].includes(user.position)) return true;
    return false;
}

export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const task = await prisma.landscapeTask.findUnique({
            where: { id: parseInt(params.id) },
            include: { assignedTo: { select: { fullName: true } } }
        });

        if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
        return NextResponse.json(task);
    } catch (error) {
        return NextResponse.json({ error: "Server Error" }, { status: 500 });
    }
}

export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (user.role !== 'ENVIRONMENT' && user.role !== 'ADMIN') return NextResponse.json({ error: "Forbidden" }, { status: 403 });

        const body = await request.json();
        const { taskType, area, scheduledDate, status, notes, assignedToId } = body;

        const updated = await prisma.landscapeTask.update({
            where: { id: parseInt(params.id) },
            data: {
                taskType,
                area,
                scheduledDate: scheduledDate ? new Date(scheduledDate) : undefined,
                status,
                notes,
                assignedToId: assignedToId ? parseInt(assignedToId) : undefined
            }
        });

        return NextResponse.json(updated);
    } catch (error) {
        return NextResponse.json({ error: "Update failed" }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!canManageEnv(user)) return NextResponse.json({ error: "Forbidden: Manager only" }, { status: 403 });

        await prisma.landscapeTask.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Delete failed" }, { status: 500 });
    }
}

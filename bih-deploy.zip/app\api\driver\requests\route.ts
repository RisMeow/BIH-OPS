import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to get current user from session
// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string };
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const requests = await prisma.transportRequest.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(requests);
    } catch (error) {
        console.error("Fetch Transport Requests Error:", error);
        return NextResponse.json({ error: "Failed to fetch requests" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Anyone can request transport
        const body = await request.json();
        const { passengerName, department, destination, pickupTime, passengerCount, tripType } = body;

        if (!passengerName || !destination || !pickupTime) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newRequest = await prisma.transportRequest.create({
            data: {
                passengerName,
                department: department || 'Unknown',
                destination,
                pickupLocation: body.pickupLocation || null,
                pickupTime: new Date(pickupTime),
                passengerCount: parseInt(passengerCount) || 1,
                tripType: tripType || 'ONE_WAY',
                purpose: body.purpose || null,
                note: body.note || null,
                status: 'PENDING',
                requestedById: user.id,
                requestedBy: user.fullName
            }
        });

        return NextResponse.json(newRequest, { status: 201 });
    } catch (error) {
        console.error("Create Transport Request Error:", error);
        return NextResponse.json({ error: "Failed to create request" }, { status: 500 });
    }
}

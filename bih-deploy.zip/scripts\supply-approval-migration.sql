-- Add approval columns to ProcurementPlan
ALTER TABLE "ProcurementPlan" ADD COLUMN IF NOT EXISTS "approvedById" INTEGER;
ALTER TABLE "ProcurementPlan" ADD COLUMN IF NOT EXISTS "approvedAt" TIMESTAMP;

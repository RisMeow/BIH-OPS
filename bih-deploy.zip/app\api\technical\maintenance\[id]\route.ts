import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function checkTechnicalAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    const user = session.user as { id: number; role: string; position: string };
    if (user.role !== 'ADMIN' && user.role !== 'TECHNICAL') return null;
    return user;
}

function calculateNextDueDate(frequency: string, lastDate: Date = new Date()): Date {
    const next = new Date(lastDate);
    switch (frequency) {
        case 'DAILY': next.setDate(next.getDate() + 1); break;
        case 'WEEKLY': next.setDate(next.getDate() + 7); break;
        case 'MONTHLY': next.setMonth(next.getMonth() + 1); break;
        case 'QUARTERLY': next.setMonth(next.getMonth() + 3); break;
        case 'YEARLY': next.setFullYear(next.getFullYear() + 1); break;
        default: next.setMonth(next.getMonth() + 1);
    }
    return next;
}

// GET: Get schedule by ID
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const schedule = await prisma.maintenanceSchedule.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                asset: true
            }
        });

        if (!schedule) {
            return NextResponse.json({ error: "Schedule not found" }, { status: 404 });
        }

        return NextResponse.json(schedule);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch schedule' }, { status: 500 });
    }
}

// PATCH: Complete maintenance (mark as done) or update schedule
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { action, notes, cost } = body;

        const schedule = await prisma.maintenanceSchedule.findUnique({
            where: { id },
            include: { asset: true }
        });

        if (!schedule) {
            return NextResponse.json({ error: "Schedule not found" }, { status: 404 });
        }

        // If action is "complete", mark as done and create history entry
        if (action === 'complete') {
            const now = new Date();
            const nextDue = calculateNextDueDate(schedule.frequency, now);

            // Update schedule
            await prisma.maintenanceSchedule.update({
                where: { id },
                data: {
                    lastExecutedAt: now,
                    nextDueAt: nextDue
                }
            });

            // Create history entry
            await prisma.maintenanceHistory.create({
                data: {
                    assetId: schedule.assetId,
                    type: 'PREVENTIVE',
                    description: `Hoàn thành: ${schedule.title}`,
                    performedById: Number(user.id),
                    cost: cost || null,
                    notes: notes || null
                }
            });

            return NextResponse.json({
                message: 'Maintenance completed',
                nextDueAt: nextDue
            });
        }

        // Otherwise, update schedule properties
        const updated = await prisma.maintenanceSchedule.update({
            where: { id },
            data: body
        });

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Update schedule error:", error);
        return NextResponse.json({ error: 'Failed to update schedule' }, { status: 500 });
    }
}

// DELETE: Delete schedule
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== 'ADMIN' && !['MANAGER', 'LEADER'].includes(user.position)) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        await prisma.maintenanceSchedule.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted' });
    } catch (error) {
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

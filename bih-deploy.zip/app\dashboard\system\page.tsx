"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
    UserPlus, UserCog, Shield, Trash2, Key, Loader2, Search,
    UserCheck, Mail, Phone, Edit, X, AlertTriangle, Users,
    Lock, RefreshCw, ChevronDown, Filter, BarChart3
} from "lucide-react";
import { clsx } from "clsx";
import Toast, { ToastType } from "@/components/Toast";

interface User {
    id: number;
    username: string;
    fullName: string;
    email?: string;
    phoneNumber?: string;
    department?: string;
    role: string;
    position: string;
    manager?: { id: number, fullName: string };
    managerId?: number | null;
    createdAt: string;
}

export default function SystemPage() {
    const { data: session, status } = useSession();
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [roleFilter, setRoleFilter] = useState<string>("ALL");

    // Toast State
    const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
        message: "",
        type: "success",
        isVisible: false
    });

    const showToast = (message: string, type: ToastType = "success") => {
        setToast({ message, type, isVisible: true });
    };

    const hideToast = () => {
        setToast(prev => ({ ...prev, isVisible: false }));
    };

    // Edit Mode State
    const [isEditing, setIsEditing] = useState(false);
    const [editId, setEditId] = useState<number | null>(null);

    // Reset Password Modal
    const [isResetModalOpen, setIsResetModalOpen] = useState(false);
    const [resetUserId, setResetUserId] = useState<number | null>(null);
    const [resetUsername, setResetUsername] = useState("");
    const [newPassword, setNewPassword] = useState("");

    // Form
    const [formData, setFormData] = useState({
        username: "",
        password: "",
        fullName: "",
        email: "",
        phoneNumber: "",
        department: "",
        role: "TECHNICAL",
        position: "STAFF",
        managerId: ""
    });

    useEffect(() => {
        if (status === 'authenticated') {
            fetchUsers();
        }
    }, [status]);

    const fetchUsers = async () => {
        try {
            const res = await fetch('/api/admin/users');
            if (!res.ok) {
                if (res.status === 403) {
                    setUsers([]);
                    return;
                }
                throw new Error("Failed to fetch");
            }

            const data = await res.json();
            if (Array.isArray(data)) {
                setUsers(data);
            } else {
                console.error("Data integrity error:", data);
                setUsers([]);
            }
        } catch (e) {
            console.error(e);
            setUsers([]);
        } finally {
            setLoading(false);
        }
    };

    const resetForm = () => {
        setFormData({
            username: "", password: "", fullName: "", email: "", phoneNumber: "",
            department: "", role: "TECHNICAL", position: "STAFF", managerId: ""
        });
        setIsEditing(false);
        setEditId(null);
    };

    const handleEdit = (user: User) => {
        setIsEditing(true);
        setEditId(user.id);
        setFormData({
            username: user.username,
            password: "",
            fullName: user.fullName,
            email: user.email || "",
            phoneNumber: user.phoneNumber || "",
            department: user.department || "",
            role: user.role,
            position: user.position,
            managerId: user.manager?.id ? user.manager.id.toString() : ""
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (id: number) => {
        if (!confirm("Bạn có chắc chắn muốn xóa tài khoản này? Hành động này không thể hoàn tác.")) return;
        try {
            const res = await fetch(`/api/admin/users/${id}`, { method: 'DELETE' });
            const data = await res.json();
            if (res.ok) {
                alert("Đã xóa thành công!");
                fetchUsers();
            } else {
                alert(data.error || "Xóa thất bại.");
            }
        } catch (e) { console.error(e); }
    };

    const openResetPasswordModal = (user: User) => {
        setResetUserId(user.id);
        setResetUsername(user.username);
        setNewPassword("");
        setIsResetModalOpen(true);
    };

    const handleResetPassword = async () => {
        if (!resetUserId || !newPassword) return;
        if (newPassword.length < 6) {
            showToast("Mật khẩu phải có ít nhất 6 ký tự", "warning");
            return;
        }

        try {
            const res = await fetch(`/api/admin/users/${resetUserId}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'reset_password', newPassword })
            });
            if (res.ok) {
                showToast("Đặt lại mật khẩu thành công!", "success");
                setIsResetModalOpen(false);
                setResetUserId(null);
                setNewPassword("");
            } else {
                const data = await res.json();
                showToast(data.error || "Có lỗi xảy ra", "error");
            }
        } catch (e) {
            console.error(e);
            showToast("Có lỗi kết nối", "error");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const url = isEditing ? `/api/admin/users/${editId}` : '/api/admin/users';
            const method = isEditing ? 'PUT' : 'POST';

            const res = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const data = await res.json();

            if (res.ok) {
                showToast(isEditing ? "Cập nhật user thành công!" : "Tạo user thành công!", "success");
                resetForm();
                fetchUsers();
            } else {
                showToast(data.error || "Có lỗi xảy ra", "error");
            }
        } catch (e) {
            console.error(e);
            showToast("Có lỗi kết nối", "error");
        } finally {
            setSubmitting(false);
        }
    };

    const roles = [
        { val: "ADMIN", label: "Quản trị viên", color: "bg-purple-100 text-purple-700 border-purple-200" },
        { val: "TECHNICAL", label: "Kỹ thuật", color: "bg-blue-100 text-blue-700 border-blue-200" },
        { val: "NURSING", label: "Hộ lý", color: "bg-pink-100 text-pink-700 border-pink-200" },
        { val: "DRIVER", label: "Đội xe", color: "bg-amber-100 text-amber-700 border-amber-200" },
        { val: "SECURITY", label: "An ninh", color: "bg-red-100 text-red-700 border-red-200" },
        { val: "SUPPLY", label: "Cung ứng", color: "bg-emerald-100 text-emerald-700 border-emerald-200" },
        { val: "ENVIRONMENT", label: "Môi trường", color: "bg-teal-100 text-teal-700 border-teal-200" },
        { val: "DEPARTMENT", label: "Khoa / Phòng", color: "bg-indigo-100 text-indigo-700 border-indigo-200" },
    ];

    const positions = [
        { val: "MANAGER", label: "Trưởng phòng / GĐ", color: "bg-purple-50 text-purple-600 border-purple-100" },
        { val: "LEADER", label: "Tổ trưởng", color: "bg-blue-50 text-blue-600 border-blue-100" },
        { val: "SUPERVISOR", label: "Giám sát", color: "bg-amber-50 text-amber-600 border-amber-100" },
        { val: "STAFF", label: "Nhân viên", color: "bg-emerald-50 text-emerald-600 border-emerald-100" },
    ];

    // Check if user is Admin
    if (status === 'loading') {
        return (
            <div className="h-full flex items-center justify-center">
                <Loader2 className="animate-spin text-slate-400" size={32} />
            </div>
        );
    }

    if (session?.user?.role !== 'ADMIN') {
        return (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mb-6">
                    <Lock className="text-red-500" size={40} />
                </div>
                <h1 className="text-2xl font-bold text-slate-800 mb-2">Truy cập bị từ chối</h1>
                <p className="text-slate-500 max-w-md">
                    Chỉ quản trị viên (Admin) mới có quyền truy cập trang quản lý hệ thống này.
                    Vui lòng liên hệ quản trị viên nếu bạn cần hỗ trợ.
                </p>
            </div>
        );
    }

    // Filter users
    const potentialManagers = Array.isArray(users) ? users.filter(u => u.id !== editId && (u.role === formData.role || u.role === 'ADMIN')) : [];

    const filteredUsers = users.filter(u => {
        const matchSearch = u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
            u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
            u.email?.toLowerCase().includes(searchQuery.toLowerCase());
        const matchRole = roleFilter === 'ALL' || u.role === roleFilter;
        return matchSearch && matchRole;
    });

    // Stats
    const stats = {
        total: users.length,
        admins: users.filter(u => u.role === 'ADMIN').length,
        managers: users.filter(u => u.position === 'MANAGER' || u.position === 'LEADER').length,
        staff: users.filter(u => u.position === 'STAFF').length,
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                        <Shield className="text-blue-600" size={28} />
                        Quản trị Hệ thống
                    </h1>
                    <p className="text-slate-500">Quản lý tài khoản và phân quyền người dùng</p>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={fetchUsers} className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors" title="Refresh">
                        <RefreshCw size={18} />
                    </button>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                            <Users className="text-blue-600" size={20} />
                        </div>
                        <div>
                            <p className="text-2xl font-black text-slate-800">{stats.total}</p>
                            <p className="text-xs text-slate-500">Tổng tài khoản</p>
                        </div>
                    </div>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                            <Shield className="text-purple-600" size={20} />
                        </div>
                        <div>
                            <p className="text-2xl font-black text-slate-800">{stats.admins}</p>
                            <p className="text-xs text-slate-500">Quản trị viên</p>
                        </div>
                    </div>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                            <UserCog className="text-amber-600" size={20} />
                        </div>
                        <div>
                            <p className="text-2xl font-black text-slate-800">{stats.managers}</p>
                            <p className="text-xs text-slate-500">Quản lý/Tổ trưởng</p>
                        </div>
                    </div>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                            <UserCheck className="text-emerald-600" size={20} />
                        </div>
                        <div>
                            <p className="text-2xl font-black text-slate-800">{stats.staff}</p>
                            <p className="text-xs text-slate-500">Nhân viên</p>
                        </div>
                    </div>
                </motion.div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* User List */}
                <div className="lg:col-span-2 space-y-4">
                    {/* Search and Filter */}
                    <div className="flex flex-col sm:flex-row gap-3">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                            <input
                                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                                placeholder="Tìm theo tên, username, email..."
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                            />
                        </div>
                        <select
                            className="px-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                            value={roleFilter}
                            onChange={e => setRoleFilter(e.target.value)}
                        >
                            <option value="ALL">Tất cả tổ</option>
                            {roles.map(r => (
                                <option key={r.val} value={r.val}>{r.label}</option>
                            ))}
                        </select>
                    </div>

                    {/* Users Table */}
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 uppercase text-xs font-bold tracking-wider">
                                <tr>
                                    <th className="p-4">Nhân sự</th>
                                    <th className="p-4 hidden md:table-cell">Liên hệ</th>
                                    <th className="p-4">Phân quyền</th>
                                    <th className="p-4 hidden sm:table-cell">Báo cáo cho</th>
                                    <th className="p-4 text-right">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                {filteredUsers.map(user => (
                                    <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                                        <td className="p-4">
                                            <div className="flex items-center gap-3">
                                                <div className={clsx(
                                                    "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm",
                                                    user.role === 'ADMIN' ? "bg-purple-100 text-purple-600" :
                                                        user.role === 'TECHNICAL' ? "bg-blue-100 text-blue-600" :
                                                            user.role === 'NURSING' ? "bg-pink-100 text-pink-600" :
                                                                user.role === 'DRIVER' ? "bg-amber-100 text-amber-600" :
                                                                    user.role === 'SECURITY' ? "bg-red-100 text-red-600" :
                                                                        user.role === 'SUPPLY' ? "bg-emerald-100 text-emerald-600" :
                                                                            "bg-teal-100 text-teal-600"
                                                )}>
                                                    {user.fullName.charAt(0)}
                                                </div>
                                                <div>
                                                    <div className="font-bold text-slate-800">{user.fullName}</div>
                                                    <div className="text-xs text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded w-fit mt-1">{user.username}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="p-4 hidden md:table-cell">
                                            <div className="space-y-1">
                                                {user.email && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Mail size={12} /> {user.email}</div>}
                                                {user.phoneNumber && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Phone size={12} /> {user.phoneNumber}</div>}
                                                {!user.email && !user.phoneNumber && <span className="text-slate-300 text-xs italic">Chưa cập nhật</span>}
                                            </div>
                                        </td>
                                        <td className="p-4">
                                            <div className="space-y-1">
                                                <span className={clsx(
                                                    "block w-fit px-2 py-0.5 rounded text-[10px] font-bold uppercase border",
                                                    roles.find(r => r.val === user.role)?.color || "bg-slate-100 text-slate-600 border-slate-200"
                                                )}>
                                                    {roles.find(r => r.val === user.role)?.label || user.role}
                                                </span>
                                                <span className={clsx(
                                                    "block w-fit px-2 py-0.5 rounded text-[10px] font-bold uppercase border",
                                                    positions.find(p => p.val === user.position)?.color
                                                )}>
                                                    {positions.find(p => p.val === user.position)?.label || user.position}
                                                </span>
                                            </div>
                                        </td>
                                        <td className="p-4 text-slate-500 text-xs hidden sm:table-cell">
                                            {user.manager ? (
                                                <div className="flex items-center gap-1 font-medium text-slate-700 bg-slate-50 px-2 py-1 rounded max-w-[140px] truncate">
                                                    <UserCheck size={14} className="shrink-0" /> {user.manager.fullName}
                                                </div>
                                            ) : <span className="text-slate-300">-</span>}
                                        </td>
                                        <td className="p-4 text-right">
                                            <div className="flex justify-end gap-1">
                                                <button onClick={() => handleEdit(user)} className="p-2 hover:bg-blue-50 text-slate-400 hover:text-blue-600 rounded-lg transition-colors" title="Sửa thông tin">
                                                    <Edit size={16} />
                                                </button>
                                                <button onClick={() => openResetPasswordModal(user)} className="p-2 hover:bg-amber-50 text-slate-400 hover:text-amber-600 rounded-lg transition-colors" title="Đổi mật khẩu">
                                                    <Key size={16} />
                                                </button>
                                                <button onClick={() => handleDelete(user.id)} className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition-colors" title="Xóa user">
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {loading && <div className="p-8 flex justify-center"><Loader2 className="animate-spin text-slate-400" /></div>}
                        {!loading && filteredUsers.length === 0 && (
                            <div className="p-8 text-center text-slate-400">
                                {searchQuery || roleFilter !== 'ALL' ? 'Không tìm thấy kết quả phù hợp' : 'Chưa có tài khoản nào'}
                            </div>
                        )}
                    </div>
                </div>

                {/* Create/Edit User Form */}
                <div className="lg:col-span-1">
                    <div className={clsx("bg-white p-6 rounded-2xl border shadow-lg h-fit sticky top-24 transition-colors", isEditing ? "border-blue-200 shadow-blue-500/10" : "border-slate-200")}>
                        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
                            <div className="flex items-center gap-3">
                                <div className={clsx("w-10 h-10 rounded-xl flex items-center justify-center transition-colors", isEditing ? "bg-blue-500 text-white" : "bg-slate-900 text-white")}>
                                    {isEditing ? <UserCog size={20} /> : <UserPlus size={20} />}
                                </div>
                                <div>
                                    <h3 className="font-bold text-slate-900">{isEditing ? "Cập nhật hồ sơ" : "Thêm nhân sự mới"}</h3>
                                    <p className="text-xs text-slate-500">{isEditing ? "Chỉnh sửa thông tin thành viên" : "Cấp tài khoản & phân quyền"}</p>
                                </div>
                            </div>
                            {isEditing && (
                                <button onClick={resetForm} className="text-xs font-bold text-slate-400 hover:text-slate-600 underline">
                                    Hủy bỏ
                                </button>
                            )}
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Username</label>
                                    <input required className="input-sm"
                                        placeholder="VD: tech_01" value={formData.username} onChange={e => setFormData({ ...formData, username: e.target.value })} />
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Mật khẩu {isEditing && <span className="text-slate-400 font-normal">(để trống = giữ)</span>}</label>
                                    <input required={!isEditing} type="password" className="input-sm font-mono"
                                        placeholder={isEditing ? "******" : "123456"} value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} />
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1">Họ và Tên</label>
                                <input required className="input-sm"
                                    placeholder="Nguyễn Văn A" value={formData.fullName} onChange={e => setFormData({ ...formData, fullName: e.target.value })} />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Email</label>
                                    <input type="email" className="input-sm"
                                        placeholder="example@bih.vn" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Số điện thoại</label>
                                    <input className="input-sm"
                                        placeholder="090..." value={formData.phoneNumber} onChange={e => setFormData({ ...formData, phoneNumber: e.target.value })} />
                                </div>
                            </div>

                            {/* Show department field only when role is DEPARTMENT */}
                            {formData.role === 'DEPARTMENT' && (
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">
                                        Khoa / Phòng <span className="text-red-500">*</span>
                                    </label>
                                    <input
                                        required
                                        className="input-sm"
                                        placeholder="VD: Khoa Nội, Khoa Ngoại, Phòng Hành chính..."
                                        value={formData.department}
                                        onChange={e => setFormData({ ...formData, department: e.target.value })} />
                                    <p className="text-[10px] text-slate-400 mt-1">Nhập tên khoa/phòng ban</p>
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Tổ / Ban</label>
                                    <select className="input-sm bg-white"
                                        value={formData.role} onChange={e => setFormData({ ...formData, role: e.target.value })}
                                    >
                                        {roles.map(r => <option key={r.val} value={r.val}>{r.label}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Chức vụ</label>
                                    <select className="input-sm bg-white"
                                        value={formData.position} onChange={e => setFormData({ ...formData, position: e.target.value })}
                                    >
                                        {positions.map(p => <option key={p.val} value={p.val}>{p.label}</option>)}
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1">Quản lý trực tiếp (Report)</label>
                                <select className="input-sm bg-white"
                                    value={formData.managerId} onChange={e => setFormData({ ...formData, managerId: e.target.value })}
                                >
                                    <option value="">-- Không có --</option>
                                    {potentialManagers.map(u => (
                                        <option key={u.id} value={u.id}>{u.fullName} ({positions.find(p => p.val === u.position)?.label})</option>
                                    ))}
                                </select>
                            </div>

                            <button disabled={submitting} type="submit" className={clsx("w-full py-3 text-white font-bold rounded-xl mt-4 transition-all shadow-lg flex justify-center items-center gap-2", isEditing ? "bg-blue-600 hover:bg-blue-700 shadow-blue-500/30" : "bg-slate-900 hover:bg-slate-800 shadow-slate-900/30")}>
                                {submitting && <Loader2 className="animate-spin" size={18} />}
                                {isEditing ? "Lưu thay đổi" : "Tạo & Phân quyền"}
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            {/* Reset Password Modal */}
            <AnimatePresence>
                {isResetModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.95, opacity: 0 }}
                            className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl"
                        >
                            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <Key className="text-amber-500" size={20} />
                                    Đặt lại mật khẩu
                                </h3>
                                <button onClick={() => setIsResetModalOpen(false)}><X size={20} className="text-slate-400 hover:text-red-500" /></button>
                            </div>

                            <div className="mb-4 p-3 bg-slate-50 rounded-xl">
                                <p className="text-sm text-slate-500">Đặt lại mật khẩu cho:</p>
                                <p className="font-bold text-slate-800">{resetUsername}</p>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-700 block mb-1">Mật khẩu mới</label>
                                    <input
                                        type="password"
                                        className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500/20 outline-none font-mono"
                                        placeholder="Nhập mật khẩu mới (ít nhất 6 ký tự)"
                                        value={newPassword}
                                        onChange={e => setNewPassword(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="mt-6 flex gap-3">
                                <button onClick={() => setIsResetModalOpen(false)} className="flex-1 py-2.5 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200">
                                    Hủy
                                </button>
                                <button
                                    onClick={handleResetPassword}
                                    disabled={!newPassword || newPassword.length < 6}
                                    className={clsx(
                                        "flex-1 py-2.5 font-bold rounded-xl shadow-lg transition-all",
                                        newPassword && newPassword.length >= 6
                                            ? "bg-amber-500 text-white hover:bg-amber-600 shadow-amber-500/20"
                                            : "bg-slate-200 text-slate-400 cursor-not-allowed"
                                    )}
                                >
                                    Xác nhận
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            <style jsx>{`
                .input-sm {
                    width: 100%;
                    padding: 0.5rem 0.75rem;
                    border: 1px solid #e2e8f0;
                    border-radius: 0.5rem;
                    font-size: 0.875rem;
                    outline: none;
                    transition: all 0.2s;
                }
                .input-sm:focus {
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
                }
            `}</style>

            {/* Toast Notification */}
            <Toast
                message={toast.message}
                type={toast.type}
                isVisible={toast.isVisible}
                onClose={hideToast}
            />
        </div>
    );
}

import { NextResponse } from 'next/server';
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can manage security reports
function canManageSecurity(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SECURITY' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) return true;
    return false;
}

// GET: Get single report detail
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const report = await prisma.securityReport.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        if (!report) {
            return NextResponse.json({ error: "Report not found" }, { status: 404 });
        }

        return NextResponse.json(report);
    } catch (error) {
        console.error("Get Security Report Error:", error);
        return NextResponse.json({ error: 'Failed to fetch report' }, { status: 500 });
    }
}

// PATCH: Update status or assign staff
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { assignedToId, status, location, incidentType, description, severity, rejectReason } = body;

        const updateData: Record<string, unknown> = {};

        // ASSIGN: Only leaders/admin can assign
        if (assignedToId !== undefined) {
            if (!canManageSecurity(user)) {
                return NextResponse.json({
                    error: "Permission denied: Only Security Leader can assign tasks"
                }, { status: 403 });
            }
            updateData.assignedToId = assignedToId ? parseInt(assignedToId) : null;
            if (!status || status === 'OPEN' || status === 'PENDING') {
                updateData.status = 'ASSIGNED';
            }
        }

        // STATUS CHANGE
        if (status) {
            // RESOLVED/CLOSED: Assigned staff or leaders can update
            if (['IN_PROGRESS', 'RESOLVED', 'CLOSED'].includes(status)) {
                const currentReport = await prisma.securityReport.findUnique({ where: { id } });
                const isAssignedStaff = currentReport?.assignedToId === user.id;
                const isLeader = canManageSecurity(user);

                if (!isAssignedStaff && !isLeader) {
                    return NextResponse.json({
                        error: "Permission denied: Only assigned staff or leaders can update status"
                    }, { status: 403 });
                }
            }

            updateData.status = status;
        }

        // CONTENT UPDATE (Allow editing if not closed, or if admin/leader)
        if (location) updateData.location = location;
        if (incidentType) updateData.incidentType = incidentType;
        if (description) updateData.description = description;
        if (severity) updateData.severity = severity;

        const updatedReport = await prisma.securityReport.update({
            where: { id },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        // === WORKFLOW TRACKING ===
        // Nếu REJECTED, tạo TicketFeedback để người yêu cầu biết lý do
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'SECURITY',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Ghi nhận timeline khi thay đổi trạng thái quan trọng
        if (status && !['PENDING', 'OPEN'].includes(status)) {
            const statusLabels: Record<string, string> = {
                'ASSIGNED': 'Đã phân công',
                'IN_PROGRESS': 'Đang xử lý',
                'RESOLVED': 'Đã giải quyết',
                'CLOSED': 'Đã đóng',
                'REJECTED': 'Từ chối'
            };

            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'SECURITY',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái: ${statusLabels[status] || status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updatedReport);
    } catch (error) {
        console.error("Update Security Report Error:", error);
        return NextResponse.json({ error: 'Failed to update report' }, { status: 500 });
    }
}

// DELETE: Delete report (Only admin or security leader)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (!canManageSecurity(user)) {
            return NextResponse.json({
                error: "Permission denied: Only Security Leader can delete reports"
            }, { status: 403 });
        }

        // Also delete related feedback
        await prisma.ticketFeedback.deleteMany({
            where: { ticketType: 'SECURITY', ticketId: parseInt(params.id) }
        });

        await prisma.securityReport.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted successfully' });
    } catch (error) {
        console.error("Delete Security Report Error:", error);
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

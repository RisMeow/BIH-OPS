import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'ADMIN') {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    try {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

        // Define status filters
        const pendingStatus = 'PENDING';
        const processingStatuses = ['ASSIGNED', 'IN_PROGRESS', 'APPROVED', 'OPEN', 'PartiallyFulfilled'];
        const completedStatuses = ['COMPLETED', 'DONE', 'RESOLVED', 'Fulfilled', 'CLOSED'];

        // Helper to count requests for a model
        const countRequests = async (model: any, whereClause: any = {}) => {
            return await model.count({ where: whereClause });
        };

        // Parallel fetch for all departments and overall stats
        const [
            // Technical
            techPending, techProcessing, techTotalMonth, techCompletedMonth,
            // Nursing
            nursingPending, nursingProcessing, nursingTotalMonth, nursingCompletedMonth,
            // Driver
            driverPending, driverProcessing, driverTotalMonth, driverCompletedMonth,
            // Security
            securityPending, securityProcessing, securityTotalMonth, securityCompletedMonth,
            // Supply
            supplyPending, supplyProcessing, supplyTotalMonth, supplyCompletedMonth,
            // Environment
            envPending, envProcessing, envTotalMonth, envCompletedMonth,
            // Staff
            totalStaff
        ] = await Promise.all([
            // Technical
            prisma.maintenanceRequest.count({ where: { status: 'PENDING' } }),
            prisma.maintenanceRequest.count({ where: { status: { in: ['ASSIGNED', 'IN_PROGRESS'] } } }),
            prisma.maintenanceRequest.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.maintenanceRequest.count({ where: { status: 'COMPLETED', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Nursing
            prisma.nursingRequest.count({ where: { status: 'PENDING' } }),
            prisma.nursingRequest.count({ where: { status: { in: ['ASSIGNED', 'IN_PROGRESS'] } } }),
            prisma.nursingRequest.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.nursingRequest.count({ where: { status: 'COMPLETED', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Driver
            prisma.transportRequest.count({ where: { status: 'PENDING' } }),
            prisma.transportRequest.count({ where: { status: { in: ['APPROVED', 'IN_PROGRESS'] } } }),
            prisma.transportRequest.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.transportRequest.count({ where: { status: 'COMPLETED', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Security (OPEN/IN_PROGRESS/RESOLVED)
            prisma.securityReport.count({ where: { status: 'OPEN' } }),
            prisma.securityReport.count({ where: { status: 'IN_PROGRESS' } }),
            prisma.securityReport.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.securityReport.count({ where: { status: 'RESOLVED', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Supply
            prisma.supplyRequest.count({ where: { status: 'PENDING' } }),
            prisma.supplyRequest.count({ where: { status: 'PartiallyFulfilled' } }),
            prisma.supplyRequest.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.supplyRequest.count({ where: { status: 'Fulfilled', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Environment
            prisma.cleaningRequest.count({ where: { status: 'PENDING' } }),
            prisma.cleaningRequest.count({ where: { status: { in: ['ASSIGNED', 'IN_PROGRESS'] } } }),
            prisma.cleaningRequest.count({ where: { createdAt: { gte: startOfMonth, lte: endOfMonth } } }),
            prisma.cleaningRequest.count({ where: { status: 'COMPLETED', createdAt: { gte: startOfMonth, lte: endOfMonth } } }),

            // Total Staff (Active users)
            prisma.user.count({ where: { role: { not: 'ADMIN' } } })
        ]);

        // Aggregate Data
        const departments = [
            { id: "TECHNICAL", name: "Kỹ Thuật", pending: techPending, processing: techProcessing },
            { id: "NURSING", name: "Hộ Lý", pending: nursingPending, processing: nursingProcessing },
            { id: "DRIVER", name: "Đội Xe", pending: driverPending, processing: driverProcessing },
            { id: "SECURITY", name: "An Ninh", pending: securityPending, processing: securityProcessing },
            { id: "SUPPLY", name: "Cung Ứng", pending: supplyPending, processing: supplyProcessing },
            { id: "ENVIRONMENT", name: "Môi Trường", pending: envPending, processing: envProcessing },
        ];

        // Overall Stats
        const totalRequestsMonth = techTotalMonth + nursingTotalMonth + driverTotalMonth + securityTotalMonth + supplyTotalMonth + envTotalMonth;
        const totalCompletedMonth = techCompletedMonth + nursingCompletedMonth + driverCompletedMonth + securityCompletedMonth + supplyCompletedMonth + envCompletedMonth;
        const totalProcessing = techProcessing + nursingProcessing + driverProcessing + securityProcessing + supplyProcessing + envProcessing; // Snapshot of current processing, not just monthly

        const completionRate = totalRequestsMonth > 0 ? ((totalCompletedMonth / totalRequestsMonth) * 100).toFixed(1) : "0";

        return NextResponse.json({
            departments,
            stats: {
                totalRequestsMonth,
                completionRate: `${completionRate}%`,
                totalProcessing,
                totalStaff
            }
        });
    } catch (error) {
        console.error("Error fetching overview stats:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

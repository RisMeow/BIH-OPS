import { NextResponse } from 'next/server';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

// Helper to get current user from session - reused logic
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        // Ensure ID is a number
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string; username: string };
}

export async function GET() {
    try {
        const userSession = await getCurrentUser();
        if (!userSession) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const user = await prisma.user.findUnique({
            where: { id: userSession.id },
            select: {
                id: true,
                username: true,
                fullName: true,
                email: true,
                phoneNumber: true,
                role: true,
                position: true
            }
        });

        if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

        return NextResponse.json(user);
    } catch (error) {
        console.error("Profile Fetch Error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const userSession = await getCurrentUser();
        if (!userSession) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const body = await request.json();
        const { fullName, email, phoneNumber, currentPassword, newPassword } = body;

        const user = await prisma.user.findUnique({
            where: { id: userSession.id },
        });

        if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

        const updateData: any = {};
        if (fullName !== undefined) updateData.fullName = fullName;
        if (email !== undefined) updateData.email = email;
        if (phoneNumber !== undefined) updateData.phoneNumber = phoneNumber;

        if (newPassword) {
            if (!currentPassword) return NextResponse.json({ error: "Vui lòng nhập mật khẩu hiện tại" }, { status: 400 });

            const isValid = await bcrypt.compare(currentPassword, user.password);
            if (!isValid) return NextResponse.json({ error: "Mật khẩu hiện tại không đúng" }, { status: 400 });

            const hashedPassword = await bcrypt.hash(newPassword, 10);
            updateData.password = hashedPassword;
        }

        const updatedUser = await prisma.user.update({
            where: { id: userSession.id },
            data: updateData
        });

        return NextResponse.json({
            id: updatedUser.id,
            fullName: updatedUser.fullName,
            email: updatedUser.email,
            phoneNumber: updatedUser.phoneNumber
        });
    } catch (error) {
        console.error("Profile Update Error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

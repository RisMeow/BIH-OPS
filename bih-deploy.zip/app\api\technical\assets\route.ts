import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to check if user has technical access
async function checkTechnicalAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    const user = session.user as { id: number; role: string; position: string };
    if (user.role !== 'ADMIN' && user.role !== 'TECHNICAL') return null;
    return user;
}

// GET: List all assets with optional filters
export async function GET(request: Request) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const category = searchParams.get('category');
        const status = searchParams.get('status');
        const search = searchParams.get('search');

        const where: any = {};
        if (category) where.category = category;
        if (status) where.status = status;
        if (search) {
            where.OR = [
                { name: { contains: search, mode: 'insensitive' } },
                { code: { contains: search, mode: 'insensitive' } },
                { location: { contains: search, mode: 'insensitive' } }
            ];
        }

        const assets = await prisma.asset.findMany({
            where,
            include: {
                maintenanceSchedules: {
                    where: { isActive: true },
                    select: { id: true, title: true, frequency: true, nextDueAt: true }
                },
                _count: {
                    select: { maintenanceHistory: true }
                }
            },
            orderBy: { createdAt: 'desc' }
        });

        return NextResponse.json(assets);
    } catch (error) {
        console.error("Fetch assets error:", error);
        return NextResponse.json({ error: 'Failed to fetch assets' }, { status: 500 });
    }
}

// POST: Create new asset
export async function POST(request: Request) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Only leaders can add assets
        if (user.role !== 'ADMIN' && !['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) {
            return NextResponse.json({ error: "Permission denied: Only leaders can add assets" }, { status: 403 });
        }

        const body = await request.json();
        const { code, name, category, location, manufacturer, model, serialNumber, purchaseDate, warrantyExpiry, notes } = body;

        if (!code || !name || !category || !location) {
            return NextResponse.json({ error: "Missing required fields: code, name, category, location" }, { status: 400 });
        }

        // Check if code already exists
        const existing = await prisma.asset.findUnique({ where: { code } });
        if (existing) {
            return NextResponse.json({ error: "Asset code already exists" }, { status: 400 });
        }

        const asset = await prisma.asset.create({
            data: {
                code,
                name,
                category,
                location,
                manufacturer,
                model,
                serialNumber,
                purchaseDate: purchaseDate ? new Date(purchaseDate) : null,
                warrantyExpiry: warrantyExpiry ? new Date(warrantyExpiry) : null,
                notes
            }
        });

        return NextResponse.json(asset, { status: 201 });
    } catch (error) {
        console.error("Create asset error:", error);
        return NextResponse.json({ error: 'Failed to create asset' }, { status: 500 });
    }
}

"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, Check, Info, AlertTriangle, CheckCircle2, Clock, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { clsx } from "clsx";

interface Notification {
    id: number;
    title: string;
    message: string;
    type: "INFO" | "SUCCESS" | "WARNING" | "URGENT";
    isRead: boolean;
    createdAt: string;
    linkType?: string;
    linkId?: number;
}

export default function NotificationPopover() {
    const router = useRouter();
    const [isOpen, setIsOpen] = useState(false);
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [loading, setLoading] = useState(false);
    const popoverRef = useRef<HTMLDivElement>(null);

    // Fetch notifications
    const fetchNotifications = async () => {
        try {
            setLoading(true);
            const res = await fetch('/api/notifications');
            if (res.ok) {
                const data = await res.json();
                setNotifications(data.notifications);
                setUnreadCount(data.unreadCount);
            }
        } catch (error) {
            console.error("Failed to fetch notifications", error);
        } finally {
            setLoading(false);
        }
    };

    // Poll for new notifications every minute
    useEffect(() => {
        fetchNotifications();
        const interval = setInterval(fetchNotifications, 60000);
        return () => clearInterval(interval);
    }, []);

    // Close on click outside
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const markAsRead = async (id: number) => {
        try {
            await fetch('/api/notifications', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });
            // Optimistic update
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
            setUnreadCount(prev => Math.max(0, prev - 1));
        } catch (error) {
            console.error("Failed to mark as read", error);
        }
    };

    const markAllAsRead = async () => {
        try {
            await fetch('/api/notifications', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'mark_all_read' })
            });
            setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
            setUnreadCount(0);
        } catch (error) {
            console.error("Failed to mark all as read", error);
        }
    };

    const handleNotificationClick = async (notif: Notification) => {
        if (!notif.isRead) {
            await markAsRead(notif.id);
        }
        setIsOpen(false);

        // Navigate if link exists
        if (notif.linkType) {
            // Mapping for specific routing logic could go here
            // distinct routes based on linkType + linkId
            // For now, simple mapping:
            if (['TECHNICAL', 'NURSING', 'DRIVER', 'SECURITY', 'SUPPLY', 'ENVIRONMENT'].includes(notif.linkType)) {
                router.push(`/dashboard/${notif.linkType.toLowerCase()}`);
            }
        }
    };

    const getTypeIcon = (type: string) => {
        switch (type) {
            case 'SUCCESS': return <CheckCircle2 size={16} className="text-emerald-500" />;
            case 'WARNING': return <AlertTriangle size={16} className="text-amber-500" />;
            case 'URGENT': return <AlertTriangle size={16} className="text-red-500" />;
            default: return <Info size={16} className="text-blue-500" />;
        }
    };

    return (
        <div className="relative" ref={popoverRef}>
            <button
                onClick={() => { setIsOpen(!isOpen); if (!isOpen) fetchNotifications(); }}
                className={clsx(
                    "relative p-3 rounded-xl transition-all duration-200 border",
                    isOpen ? "bg-blue-50 text-blue-600 border-blue-200" : "bg-white text-slate-500 border-transparent hover:bg-slate-100",
                    unreadCount > 0 && !isOpen && "shadow-sm"
                )}
            >
                <Bell size={20} />
                {unreadCount > 0 && (
                    <span className="absolute top-2 right-2 flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500 border-2 border-white"></span>
                    </span>
                )}
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-80 md:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden z-[100] origin-top-right"
                    >
                        {/* Header */}
                        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white/50 backdrop-blur-sm">
                            <h3 className="font-bold text-slate-800">Thông báo</h3>
                            {unreadCount > 0 && (
                                <button
                                    onClick={markAllAsRead}
                                    className="text-xs font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-blue-50 transition-colors"
                                >
                                    <Check size={14} /> Đánh dấu đã đọc
                                </button>
                            )}
                        </div>

                        {/* List */}
                        <div className="max-h-[60vh] overflow-y-auto custom-scrollbar">
                            {loading && notifications.length === 0 ? (
                                <div className="p-8 text-center text-slate-400">
                                    <span className="animate-pulse">Đang tải...</span>
                                </div>
                            ) : notifications.length === 0 ? (
                                <div className="p-8 text-center flex flex-col items-center gap-2">
                                    <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                                        <Bell size={24} />
                                    </div>
                                    <p className="text-slate-500 text-sm">Không có thông báo mới</p>
                                </div>
                            ) : (
                                <div className="divide-y divide-slate-50">
                                    {notifications.map((notif) => (
                                        <div
                                            key={notif.id}
                                            onClick={() => handleNotificationClick(notif)}
                                            className={clsx(
                                                "p-4 hover:bg-slate-50 transition-colors cursor-pointer flex gap-3",
                                                !notif.isRead && "bg-blue-50/30"
                                            )}
                                        >
                                            <div className={clsx(
                                                "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1",
                                                notif.type === 'URGENT' ? "bg-red-100" :
                                                    notif.type === 'SUCCESS' ? "bg-emerald-100" :
                                                        "bg-blue-100"
                                            )}>
                                                {getTypeIcon(notif.type)}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex justify-between items-start mb-0.5">
                                                    <h4 className={clsx(
                                                        "text-sm font-semibold truncate pr-2",
                                                        !notif.isRead ? "text-slate-900" : "text-slate-600"
                                                    )}>
                                                        {notif.title}
                                                    </h4>
                                                    {!notif.isRead && (
                                                        <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0 mt-1.5" />
                                                    )}
                                                </div>
                                                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 mb-1.5">
                                                    {notif.message}
                                                </p>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                                        <Clock size={10} />
                                                        {new Date(notif.createdAt).toLocaleDateString('vi-VN', {
                                                            hour: '2-digit', minute: '2-digit'
                                                        })}
                                                    </span>
                                                    {notif.type === 'URGENT' && (
                                                        <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0 rounded font-bold">KHẨN</span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

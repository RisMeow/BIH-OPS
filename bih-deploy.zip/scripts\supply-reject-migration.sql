-- Add rejectionReason to ProcurementPlan
ALTER TABLE "ProcurementPlan" ADD COLUMN IF NOT EXISTS "rejectionReason" TEXT;

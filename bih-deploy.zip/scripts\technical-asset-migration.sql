-- Technical Asset Management Migration
-- Creates tables for Asset, MaintenanceSchedule, MaintenanceHistory

-- Asset table (Tài sản kỹ thuật)
CREATE TABLE IF NOT EXISTS "Asset" (
    "id" SERIAL PRIMARY KEY,
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "category" VARCHAR(50) NOT NULL,
    "location" VARCHAR(255) NOT NULL,
    "manufacturer" VARCHAR(255),
    "model" VARCHAR(255),
    "serialNumber" VARCHAR(255),
    "purchaseDate" TIMESTAMP,
    "warrantyExpiry" TIMESTAMP,
    "status" VARCHAR(50) DEFAULT 'ACTIVE',
    "notes" TEXT,
    "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Maintenance Schedule table (Lịch bảo trì định kỳ)
CREATE TABLE IF NOT EXISTS "MaintenanceSchedule" (
    "id" SERIAL PRIMARY KEY,
    "assetId" INTEGER NOT NULL REFERENCES "Asset"("id") ON DELETE CASCADE,
    "title" VARCHAR(255) NOT NULL,
    "frequency" VARCHAR(50) NOT NULL,
    "dayOfWeek" INTEGER,
    "dayOfMonth" INTEGER,
    "monthOfYear" INTEGER,
    "lastExecutedAt" TIMESTAMP,
    "nextDueAt" TIMESTAMP,
    "checklistItems" TEXT,
    "isActive" BOOLEAN DEFAULT TRUE,
    "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Maintenance History table (Lịch sử bảo trì)
CREATE TABLE IF NOT EXISTS "MaintenanceHistory" (
    "id" SERIAL PRIMARY KEY,
    "assetId" INTEGER NOT NULL REFERENCES "Asset"("id") ON DELETE CASCADE,
    "type" VARCHAR(50) NOT NULL,
    "description" TEXT NOT NULL,
    "performedById" INTEGER,
    "performedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    "cost" FLOAT,
    "notes" TEXT,
    "requestId" INTEGER
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS "idx_asset_category" ON "Asset"("category");
CREATE INDEX IF NOT EXISTS "idx_asset_status" ON "Asset"("status");
CREATE INDEX IF NOT EXISTS "idx_asset_location" ON "Asset"("location");
CREATE INDEX IF NOT EXISTS "idx_schedule_asset" ON "MaintenanceSchedule"("assetId");
CREATE INDEX IF NOT EXISTS "idx_schedule_nextdue" ON "MaintenanceSchedule"("nextDueAt");
CREATE INDEX IF NOT EXISTS "idx_history_asset" ON "MaintenanceHistory"("assetId");
CREATE INDEX IF NOT EXISTS "idx_history_type" ON "MaintenanceHistory"("type");

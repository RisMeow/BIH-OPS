import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

function canManageEnv(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'ENVIRONMENT' && ['MANAGER', 'LEADER'].includes(user.position)) return true;
    return false;
}

export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const log = await prisma.wasteCollectionLog.findUnique({
            where: { id: parseInt(params.id) },
            include: { handler: { select: { fullName: true } } }
        });

        if (!log) return NextResponse.json({ error: "Not found" }, { status: 404 });
        return NextResponse.json(log);
    } catch (error) {
        return NextResponse.json({ error: "Server Error" }, { status: 500 });
    }
}

export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (user.role !== 'ENVIRONMENT' && user.role !== 'ADMIN') return NextResponse.json({ error: "Forbidden" }, { status: 403 });

        const body = await request.json();
        const { wasteType, weight, location, notes, status } = body;

        const updated = await prisma.wasteCollectionLog.update({
            where: { id: parseInt(params.id) },
            data: {
                wasteType,
                weight: weight ? parseFloat(weight) : undefined,
                location,
                notes,
                status
            }
        });

        return NextResponse.json(updated);
    } catch (error) {
        return NextResponse.json({ error: "Update failed" }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!canManageEnv(user)) return NextResponse.json({ error: "Forbidden: Manager only" }, { status: 403 });

        await prisma.wasteCollectionLog.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Delete failed" }, { status: 500 });
    }
}

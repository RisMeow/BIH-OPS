import { prisma } from "@/lib/prisma";

interface CreateNotificationParams {
    userId: number;
    title: string;
    message?: string;
    type?: "INFO" | "SUCCESS" | "WARNING" | "URGENT";
    linkType?: "TECHNICAL" | "NURSING" | "DRIVER" | "SECURITY" | "SUPPLY" | "ENVIRONMENT";
    linkId?: number;
}

/**
 * Tạo thông báo cho một user cụ thể
 */
export async function createNotification(params: CreateNotificationParams) {
    try {
        return await prisma.notification.create({
            data: {
                userId: params.userId,
                title: params.title,
                type: params.type || "INFO",
                ...(params.message && { message: params.message }),
                ...(params.linkType && { linkType: params.linkType }),
                ...(params.linkId && { linkId: params.linkId })
            }
        });
    } catch (error) {
        console.error("Failed to create notification:", error);
        return null;
    }
}

/**
 * Tạo thông báo cho nhiều users cùng lúc (ví dụ: tất cả leaders của bộ phận)
 */
export async function createBulkNotifications(
    userIds: number[],
    params: Omit<CreateNotificationParams, "userId">
) {
    try {
        return await prisma.notification.createMany({
            data: userIds.map(userId => ({
                userId,
                title: params.title,
                message: params.message,
                type: params.type || "INFO",
                linkType: params.linkType,
                linkId: params.linkId
            }))
        });
    } catch (error) {
        console.error("Failed to create bulk notifications:", error);
        return null;
    }
}

/**
 * Tạo thông báo cho Leaders/Managers của một bộ phận cụ thể
 */
export async function notifyDepartmentLeaders(
    department: "TECHNICAL" | "NURSING" | "DRIVER" | "SECURITY" | "SUPPLY" | "ENVIRONMENT",
    params: Omit<CreateNotificationParams, "userId">
) {
    try {
        // Tìm tất cả leaders/managers/supervisors của bộ phận
        const leaders = await prisma.user.findMany({
            where: {
                role: department,
                position: { in: ["LEADER", "MANAGER", "SUPERVISOR"] }
            },
            select: { id: true }
        });

        // Thêm Admin vào danh sách nhận thông báo 
        const admins = await prisma.user.findMany({
            where: { role: "ADMIN" },
            select: { id: true }
        });

        const allUserIds = [...leaders.map(l => l.id), ...admins.map(a => a.id)];

        if (allUserIds.length === 0) return null;

        return await createBulkNotifications(allUserIds, {
            ...params,
            linkType: department
        });
    } catch (error) {
        console.error("Failed to notify department leaders:", error);
        return null;
    }
}

/**
 * Labels cho các loại yêu cầu
 */
export const departmentLabels: Record<string, string> = {
    TECHNICAL: "Kỹ thuật",
    NURSING: "Hộ lý",
    DRIVER: "Đội xe",
    SECURITY: "An ninh",
    SUPPLY: "Vật tư",
    ENVIRONMENT: "Môi trường"
};

export const priorityLabels: Record<string, string> = {
    LOW: "Thấp",
    MEDIUM: "Trung bình",
    HIGH: "Cao",
    URGENT: "Khẩn cấp"
};

export const statusLabels: Record<string, string> = {
    PENDING: "Chờ xử lý",
    ASSIGNED: "Đã phân công",
    IN_PROGRESS: "Đang thực hiện",
    COMPLETED: "Hoàn thành",
    CANCELLED: "Đã hủy",
    REJECTED: "Từ chối",
    APPROVED: "Đã duyệt"
};

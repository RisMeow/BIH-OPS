"use client";

import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, XCircle, AlertCircle, Info, X } from "lucide-react";
import { useEffect } from "react";

export type ToastType = "success" | "error" | "warning" | "info";

interface ToastProps {
    message: string;
    type: ToastType;
    isVisible: boolean;
    onClose: () => void;
    duration?: number;
}

export default function Toast({ message, type, isVisible, onClose, duration = 3000 }: ToastProps) {
    useEffect(() => {
        if (isVisible && duration > 0) {
            const timer = setTimeout(() => {
                onClose();
            }, duration);
            return () => clearTimeout(timer);
        }
    }, [isVisible, duration, onClose]);

    const icons = {
        success: CheckCircle,
        error: XCircle,
        warning: AlertCircle,
        info: Info,
    };

    const colors = {
        success: {
            bg: "bg-emerald-50 border-emerald-200",
            text: "text-emerald-800",
            icon: "text-emerald-500",
            progress: "bg-emerald-500"
        },
        error: {
            bg: "bg-red-50 border-red-200",
            text: "text-red-800",
            icon: "text-red-500",
            progress: "bg-red-500"
        },
        warning: {
            bg: "bg-amber-50 border-amber-200",
            text: "text-amber-800",
            icon: "text-amber-500",
            progress: "bg-amber-500"
        },
        info: {
            bg: "bg-blue-50 border-blue-200",
            text: "text-blue-800",
            icon: "text-blue-500",
            progress: "bg-blue-500"
        },
    };

    const Icon = icons[type];
    const colorScheme = colors[type];

    return (
        <AnimatePresence>
            {isVisible && (
                <motion.div
                    initial={{ opacity: 0, y: -50, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.95 }}
                    transition={{ duration: 0.2, ease: "easeOut" }}
                    className="fixed top-4 right-4 z-[9999] max-w-md"
                >
                    <div className={`${colorScheme.bg} border rounded-xl shadow-lg overflow-hidden`}>
                        <div className="flex items-start gap-3 p-4">
                            <Icon className={`${colorScheme.icon} flex-shrink-0 mt-0.5`} size={20} />
                            <p className={`${colorScheme.text} flex-1 font-medium text-sm`}>
                                {message}
                            </p>
                            <button
                                onClick={onClose}
                                className={`${colorScheme.text} hover:opacity-70 transition-opacity flex-shrink-0`}
                            >
                                <X size={18} />
                            </button>
                        </div>
                        {duration > 0 && (
                            <motion.div
                                initial={{ width: "100%" }}
                                animate={{ width: "0%" }}
                                transition={{ duration: duration / 1000, ease: "linear" }}
                                className={`h-1 ${colorScheme.progress}`}
                            />
                        )}
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
}


const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // Target the PDF download button
    const pdfBtnRegex = /<button onClick=\{handleDownloadPDF\}[\s\S]*?PDF\s*<\/button>/;

    const newButtons = `
                                        {(session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER')) && (
                                            <button onClick={() => handleDeletePlan(selectedPlan.id)} className="px-4 py-2 text-red-600 hover:bg-red-50 font-bold rounded-xl border border-transparent hover:border-red-100">Xóa phiếu</button>
                                        )}
                                        
                                        <button onClick={() => handleRevertPlan(selectedPlan.id)} className="px-4 py-2 bg-amber-100 text-amber-700 font-bold rounded-xl hover:bg-amber-200">Điều chỉnh</button>

                                        <button onClick={handleDownloadPDF} className="px-6 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center gap-2">
                                            <Download size={18} /> PDF
                                        </button>`;

    if (pdfBtnRegex.test(content)) {
        content = content.replace(pdfBtnRegex, newButtons);
        console.log("Buttons injected successfully.");
        fs.writeFileSync(path, content);
    } else {
        console.log("PDF button not found for injection.");
    }

} catch (e) {
    console.error("Error:", e);
}

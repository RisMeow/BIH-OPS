import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(request: Request) {
    try {
        // Fetch all locations, or hierarchy
        // For simple dropdown: fetch all hierarchy
        // Ideally should support query param ?parentId=...

        const { searchParams } = new URL(request.url);
        const parentId = searchParams.get('parentId');

        const whereCondition = parentId ? { parentId } : { parentId: null };

        const locations = await prisma.location.findMany({
            where: whereCondition,
            include: { children: true },
            orderBy: { name: 'asc' }
        });

        return NextResponse.json(locations);
    } catch (error) {
        return NextResponse.json({ error: "Failed to fetch locations" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { name, code, type, description, parentId } = body;

        const location = await prisma.location.create({
            data: {
                name, code, type, description, parentId
            }
        });
        return NextResponse.json(location);
    } catch (error) {
        return NextResponse.json({ error: "Failed to create location" }, { status: 500 });
    }
}

"use client";

import { useState, useEffect } from "react";
import { Loader2, MapPin, ChevronRight, Check } from "lucide-react";
import { clsx } from "clsx";

interface Location {
    id: string;
    name: string;
    type: string;
    children?: Location[];
}

interface LocationSelectorProps {
    value: string; // The final selected string (e.g. "Khu A - Tầng 2 - Phòng 201")
    onChange: (value: string) => void;
    onLocationSelect?: (locationId: string) => void;
    label?: string;
}

export default function LocationSelector({ value, onChange, onLocationSelect, label = "Vị trí" }: LocationSelectorProps) {
    const [blocks, setBlocks] = useState<Location[]>([]);
    const [floors, setFloors] = useState<Location[]>([]);
    const [rooms, setRooms] = useState<Location[]>([]);

    const [selectedBlock, setSelectedBlock] = useState<Location | null>(null);
    const [selectedFloor, setSelectedFloor] = useState<Location | null>(null);
    const [selectedRoom, setSelectedRoom] = useState<Location | null>(null);

    const [loading, setLoading] = useState(false);
    const [mode, setMode] = useState<"select" | "manual">("select");
    const [manualValue, setManualValue] = useState(value);

    // Initial fetch for Blocks (Root locations)
    useEffect(() => {
        fetchLocations(null, setBlocks);
    }, []);

    const fetchLocations = async (parentId: string | null, setter: (data: Location[]) => void) => {
        setLoading(true);
        try {
            const url = parentId
                ? `/api/locations?parentId=${parentId}`
                : '/api/locations' // If logic in API handles no query param as root

            // Check API logic: API implementation I saw handled "?parentId=" vs no param slightly differently
            // line 15: const whereCondition = parentId ? { parentId } : { parentId: null };
            // So calling `/api/locations` returns roots. Correct.

            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setter(data);
            }
        } catch (error) {
            console.error("Failed to fetch locations", error);
        } finally {
            setLoading(false);
        }
    };

    const handleBlockChange = (blockId: string) => {
        const block = blocks.find(b => b.id === blockId) || null;
        setSelectedBlock(block);
        setSelectedFloor(null);
        setSelectedRoom(null);
        setFloors([]);
        setRooms([]);

        onChange(constructLocationString(block, null, null));

        if (block) {
            fetchLocations(block.id, setFloors);
        }
    };

    const handleFloorChange = (floorId: string) => {
        const floor = floors.find(f => f.id === floorId) || null;
        setSelectedFloor(floor);
        setSelectedRoom(null);
        setRooms([]);

        onChange(constructLocationString(selectedBlock, floor, null));

        if (floor) {
            fetchLocations(floor.id, setRooms);
        }
    };

    const handleRoomChange = (roomId: string) => {
        const room = rooms.find(r => r.id === roomId) || null;
        setSelectedRoom(room);

        onChange(constructLocationString(selectedBlock, selectedFloor, room));
        if (room && onLocationSelect) {
            onLocationSelect(room.id);
        }
    };

    const constructLocationString = (b: Location | null, f: Location | null, r: Location | null) => {
        const parts = [];
        if (b) parts.push(b.name);
        if (f) parts.push(f.name);
        if (r) parts.push(r.name);
        return parts.join(" - ");
    };

    // Toggle manual input in case dropdown data is missing
    const toggleMode = () => {
        if (mode === "select") {
            setMode("manual");
            setManualValue(value);
        } else {
            setMode("select");
            // Reset logic if needed or just switch back
        }
    };

    // Sync manual input to parent
    const handleManualChange = (val: string) => {
        setManualValue(val);
        onChange(val);
    };

    return (
        <div className="space-y-3">
            <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <MapPin size={14} /> {label} <span className="text-red-500">*</span>
                </label>
                <button
                    type="button"
                    onClick={toggleMode}
                    className="text-xs text-emerald-600 font-medium hover:underline"
                >
                    {mode === "select" ? "Nhập tay (nếu không tìm thấy)" : "Chọn từ danh sách"}
                </button>
            </div>

            {mode === "select" ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {/* Block Select */}
                    <div>
                        <select
                            className="w-full p-2.5 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none"
                            value={selectedBlock?.id || ""}
                            onChange={(e) => handleBlockChange(e.target.value)}
                        >
                            <option value="">-- Chọn Khu/Nhà --</option>
                            {blocks.map(b => (
                                <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                        </select>
                    </div>

                    {/* Floor Select */}
                    <div className={clsx(!selectedBlock && "opacity-50 pointer-events-none")}>
                        <select
                            className="w-full p-2.5 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none"
                            value={selectedFloor?.id || ""}
                            onChange={(e) => handleFloorChange(e.target.value)}
                            disabled={!selectedBlock}
                        >
                            <option value="">-- Chọn Tầng --</option>
                            {floors.map(f => (
                                <option key={f.id} value={f.id}>{f.name}</option>
                            ))}
                        </select>
                    </div>

                    {/* Room Select */}
                    <div className={clsx(!selectedFloor && "opacity-50 pointer-events-none")}>
                        <select
                            className="w-full p-2.5 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none"
                            value={selectedRoom?.id || ""}
                            onChange={(e) => handleRoomChange(e.target.value)}
                            disabled={!selectedFloor}
                        >
                            <option value="">-- Chọn Phòng/Khu vực --</option>
                            {rooms.map(r => (
                                <option key={r.id} value={r.id}>{r.name}</option>
                            ))}
                        </select>
                    </div>

                    {loading && <div className="text-xs text-slate-400 col-span-3 flex items-center gap-1"><Loader2 size={10} className="animate-spin" /> Đang tải dữ liệu...</div>}
                </div>
            ) : (
                <input
                    required
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    placeholder="VD: Tầng 3, Phòng 301, Khoa Nội"
                    value={manualValue}
                    onChange={(e) => handleManualChange(e.target.value)}
                />
            )}

            {/* Display formatted selection if in select mode */}
            {mode === "select" && value && (
                <div className="text-sm bg-slate-50 p-2 rounded-lg text-slate-600 flex items-center gap-2">
                    <Check size={14} className="text-emerald-500" />
                    Đã chọn: <span className="font-semibold text-slate-800">{value}</span>
                </div>
            )}
        </div>
    );
}

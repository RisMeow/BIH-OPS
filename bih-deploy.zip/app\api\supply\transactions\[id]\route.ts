import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Use a shared Prisma Client instance or create new.
// For robust serverless, usually global instance. Here keeping standard pattern.
import { prisma } from "@/lib/prisma";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

function isManagerOrAdmin(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    // Strictly Manager as requested, or Leader/Manager depending on interpretation.
    // User said "manager". I will include MANAGER.
    if (user.role === 'SUPPLY' && user.position === 'MANAGER') return true;
    return false;
}

export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!isManagerOrAdmin(user)) {
            return NextResponse.json({ error: "Permission denied: Manager/Admin only" }, { status: 403 });
        }

        const body = await request.json();
        const { reason, referenceId } = body;

        // Only allow editing metadata, not quantity/type to preserve stock integrity
        const updated = await prisma.inventoryTransaction.update({
            where: { id: parseInt(params.id) },
            data: {
                reason,
                referenceId
            }
        });

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Transaction Update Error:", error);
        return NextResponse.json({ error: "Update failed" }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!isManagerOrAdmin(user)) {
            return NextResponse.json({ error: "Permission denied: Manager/Admin only" }, { status: 403 });
        }

        // We delete the record. We DO NOT auto-adjust stock to avoid complex consistency issues (e.g. stock already used).
        // Managers should manually correct stock if this was a mistake.
        await prisma.inventoryTransaction.delete({ where: { id: parseInt(params.id) } });

        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Delete failed" }, { status: 500 });
    }
}

import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; fullName: string } | null;
}

// GET: Lấy danh sách xe
export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const vehicles = await prisma.vehicle.findMany({
            orderBy: { licensePlate: 'asc' },
            include: {
                _count: {
                    select: { trips: true }
                }
            }
        });
        return NextResponse.json(vehicles);
    } catch (error) {
        console.error("Fetch Vehicles Error:", error);
        return NextResponse.json({ error: "Failed to fetch vehicles" }, { status: 500 });
    }
}

// POST: Thêm xe mới
export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Chỉ DRIVER leader/admin mới được thêm xe
        if (user.role !== 'DRIVER' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Không có quyền thêm xe" }, { status: 403 });
        }

        const body = await request.json();
        const {
            licensePlate, vehicleType, brand, model, color, seats,
            currentKm, registrationExpiry, insuranceExpiry, nextMaintenanceKm
        } = body;

        if (!licensePlate || !vehicleType) {
            return NextResponse.json({ error: "Thiếu biển số hoặc loại xe" }, { status: 400 });
        }

        const newVehicle = await prisma.vehicle.create({
            data: {
                licensePlate,
                vehicleType,
                brand: brand || null,
                model: model || null,
                color: color || null,
                seats: seats || 4,
                status: 'AVAILABLE',
                currentKm: currentKm || null,
                registrationExpiry: registrationExpiry ? new Date(registrationExpiry) : null,
                insuranceExpiry: insuranceExpiry ? new Date(insuranceExpiry) : null,
                lastMaintenance: body.lastMaintenance ? new Date(body.lastMaintenance) : null,
                nextMaintenanceKm: nextMaintenanceKm || null
            }
        });

        return NextResponse.json(newVehicle, { status: 201 });
    } catch (error) {
        console.error("Create Vehicle Error:", error);
        return NextResponse.json({ error: "Failed to create vehicle" }, { status: 500 });
    }
}

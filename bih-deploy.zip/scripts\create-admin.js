const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    const hashedPassword = await bcrypt.hash('123456', 10);

    const admin = await prisma.user.upsert({
        where: { username: 'admin' },
        update: {
            password: hashedPassword,
        },
        create: {
            username: 'admin',
            password: hashedPassword,
            fullName: 'Administrator',
            role: 'ADMIN',
            position: 'MANAGER',
            email: 'admin@bih.vn',
        },
    });

    console.log('Admin user created/updated:', admin);

    // Create some test users for each department
    const departments = [
        { username: 'tech_manager', fullName: 'Trưởng phòng Kỹ thuật', role: 'TECHNICAL', position: 'MANAGER' },
        { username: 'nursing_staff', fullName: 'Nhân viên Hộ lý', role: 'NURSING', position: 'STAFF' },
        { username: 'driver_staff', fullName: 'Tài xế 1', role: 'DRIVER', position: 'STAFF' },
        { username: 'security_leader', fullName: 'Tổ trưởng An ninh', role: 'SECURITY', position: 'LEADER' },
        { username: 'supply_manager', fullName: 'Trưởng phòng Cung ứng', role: 'SUPPLY', position: 'MANAGER' },
        { username: 'env_staff', fullName: 'Nhân viên Môi trường', role: 'ENVIRONMENT', position: 'STAFF' },
    ];

    for (const dept of departments) {
        const user = await prisma.user.upsert({
            where: { username: dept.username },
            update: { password: hashedPassword },
            create: {
                ...dept,
                password: hashedPassword,
            },
        });
        console.log('User created/updated:', user.username);
    }

    console.log('\n✅ All users created successfully!');
    console.log('Login credentials for all users: password = 123456');
}

main()
    .then(async () => {
        await prisma.$disconnect();
    })
    .catch(async (e) => {
        console.error(e);
        await prisma.$disconnect();
        process.exit(1);
    });

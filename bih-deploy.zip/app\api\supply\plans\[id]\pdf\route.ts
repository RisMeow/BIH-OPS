import { NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import puppeteer from 'puppeteer-core';
import { format } from 'date-fns';
import fs from 'fs';
import path from 'path';

export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const session = await getServerSession(authOptions);
        if (!session) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const plan = await prisma.procurementPlan.findUnique({
            where: { id },
            include: {
                items: true,
                createdBy: { select: { fullName: true, email: true } }
            }
        });

        if (!plan) {
            return NextResponse.json({ error: "Plan not found" }, { status: 404 });
        }

        // --- HTML TEMPLATE GENERATION ---
        // Helper to format currency
        const formatMoney = (n: number) => n.toLocaleString('en-US');
        const calculateItemTotal = (item: any) => {
            const base = (item.quantity || 0) * (item.unitPrice || 0);
            const vatAmount = base * ((item.vat || 10) / 100);
            return base + vatAmount;
        };
        const total = plan.items.reduce((acc: number, item: any) => acc + calculateItemTotal(item), 0);

        // Map categories (Logic from frontend)
        const typeMap: Record<string, string> = {
            'ELECTRICAL': 'KTVH', 'PLUMBING': 'KTVH', 'OFFICE': 'VPP', 'MEDICAL': 'VTYT', 'GENERAL': 'KTVH'
        };

        // Prepare Logo Base64
        let logoBase64 = '';
        try {
            const logoPath = path.join(process.cwd(), 'public', 'logo-becamex.png');
            if (fs.existsSync(logoPath)) {
                const logoData = fs.readFileSync(logoPath);
                logoBase64 = `data:image/png;base64,${logoData.toString('base64')}`;
            }
        } catch (e) {
            console.error("Error loading logo:", e);
        }

        const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');
                body {
                    font-family: 'Arial', 'Helvetica', sans-serif;
                    font-size: 13px; /* 10pt approx */
                    color: #000;
                    margin: 0;
                    padding: 20px 40px; /* Reduced padding */
                    box-sizing: border-box;
                    line-height: 1.4;
                }
                .flex { display: flex; align-items: center; }
                .justify-between { justify-content: space-between; }
                .items-end { align-items: flex-end; }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .font-bold { font-weight: bold; }
                .uppercase { text-transform: uppercase; }
                .text-2xl { font-size: 24px; }
                .mb-8 { margin-bottom: 32px; }
                .mb-6 { margin-bottom: 24px; }
                .mb-4 { margin-bottom: 16px; }
                .mb-2 { margin-bottom: 8px; }
                .mb-1 { margin-bottom: 4px; }
                .space-y-12 > * + * { margin-top: 48px; }
                .w-30 { width: 30%; }
                .w-40 { width: 40%; }
                .w-60 { width: 60%; }
                .w-70 { width: 70%; }
                
                table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 12px; }
                th, td { border: 1px solid #cbd5e1; padding: 8px; } /* slate-300 */
                th { background-color: #f1f5f9; text-align: left; } /* slate-100 */
                .text-blue-600 { color: #2563eb; }
                .tracking-wider { letter-spacing: 0.05em; }
                .italic { font-style: italic; }
                .text-slate-500 { color: #64748b; }
            </style>
        </head>
        <body>
            <!-- Header -->
            <div class="flex justify-between mb-8">
                <div class="w-30">
                    ${logoBase64 ? `<img src="${logoBase64}" style="max-height: 80px; max-width: 100%;" alt="Becamex Logo" />` : '<div class="font-bold text-blue-600">BECAMEX</div>'}
                </div>
                <div class="w-40 text-center">
                    <h1 class="text-2xl font-bold uppercase" style="margin: 0;">Dự trù mua hàng</h1>
                </div>
                <div class="w-30 text-right font-bold">
                    Mã: ${plan.code || 'DTMH-' + id}
                </div>
            </div>

            <!-- Meta -->
            <div class="mb-6">
                <div class="flex justify-between mb-2">
                    <div><span class="font-bold">Nội dung dự trù:</span> ${plan.title}</div>
                </div>
                <div class="flex justify-between">
                    <div><span class="font-bold">Người tạo:</span> ${plan.createdBy?.fullName || 'N/A'}</div>
                    <div><span class="font-bold">Ngày tạo:</span> ${format(new Date(plan.createdAt), "dd/MM/yyyy")}</div>
                </div>
            </div>

            <!-- Table -->
            <div>
                <h3 class="font-bold mb-2">Bảng kê chi tiết:</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Hạng mục</th>
                            <th style="width: 25mm">NCC</th>
                            <th class="text-center" style="width: 15mm">ĐVT</th>
                            <th class="text-center" style="width: 20mm">Số lượng</th>
                            <th class="text-right" style="width: 25mm">Đơn giá</th>
                            <th class="text-center" style="width: 15mm">VAT (%)</th>
                            <th class="text-right" style="width: 30mm">Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${plan.items.map((item: any) => `
                        <tr>
                            <td style="white-space: nowrap;">
                                ${item.itemName}
                            </td>
                            <td>
                                <div>${item.supplier || 'An Thịnh'}</div>
                                ${item.bankAccount ? `<div style="font-size: 9px; color: #555; margin-top: 2px;">TK: ${item.bankAccount}</div>` : ''}
                            </td>
                            <td class="text-center">${item.unit}</td>
                            <td class="text-center">${item.quantity}</td>
                            <td class="text-right">${item.unitPrice ? formatMoney(item.unitPrice) : '0'}</td>
                            <td class="text-center">${item.vat || 10}</td>
                            <td class="text-right font-bold">${formatMoney(calculateItemTotal(item))}</td>
                        </tr>
                        `).join('')}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="8" class="text-right font-bold" style="padding-top: 12px; border: none; border-top: 1px solid #cbd5e1;">
                                Tổng cộng: ${formatMoney(total)}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Note -->
            <p class="mb-8"><span class="font-bold">Ghi chú (nếu có):</span> ${plan.description || 'file danh mục sửa chữa'}</p>

            <!-- Signatures -->
            <div style="margin-top: 40px; padding-bottom: 40px; padding-left: 10px; padding-right: 10px;">
                <div class="flex justify-between items-end mb-8" style="margin-bottom: 30px;">
                    <div class="w-60">
                        <div class="mb-1 font-bold">Người lập bảng:</div>
                        <div class="font">${plan.createdBy?.fullName || 'Nguyễn Văn A'}</div>
                    </div>
                    <div class="w-40 text-right italic text-slate-500">Chữ ký: ___________________</div>
                </div>
                <div class="flex justify-between items-end mb-8" style="margin-bottom: 30px;">
                    <div class="w-60">
                        <div class="mb-1 font-bold">Phòng Tài chính Kế toán:</div>
                        <div class="font">Nguyễn Thị Bích Sơn</div>
                    </div>
                    <div class="w-40 text-right italic text-slate-500">Chữ ký: ___________________</div>
                </div>
                <div class="flex justify-between items-end mb-8" style="margin-bottom: 30px;">
                    <div class="w-60">
                        <div class="mb-1 font-bold">Giám đốc Bệnh viện Quốc tế Becamex:</div>
                        <div class="font">Nguyễn Văn Trương</div>
                    </div>
                    <div class="w-40 text-right italic text-slate-500">Chữ ký: ___________________</div>
                </div>
                <div class="flex justify-between items-end">
                    <div class="w-70">
                        <div class="mb-1 font-bold">CT Hội đồng Quản trị Công ty CP Bệnh viện Quốc tế Becamex:</div>
                        <div class="font">Nguyễn Tấn Lợi</div>
                    </div>
                    <div class="w-30 text-right italic text-slate-500">Chữ ký: ___________________</div>
                </div>
            </div>
        </body>
        </html>
        `;

        // Launch Puppeteer
        // In local Docker (Alpine), we typically use the installed chromium
        const browser = await puppeteer.launch({
            executablePath: '/usr/bin/chromium-browser', // Path in Alpine
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage', // Critical for Docker to prevent crashes
                '--disable-accel-2d-canvas',
                '--disable-gpu',
                '--hide-scrollbars'
            ]
        });

        const page = await browser.newPage();
        await page.setContent(htmlContent, { waitUntil: 'networkidle0' }); // Wait for images

        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: { top: '10mm', right: '10mm', bottom: '10mm', left: '10mm' }
        });

        await browser.close();

        return new NextResponse(pdfBuffer as any, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="DTMH-${plan.code || id}.pdf"`
            }
        });

    } catch (error: any) {
        console.error("PDF Export Error:", error);
        return NextResponse.json({ error: error.message || "Failed to generate PDF" }, { status: 500 });
    }
}

-- Add new columns to SecurityReport
ALTER TABLE "SecurityReport" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP DEFAULT NOW();
ALTER TABLE "SecurityReport" ADD COLUMN IF NOT EXISTS "reportedById" INTEGER;
ALTER TABLE "SecurityReport" ADD COLUMN IF NOT EXISTS "reportedBy" VARCHAR(255);

-- Create PatrolLog table
CREATE TABLE IF NOT EXISTS "PatrolLog" (
    id SERIAL PRIMARY KEY,
    checkpoint VARCHAR(255) NOT NULL,
    "checkpointCode" VARCHAR(100),
    status VARCHAR(50) DEFAULT 'NORMAL',
    note TEXT,
    "imageUrl" TEXT,
    "guardId" INTEGER NOT NULL,
    "guardName" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP DEFAULT NOW()
);

-- Create Visitor table
CREATE TABLE IF NOT EXISTS "Visitor" (
    id SERIAL PRIMARY KEY,
    "fullName" VARCHAR(255) NOT NULL,
    "idNumber" VARCHAR(50),
    company VARCHAR(255),
    phone VARCHAR(50),
    purpose VARCHAR(50) NOT NULL,
    "hostDepartment" VARCHAR(255),
    "hostPerson" VARCHAR(255),
    "vehicleType" VARCHAR(50),
    "vehiclePlate" VARCHAR(50),
    "checkInTime" TIMESTAMP DEFAULT NOW(),
    "checkOutTime" TIMESTAMP,
    "tempCardNumber" VARCHAR(50),
    status VARCHAR(50) DEFAULT 'CHECKED_IN',
    "createdById" INTEGER,
    "createdByName" VARCHAR(255)
);

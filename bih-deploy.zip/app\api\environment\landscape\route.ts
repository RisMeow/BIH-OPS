import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(req: Request) {
    try {
        const tasks = await prisma.landscapeTask.findMany({
            include: { assignedTo: { select: { fullName: true } } },
            orderBy: { scheduledDate: 'asc' }
        });
        return NextResponse.json(tasks);
    } catch (error) {
        console.error("Error fetching landscape tasks:", error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}

export async function POST(req: Request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

        const body = await req.json();
        const { taskType, area, scheduledDate, assignedToId, notes } = body;

        const task = await prisma.landscapeTask.create({
            data: {
                taskType,
                area,
                scheduledDate: new Date(scheduledDate),
                assignedToId: assignedToId ? parseInt(String(assignedToId)) : undefined,
                notes
            }
        });
        return NextResponse.json(task);
    } catch (error) {
        console.error("Error creating landscape task:", error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}

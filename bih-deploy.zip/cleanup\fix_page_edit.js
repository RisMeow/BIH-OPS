
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // 1. Add bankAccount to ProcurementItem interface
    // interface ProcurementItem { ... vat?: number; note?: string; }
    // We regex replace to add bankAccount?: string;
    if (!content.includes('bankAccount?: string;')) {
        content = content.replace('vat?: number;', 'vat?: number;\n    bankAccount?: string;');
        console.log("Interface updated.");
    }

    // 2. Add bankAccount input to Creating Plan Form (Item Row)
    // We target the row we modified earlier.
    const rowRegex = /<input type="number" className="w-20 p-2 border rounded-lg text-sm font-bold text-slate-700" placeholder="VAT%" title="VAT %" value=\{item\.vat\} onChange=\{e => handleItemChange\(idx, 'vat', parseFloat\(e\.target\.value\)\)\} \/>\s*<\/div>/;

    const newRow = `<input type="number" className="w-20 p-2 border rounded-lg text-sm font-bold text-slate-700" placeholder="VAT%" title="VAT %" value={item.vat} onChange={e => handleItemChange(idx, 'vat', parseFloat(e.target.value))} />
                                                    </div>
                                                    <div className="mt-2">
                                                        <input className="w-full p-2 border rounded-lg text-sm" placeholder="Thông tin chuyển khoản (Số TK - Ngân hàng - Chi nhánh)" value={item.bankAccount || ''} onChange={e => handleItemChange(idx, 'bankAccount', e.target.value)} />
                                                    </div>`;

    if (rowRegex.test(content)) {
        content = content.replace(rowRegex, newRow);
        console.log("Item bank input added.");
    } else {
        console.log("Could not find row to append bank input.");
    }

    // 3. Update 'handleRevertPlan' to be 'handleAdjustPlan' (Edit Flow)
    // "Điều chỉnh" means Adjust. Users want to edit.
    // Flow:
    // a. Click "Điều chỉnh" -> Confirm -> Update status to PENDING -> Open Modal with Data.
    // b. Or just Open Modal with Data -> On Save, it updates status PENDING automatically?
    // User said: "Action Button "Dieu chinh" khong phai chi reverse flow ma con cho phep supply staff thuc hien dieu chinh lai cac field da nhap truoc do."
    // So distinct step: reverse flow AND allow edit.

    // I will modify `handleRevertPlan` (if it exists from previous script) or `handleAdjustPlan`.
    // My previous script injected `handleRevertPlan`. I will rename/rework it.

    // I'll define `handleEditPlan` which opens the modal and sets `planFormData`.
    // And `handleAdjustPlan` which calls API to set PENDING, THEN calls `handleEditPlan`.

    const editFunc = `
    const handleEditPlan = (plan: ProcurementPlan) => {
        setPlanFormData({
             title: plan.title, 
             description: plan.description || "", 
             supplierBank: plan.supplierBank || "" 
        });
        setPlanItems(plan.items.map(i => ({
            ...i,
            bankAccount: i.bankAccount || ""
        })));
        // We need to know we are editing this specific plan ID when saving
        // Reuse 'selectedPlan' or a new state?
        // 'handlePlanSubmit' currently does POST create.
        // I need 'editingPlanId' state.
        setEditingPlanId(plan.id);
        setIsCreatePlanModalOpen(true);
    };

    const handleAdjustPlan = (id: number) => {
        openConfirm("Điều chỉnh phiếu", "Phiếu sẽ chuyển về trạng thái CHỜ DUYỆT để bạn chỉnh sửa. Tiếp tục?", async () => {
            try {
                // 1. Revert Status
                const res = await fetch(\`/api/supply/plans/\${id}\`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: 'PENDING' }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    showToast("Đã mở khóa phiếu để chỉnh sửa!", 'success');
                    fetchPlans();
                    // 2. Open Edit Modal
                    // We need to find the plan object. 
                    // If we are in detail view, 'selectedPlan' is it.
                    // If 'selectedPlan' is stale (status still approved), we might need updated one.
                    // But for editing fields, the stale one is fine as fields haven't changed yet.
                    if (selectedPlan && selectedPlan.id === id) {
                         handleEditPlan(selectedPlan);
                         setSelectedPlan(null); // Close detail modal
                    } else {
                        // If triggered from table (not implemented yet but possible)
                        const p = plans.find(p => p.id === id);
                        if (p) handleEditPlan(p);
                    }
                } else {
                     const data = await res.json();
                     showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); }
        }, 'info');
    };
    `;

    // Inject `const [editingPlanId, setEditingPlanId] = useState<number | null>(null);`
    if (!content.includes('editingPlanId')) {
        content = content.replace('const [isCreatePlanModalOpen, setIsCreatePlanModalOpen] = useState(false);',
            'const [isCreatePlanModalOpen, setIsCreatePlanModalOpen] = useState(false);\n    const [editingPlanId, setEditingPlanId] = useState<number | null>(null);');
    }

    // Inject the functions
    // Replace the previous `handleRevertPlan` if it exists, or just append before `return`.
    if (content.includes('const handleRevertPlan')) {
        // Remove old function crudely or just overwrite
        // It's safer to just regex replace the definition or append new ones and update the button to use new one.
        // I'll append `handleEditPlan` and `handleAdjustPlan`
        content = content.replace('return (', editFunc + '\n    return (');
    } else {
        content = content.replace('return (', editFunc + '\n    return (');
    }

    // 4. Update `handlePlanSubmit` to handle Edit (PUT/PATCH)
    /*
    const handlePlanSubmit = async () => {
        try {
            if (!planFormData.title.trim()) ...
            
            const payload = { ... };

            let res;
            if (editingPlanId) {
                 res = await fetch(`/api/supply/plans/${editingPlanId}`, { 
                     method: 'PATCH', 
                     body: JSON.stringify({ ...payload, items: planItems }), // Ensure items are included
                     headers: { 'Content-Type': 'application/json' } 
                 });
            } else {
                 res = await fetch('/api/supply/plans', { ...POST... });
            }
            ...
    */

    // I need to parse the existing `handlePlanSubmit` and inject the logic.
    // It's easier to replace the fetch call.
    const fetchPostRegex = /const res = await fetch\('\/api\/supply\/plans', \{ method: 'POST', body: JSON\.stringify\(payload\), headers: \{ 'Content-Type': 'application\/json' \} \}\);/;

    const newFetchLogic = `let res;
            if (editingPlanId) {
                // For edit, we send Payload + Items. The API PATCH handles items update if status is PENDING.
                // We ensure status is preserved or strictly validated backend.
                res = await fetch(\`/api/supply/plans/\${editingPlanId}\`, { 
                    method: 'PATCH', 
                    body: JSON.stringify({ ...payload, items: planItems }), 
                    headers: { 'Content-Type': 'application/json' } 
                });
            } else {
                res = await fetch('/api/supply/plans', { method: 'POST', body: JSON.stringify(payload), headers: { 'Content-Type': 'application/json' } });
            }`;

    if (fetchPostRegex.test(content)) {
        content = content.replace(fetchPostRegex, newFetchLogic);
        console.log("Submit logic updated for Editing.");
    }

    // Also reset `editingPlanId` when closing modal
    // <button onClick={() => setIsCreatePlanModalOpen(false)} ...
    // Needs to be: () => { setIsCreatePlanModalOpen(false); setEditingPlanId(null); setPlanFormData(...); setPlanItems(...); }
    // There are multiple close buttons (header X and Cancel button).
    // I'll replace the setters globally? Use regex.
    const closeBtnRegex = /setIsCreatePlanModalOpen\(false\)/g;
    content = content.replace(closeBtnRegex, 'setIsCreatePlanModalOpen(false); setEditingPlanId(null); setPlanFormData({ title: "", description: "", supplierBank: "" }); setPlanItems([{ itemName: "", category: "OFFICE", quantity: 1, unit: "PCS", supplier: "", unitPrice: 0, vat: 10, note: "" }]);');

    // 5. Update the "Điều chỉnh" button to call `handleAdjustPlan`
    // It was calling `handleRevertPlan`.
    const revertBtnRegex = /onClick=\{\(\) => handleRevertPlan\(selectedPlan\.id\)\}/;
    if (revertBtnRegex.test(content)) {
        content = content.replace(revertBtnRegex, 'onClick={() => handleAdjustPlan(selectedPlan.id)}');
        console.log("Button handler updated.");
    }

    // 6. Update Modal Title
    // <h3 className="font-bold text-xl text-slate-800">Lập dự trù mới</h3>
    content = content.replace('Lập dự trù mới', '{editingPlanId ? "Chỉnh sửa phiếu dự trù" : "Lập dự trù mới"}');

    fs.writeFileSync(path, content);
    console.log("Edit Plan feature fully implemented.");

} catch (e) {
    console.error("Error:", e);
}

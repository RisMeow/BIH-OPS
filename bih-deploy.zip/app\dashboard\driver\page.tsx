"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
    Car, CalendarCheck, MapPin, Clock, Users, Compass, Plus, X, Loader2,
    Filter, Truck, AlertTriangle, CheckCircle, Play, Fuel, Gauge, Settings,
    Calendar, Shield, Wrench, BarChart3, Edit, Trash2
} from "lucide-react";
import { clsx } from "clsx";
import DateInput from "@/app/components/DateInput";

// Types
interface TransportRequest {
    id: number;
    passengerName: string;
    department: string;
    destination: string;
    pickupLocation?: string;
    pickupTime: string;
    returnTime?: string;
    passengerCount: number;
    tripType: string;
    purpose?: string;
    note?: string;
    status: string;
    startKm?: number;
    endKm?: number;
    fuelUsed?: number;
    vehicle?: { id: number; licensePlate: string };
    assignedTo?: { id: number; fullName: string };
    createdAt: string;
    isArchived: boolean;
}

interface Vehicle {
    id: number;
    licensePlate: string;
    vehicleType: string;
    brand?: string;
    model?: string;
    color?: string;
    seats: number;
    status: string;
    currentKm?: number;
    registrationExpiry?: string;
    insuranceExpiry?: string;
    lastMaintenance?: string;
    _count?: { trips: number };
}

interface FuelLog {
    id: number;
    vehicle: { licensePlate: string; brand: string; model: string };
    filledAt: string;
    liters: number;
    pricePerLiter: number;
    totalCost: number;
    odoReading: number;
    filledBy: { fullName: string };
    notes: string;
}

export default function DriverDashboard() {
    const { data: session } = useSession();
    const [activeTab, setActiveTab] = useState<'TRIPS' | 'VEHICLES' | 'STATS' | 'FUEL' | 'HISTORY'>('TRIPS');

    const [requests, setRequests] = useState<TransportRequest[]>([]);
    const [vehicles, setVehicles] = useState<Vehicle[]>([]);
    const [fuelLogs, setFuelLogs] = useState<FuelLog[]>([]);
    const [loading, setLoading] = useState(true);

    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

    const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
    // Removed duplicate state variables here since they are defined below
    const [isFuelModalOpen, setIsFuelModalOpen] = useState(false);
    const [isEmergencyMode, setIsEmergencyMode] = useState(false);

    // Approval Modal State
    const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState<TransportRequest | null>(null);
    const [selectedVehicleId, setSelectedVehicleId] = useState<string>("");

    // Custom Confirm Modal State
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean;
        title: string;
        content: string;
        action: () => Promise<void> | void;
        isDanger?: boolean;
    }>({ isOpen: false, title: "", content: "", action: () => { }, isDanger: false });

    // Toast State
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | null; isVisible: boolean }>({
        message: "", type: null, isVisible: false
    });

    const showToast = (message: string, type: 'success' | 'error') => {
        setToast({ message, type, isVisible: true });
        setTimeout(() => setToast(prev => ({ ...prev, isVisible: false })), 3000);
    };


    const [formData, setFormData] = useState({
        passengerName: "", department: "", destination: "", pickupLocation: "",
        pickupTime: "", passengerCount: 1, tripType: "ONE_WAY", purpose: "", note: ""
    });
    const [vehicleForm, setVehicleForm] = useState({
        licensePlate: "", vehicleType: "CAR", brand: "", model: "", color: "", seats: 4, currentKm: 0,
        registrationExpiry: "", insuranceExpiry: "", lastMaintenance: ""
    });
    const [editingVehicleId, setEditingVehicleId] = useState<number | null>(null);
    const [fuelForm, setFuelForm] = useState({
        vehicleId: "", liters: "", pricePerLiter: "", odoReading: "", notes: ""
    });
    const [editingFuelLogId, setEditingFuelLogId] = useState<number | null>(null);
    const [submitting, setSubmitting] = useState(false);
    const [statusFilter, setStatusFilter] = useState<string>('ALL');

    // === FETCH DATA ===
    const fetchRequests = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/driver/requests');
            const data = await res.json();
            if (Array.isArray(data)) setRequests(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const fetchVehicles = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/driver/vehicles');
            const data = await res.json();
            if (Array.isArray(data)) setVehicles(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const fetchFuelLogs = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/driver/fuel');
            const data = await res.json();
            if (Array.isArray(data)) setFuelLogs(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    useEffect(() => {
        if (activeTab === 'TRIPS' || activeTab === 'HISTORY') fetchRequests();
        else if (activeTab === 'VEHICLES') fetchVehicles();
        else if (activeTab === 'FUEL') { fetchFuelLogs(); fetchVehicles(); } // Need vehicles for select
    }, [activeTab]);

    // === HANDLERS ===
    const handleCreateSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await fetch('/api/driver/requests', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...formData,
                    tripType: isEmergencyMode ? 'EMERGENCY' : formData.tripType,
                    requestedBy: session?.user?.name
                })
            });
            setIsCreateModalOpen(false);
            setFormData({ passengerName: "", department: "", destination: "", pickupLocation: "", pickupTime: "", passengerCount: 1, tripType: "ONE_WAY", purpose: "", note: "" });
            setIsEmergencyMode(false);
            fetchRequests();
        } catch (e) { console.error(e); }
        finally { setSubmitting(false); }
    };

    const handleCreateVehicle = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const url = editingVehicleId ? `/api/driver/vehicles/${editingVehicleId}` : '/api/driver/vehicles';
            const method = editingVehicleId ? 'PATCH' : 'POST';

            const res = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(vehicleForm)
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "Lỗi không xác định");

            setIsVehicleModalOpen(false);
            setVehicleForm({
                licensePlate: "", vehicleType: "CAR", brand: "", model: "", color: "", seats: 4, currentKm: 0,
                registrationExpiry: "", insuranceExpiry: "", lastMaintenance: ""
            });
            setEditingVehicleId(null);
            fetchVehicles();
            showToast(editingVehicleId ? "Đã cập nhật xe thành công!" : "Đã thêm xe mới thành công!", "success");
        } catch (e: any) {
            console.error(e);
            showToast(`Lỗi: ${e.message}`, "error");
        }
        finally { setSubmitting(false); }
    };

    // Remove separate handleEditVehicle as it is merged into handleCreateVehicle

    const handleDeleteVehicle = async (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Xóa Xe",
            content: "Bạn có chắc chắn muốn xóa xe này không? Hành động này không thể hoàn tác.",
            isDanger: true,
            action: async () => {
                try {
                    const res = await fetch(`/api/driver/vehicles/${id}`, { method: 'DELETE' });
                    if (!res.ok) {
                        const err = await res.json();
                        throw new Error(err.error || "Lỗi xóa");
                    }
                    showToast("Đã xóa xe thành công!", "success");
                    fetchVehicles();
                    setConfirmModal(prev => ({ ...prev, isOpen: false }));
                } catch (e: any) {
                    showToast(`Không thể xóa: ${e.message}`, "error");
                }
            }
        });
    };

    const openEditVehicle = (v: any) => {
        setVehicleForm({
            licensePlate: v.licensePlate,
            vehicleType: v.vehicleType,
            brand: v.brand || "",
            model: v.model || "",
            color: v.color || "",
            seats: v.seats,
            currentKm: v.currentKm || 0,
            registrationExpiry: v.registrationExpiry ? new Date(v.registrationExpiry).toISOString().split('T')[0] : "",
            insuranceExpiry: v.insuranceExpiry ? new Date(v.insuranceExpiry).toISOString().split('T')[0] : "",
            lastMaintenance: v.lastMaintenance ? new Date(v.lastMaintenance).toISOString().split('T')[0] : ""
        });
        setEditingVehicleId(v.id);
        setIsVehicleModalOpen(true);
    };

    const handleDeleteHistory = (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Xóa Lịch sử Vĩnh viễn",
            content: "Bạn có chắc chắn muốn xóa vĩnh viễn lịch sử này? Hành động này không thể hoàn tác.",
            isDanger: true,
            action: async () => {
                try {
                    await fetch(`/api/driver/requests/${id}`, { method: 'DELETE' });
                    fetchRequests();
                    setConfirmModal(prev => ({ ...prev, isOpen: false }));
                } catch (e) { console.error(e); }
            }
        });
    };

    const handleArchiveRequest = (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Lưu trữ Phiếu",
            content: "Bạn muốn xóa phiếu này khỏi danh sách đang xử lý? Nó sẽ được chuyển vào Lịch sử.",
            isDanger: false,
            action: async () => {
                try {
                    const res = await fetch(`/api/driver/requests/${id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ isArchived: true })
                    });
                    if (!res.ok) {
                        const err = await res.json();
                        throw new Error(err.error || "Lỗi không xác định");
                    }
                    fetchRequests();
                    setConfirmModal(prev => ({ ...prev, isOpen: false }));
                    showToast("Đã lưu trữ thành công!", "success");
                } catch (e: any) {
                    console.error(e);
                    showToast(`Không thể lưu trữ phiếu: ${e.message}`, "error");
                }
            }
        });
    };

    const handleCreateFuelLog = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const url = editingFuelLogId ? `/api/driver/fuel/${editingFuelLogId}` : '/api/driver/fuel';
            const method = editingFuelLogId ? 'PATCH' : 'POST';

            const res = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(fuelForm)
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "Lỗi không xác định");

            setIsFuelModalOpen(false);
            setFuelForm({ vehicleId: "", liters: "", pricePerLiter: "", odoReading: "", notes: "" });
            setEditingFuelLogId(null); // Reset edit mode
            fetchFuelLogs();
            showToast(editingFuelLogId ? "Đã cập nhật nhật ký thành công!" : "Đã tạo nhật ký thành công!", "success");
        } catch (e: any) {
            console.error(e);
            showToast(`Lỗi: ${e.message}`, "error");
        }
        finally { setSubmitting(false); }
    };

    const handleDeleteFuelLog = async (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Xóa Nhật ký",
            content: "Bạn có chắc chắn muốn xóa nhật ký nhiên liệu này không? Hành động này không thể hoàn tác.",
            isDanger: true,
            action: async () => {
                try {
                    const res = await fetch(`/api/driver/fuel/${id}`, { method: 'DELETE' });
                    if (!res.ok) {
                        const err = await res.json();
                        throw new Error(err.error || "Lỗi xóa");
                    }
                    showToast("Đã xóa nhật ký thành công!", "success");
                    fetchFuelLogs();
                    setConfirmModal(prev => ({ ...prev, isOpen: false }));
                } catch (e: any) {
                    showToast(`Không thể xóa: ${e.message}`, "error");
                }
            }
        });
    };

    const openEditFuelLog = (log: any) => {
        setFuelForm({
            vehicleId: log.vehicleId.toString(),
            liters: log.liters.toString(),
            pricePerLiter: log.pricePerLiter.toString(),
            odoReading: log.odoReading.toString(),
            notes: log.notes || ""
        });
        setEditingFuelLogId(log.id);
        setIsFuelModalOpen(true);
    };

    const handleUpdateStatus = async (id: number, status: string) => {
        try {
            await fetch(`/api/driver/requests/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });
            fetchRequests();
        } catch (e) { console.error(e); }
    };



    const handleOpenApprove = (req: TransportRequest) => {
        setSelectedRequest(req);
        setSelectedVehicleId("");
        setIsApproveModalOpen(true);
    };

    const handleApproveSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        if (!selectedRequest) return;

        try {
            await fetch(`/api/driver/requests/${selectedRequest.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    status: 'APPROVED',
                    vehicleId: selectedVehicleId ? parseInt(selectedVehicleId) : null,
                    assignedToId: session?.user?.id
                }) // Assign to self (manager) or keep null? Usually manager approves, driver picks up? 
                // The prompt says "Manager choose vehicle -> Approve -> Notify Driver".
                // Ideally we assign a specific driver too, but for now let's stick to vehicle first.
                // If we want to assign a driver, we need a driver list.
                // For now, let's assume the Manager who approves IS controlling the flow.
            });
            setIsApproveModalOpen(false);
            fetchRequests();
        } catch (e) { console.error(e); }
        finally { setSubmitting(false); }
    };

    // === HELPERS ===
    const getStatusConfig = (status: string) => {
        switch (status) {
            case "PENDING": return { label: "Chờ duyệt", color: "text-amber-600", bg: "bg-amber-50", icon: Clock };
            case "APPROVED": return { label: "Đã duyệt", color: "text-blue-600", bg: "bg-blue-50", icon: CheckCircle };
            case "IN_PROGRESS": return { label: "Đang đi", color: "text-purple-600", bg: "bg-purple-50", icon: Play };
            case "COMPLETED": return { label: "Hoàn thành", color: "text-green-600", bg: "bg-green-50", icon: CheckCircle };
            case "CANCELLED": return { label: "Đã hủy", color: "text-red-600", bg: "bg-red-50", icon: X };
            default: return { label: "Khác", color: "text-slate-500", bg: "bg-slate-50", icon: Clock };
        }
    };

    const getTripTypeLabel = (type: string) => {
        switch (type) {
            case 'ONE_WAY': return { label: 'Một chiều', color: 'text-slate-600' };
            case 'ROUND_TRIP': return { label: 'Khứ hồi', color: 'text-blue-600' };
            case 'EMERGENCY': return { label: 'CẤP CỨU', color: 'text-red-600' };
            default: return { label: type, color: 'text-slate-600' };
        }
    };

    const getVehicleTypeIcon = (type: string) => {
        switch (type) {
            case 'AMBULANCE': return AlertTriangle;
            case 'VAN': return Truck;
            default: return Car;
        }
    };

    // Stats
    const pendingTrips = requests.filter(r => r.status === 'PENDING').length;
    const inProgressTrips = requests.filter(r => r.status === 'IN_PROGRESS').length;
    const todayTrips = requests.filter(r =>
        new Date(r.pickupTime).toDateString() === new Date().toDateString()
    ).length;
    const availableVehicles = vehicles.filter(v => v.status === 'AVAILABLE').length;

    const filteredRequests = statusFilter === 'ALL'
        ? requests.filter(r => !r.isArchived)
        : requests.filter(r => r.status === statusFilter && !r.isArchived);

    // History data: Archived OR Completed/Cancelled
    const historyRequests = requests.filter(r => r.isArchived || ['COMPLETED', 'CANCELLED'].includes(r.status));

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                            <Car size={22} />
                        </div>
                        Điều phối Đội xe
                    </h2>
                    <p className="text-slate-500 mt-1">Quản lý lịch trình điều xe và phương tiện.</p>
                </div>

                {/* Stats Cards */}
                <div className="flex gap-3">
                    <div className="bg-amber-50 border border-amber-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-amber-600">{pendingTrips}</div>
                        <div className="text-[10px] font-bold text-amber-500 uppercase">Chờ duyệt</div>
                    </div>
                    <div className="bg-purple-50 border border-purple-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-purple-600">{inProgressTrips}</div>
                        <div className="text-[10px] font-bold text-purple-500 uppercase">Đang đi</div>
                    </div>
                    <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-blue-600">{todayTrips}</div>
                        <div className="text-[10px] font-bold text-blue-500 uppercase">Hôm nay</div>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-emerald-600">{availableVehicles}</div>
                        <div className="text-[10px] font-bold text-emerald-500 uppercase">Xe sẵn</div>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 border-b border-slate-200">
                <button
                    onClick={() => setActiveTab('TRIPS')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'TRIPS' ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <CalendarCheck size={18} /> Lịch điều xe
                </button>
                <button
                    onClick={() => setActiveTab('VEHICLES')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'VEHICLES' ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Car size={18} /> Danh sách xe
                </button>
                <button
                    onClick={() => setActiveTab('STATS')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'STATS' ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <BarChart3 size={18} /> Thống kê
                </button>
                <button
                    onClick={() => setActiveTab('FUEL')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'FUEL' ? "border-amber-600 text-amber-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Fuel size={18} /> Nhiên liệu
                </button>
                <button
                    onClick={() => setActiveTab('HISTORY')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'HISTORY' ? "border-slate-800 text-slate-800" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Clock size={18} /> Lịch sử
                </button>
            </div>

            {/* === TAB: TRIPS === */}
            {
                activeTab === 'TRIPS' && (
                    <div>
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex gap-2">
                                {['ALL', 'PENDING', 'APPROVED', 'IN_PROGRESS', 'COMPLETED'].map(s => (
                                    <button key={s}
                                        onClick={() => setStatusFilter(s)}
                                        className={clsx(
                                            "px-3 py-1.5 rounded-lg text-xs font-bold transition-colors",
                                            statusFilter === s ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                                        )}
                                    >
                                        {s === 'ALL' ? 'Tất cả' : getStatusConfig(s).label}
                                    </button>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => { setIsEmergencyMode(true); setIsCreateModalOpen(true); }}
                                    className="px-4 py-2 bg-red-600 text-white font-bold rounded-xl shadow-lg shadow-red-500/30 hover:bg-red-700 flex items-center gap-2"
                                >
                                    <AlertTriangle size={18} /> Cấp cứu
                                </button>
                                <button
                                    onClick={() => { setIsEmergencyMode(false); setIsCreateModalOpen(true); }}
                                    className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:bg-blue-700 flex items-center gap-2"
                                >
                                    <Plus size={18} /> Đặt xe
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {loading ? (
                                <div className="col-span-full flex justify-center py-20"><Loader2 className="animate-spin text-blue-500" /></div>
                            ) : filteredRequests.length === 0 ? (
                                <div className="col-span-full text-center py-20 bg-white rounded-2xl border border-dashed border-slate-200">
                                    <Car className="mx-auto text-slate-300 mb-4" size={48} />
                                    <p className="text-slate-500 font-medium">Chưa có chuyến đi nào.</p>
                                </div>
                            ) : (
                                <AnimatePresence>
                                    {filteredRequests.map((req) => {
                                        const status = getStatusConfig(req.status);
                                        const tripType = getTripTypeLabel(req.tripType);
                                        const StatusIcon = status.icon;
                                        return (
                                            <motion.div
                                                key={req.id}
                                                initial={{ opacity: 0, scale: 0.95 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                className={clsx(
                                                    "bg-white p-5 rounded-2xl border shadow-sm hover:shadow-md transition-all relative",
                                                    req.tripType === 'EMERGENCY' ? "border-red-200 bg-red-50/30" : "border-slate-100"
                                                )}
                                            >
                                                {req.tripType === 'EMERGENCY' && (
                                                    <div className="absolute top-0 right-0 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded-bl-lg rounded-tr-xl">
                                                        CẤP CỨU
                                                    </div>
                                                )}

                                                <div className="flex justify-between items-start mb-4">
                                                    <div className="flex items-center gap-3">
                                                        <div className={clsx("w-10 h-10 rounded-full flex items-center justify-center", status.bg)}>
                                                            <Car size={20} className={status.color} />
                                                        </div>
                                                        <div>
                                                            <h4 className="font-bold text-slate-800">{req.passengerName}</h4>
                                                            <p className="text-xs text-slate-500">{req.department}</p>
                                                        </div>
                                                    </div>
                                                    <span className={clsx("px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1", status.bg, status.color)}>
                                                        <StatusIcon size={12} /> {status.label}
                                                    </span>
                                                </div>

                                                <div className="space-y-2 text-sm">
                                                    <div className="flex items-center gap-2 text-slate-600">
                                                        <MapPin size={14} className="text-slate-400" />
                                                        <span className="font-medium">{req.destination}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2 text-slate-600">
                                                        <Clock size={14} className="text-slate-400" />
                                                        <span>{new Date(req.pickupTime).toLocaleString('en-GB')}</span>
                                                    </div>
                                                    <div className="flex items-center gap-4 pt-2 border-t border-slate-50">
                                                        <span className="flex items-center gap-1 text-slate-500">
                                                            <Users size={14} /> {req.passengerCount}
                                                        </span>
                                                        <span className={clsx("flex items-center gap-1 font-bold", tripType.color)}>
                                                            <Compass size={14} /> {tripType.label}
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Actions */}
                                                {(session?.user as any)?.role === 'DRIVER' || (session?.user as any)?.role === 'ADMIN' ? (
                                                    <div className="mt-4 pt-3 border-t border-slate-100 flex gap-2">
                                                        {req.status === 'PENDING' && (
                                                            <button onClick={() => handleOpenApprove(req)} className="flex-1 py-2 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700">
                                                                Duyệt & Điều xe
                                                            </button>
                                                        )}
                                                        {req.status === 'APPROVED' && (
                                                            <button onClick={() => handleUpdateStatus(req.id, 'IN_PROGRESS')} className="flex-1 py-2 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700">
                                                                Bắt đầu
                                                            </button>
                                                        )}
                                                        {req.status === 'IN_PROGRESS' && (
                                                            <button onClick={() => handleUpdateStatus(req.id, 'COMPLETED')} className="flex-1 py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700">
                                                                Hoàn thành
                                                            </button>
                                                        )}
                                                        {req.status === 'PENDING' && (
                                                            <button onClick={() => handleUpdateStatus(req.id, 'CANCELLED')} className="px-3 py-2 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-200">
                                                                Hủy
                                                            </button>
                                                        )}

                                                        {req.status === 'COMPLETED' && ((session?.user as any)?.role === 'ADMIN' || (session?.user as any)?.role === 'DRIVER') && (
                                                            <button onClick={() => handleArchiveRequest(req.id)} className="flex-1 py-2 bg-slate-100 text-slate-500 text-xs font-bold rounded-lg hover:bg-slate-200">
                                                                Xóa (Lưu trữ)
                                                            </button>
                                                        )}
                                                    </div>
                                                ) : null}
                                            </motion.div>
                                        );
                                    })}
                                </AnimatePresence>
                            )}
                        </div>
                    </div>
                )
            }

            {/* === TAB: HISTORY === */}
            {
                activeTab === 'HISTORY' && (
                    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                                    <tr>
                                        <th className="p-4">Ngày tạo</th>
                                        <th className="p-4">Người đi</th>
                                        <th className="p-4">Điểm đến</th>
                                        <th className="p-4">Thời gian đón</th>
                                        <th className="p-4">Trạng thái</th>
                                        <th className="p-4 text-right">Hành động</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {historyRequests.map((req) => {
                                        const status = getStatusConfig(req.status);
                                        return (
                                            <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                                                <td className="p-4 text-slate-500">{new Date(req.createdAt).toLocaleDateString('en-GB')}</td>
                                                <td className="p-4 font-medium text-slate-800">
                                                    {req.passengerName}
                                                    <div className="text-xs text-slate-500 font-normal">{req.department}</div>
                                                </td>
                                                <td className="p-4 text-slate-700">{req.destination}</td>
                                                <td className="p-4 text-slate-600">
                                                    {new Date(req.pickupTime).toLocaleString('en-GB')}
                                                </td>
                                                <td className="p-4">
                                                    <span className={clsx("px-2 py-1 rounded-lg text-xs font-bold", status.bg, status.color)}>
                                                        {status.label}
                                                    </span>
                                                    {req.isArchived && <span className="ml-2 text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded border border-slate-200">Lưu trữ</span>}
                                                </td>
                                                <td className="p-4 text-right">
                                                    {(session?.user as any)?.role === 'ADMIN' && (
                                                        <button onClick={() => handleDeleteHistory(req.id)} className="text-red-500 hover:text-red-700 font-bold text-xs">
                                                            Xóa vĩnh viễn
                                                        </button>
                                                    )}
                                                </td>
                                            </tr>
                                        )
                                    })}
                                </tbody>
                            </table>
                            {historyRequests.length === 0 && (
                                <div className="p-10 text-center text-slate-400">
                                    <Clock className="mx-auto mb-2 opacity-50" size={32} />
                                    Chưa có lịch sử
                                </div>
                            )}
                        </div>
                    </div>
                )
            }



            {/* === TAB: FUEL === */}
            {
                activeTab === 'FUEL' && (
                    <div>
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex gap-4">
                                <div className="bg-white px-4 py-2 rounded-xl border border-slate-100 flex items-center gap-3 shadow-sm">
                                    <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center"><Fuel size={16} /></div>
                                    <div>
                                        <p className="text-[10px] text-slate-500 font-bold uppercase">Tổng chi phí</p>
                                        <p className="text-lg font-black text-slate-800">
                                            {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(fuelLogs.reduce((acc, log) => acc + log.totalCost, 0))}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <button
                                onClick={() => {
                                    setFuelForm({ vehicleId: "", liters: "", pricePerLiter: "", odoReading: "", notes: "" });
                                    setEditingFuelLogId(null);
                                    setIsFuelModalOpen(true);
                                }}
                                className="px-4 py-2 bg-amber-600 text-white font-bold rounded-xl shadow-lg shadow-amber-500/30 hover:bg-amber-700 flex items-center gap-2"
                            >
                                <Plus size={18} /> Đổ xăng
                            </button>
                        </div>

                        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                                        <tr>
                                            <th className="p-4">Thời gian</th>
                                            <th className="p-4">Xe</th>
                                            <th className="p-4 text-right">Số lượng</th>
                                            <th className="p-4 text-right">Đơn giá</th>
                                            <th className="p-4 text-right">Thành tiền</th>
                                            <th className="p-4 text-right">ODO (km)</th>
                                            <th className="p-4">Người đổ</th>
                                            <th className="p-4">Ghi chú</th>
                                            <th className="p-4 text-right">Hành động</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                        {fuelLogs.map((log) => (
                                            <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                                                <td className="p-4 text-slate-500">
                                                    {new Date(log.filledAt).toLocaleDateString('en-GB')} <span className="text-xs">{new Date(log.filledAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
                                                </td>
                                                <td className="p-4">
                                                    <div className="font-bold text-slate-800">{log.vehicle.licensePlate}</div>
                                                    <div className="text-xs text-slate-500">{log.vehicle.brand} {log.vehicle.model}</div>
                                                </td>
                                                <td className="p-4 text-right font-medium">{log.liters.toLocaleString('vi-VN')} L</td>
                                                <td className="p-4 text-right text-slate-500">{log.pricePerLiter.toLocaleString('vi-VN')} ₫</td>
                                                <td className="p-4 text-right font-bold text-amber-600">{log.totalCost.toLocaleString('vi-VN')} ₫</td>
                                                <td className="p-4 text-right font-mono text-slate-600">{log.odoReading.toLocaleString('vi-VN')}</td>
                                                <td className="p-4 text-slate-600">{log.filledBy?.fullName || '-'}</td>
                                                <td className="p-4 text-slate-500 italic max-w-xs truncate">{log.notes}</td>
                                                <td className="p-4 text-right flex gap-2 justify-end">
                                                    <button onClick={() => openEditFuelLog(log)} className="text-blue-600 hover:text-blue-800 font-bold text-xs p-2 bg-blue-50 rounded-lg">
                                                        <Edit size={14} />
                                                    </button>
                                                    <button onClick={() => handleDeleteFuelLog(log.id)} className="text-red-600 hover:text-red-800 font-bold text-xs p-2 bg-red-50 rounded-lg">
                                                        <Trash2 size={14} />
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                                {fuelLogs.length === 0 && (
                                    <div className="p-10 text-center text-slate-400">
                                        <Fuel className="mx-auto mb-2 opacity-50" size={32} />
                                        Chưa có nhật ký nhiên liệu
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )
            }

            {/* === TAB: VEHICLES === */}
            {
                activeTab === 'VEHICLES' && (
                    <div>
                        <div className="flex justify-end mb-4">
                            <button
                                onClick={() => {
                                    setEditingVehicleId(null);
                                    setVehicleForm({
                                        licensePlate: "", vehicleType: "CAR", brand: "", model: "", color: "", seats: 4, currentKm: 0,
                                        registrationExpiry: "", insuranceExpiry: "", lastMaintenance: ""
                                    });
                                    setIsVehicleModalOpen(true);
                                }}
                                className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:bg-blue-700 flex items-center gap-2"
                            >
                                <Plus size={18} /> Thêm xe
                            </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {vehicles.map(vehicle => {
                                const VehicleIcon = getVehicleTypeIcon(vehicle.vehicleType);
                                const isExpiringSoon = (date?: string) => {
                                    if (!date) return false;
                                    const expiry = new Date(date);
                                    const now = new Date();
                                    const diffDays = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                                    return diffDays <= 30 && diffDays > 0;
                                };
                                const isExpired = (date?: string) => date && new Date(date) < new Date();

                                return (
                                    <motion.div
                                        key={vehicle.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all"
                                    >
                                        <div className="flex justify-between items-start mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className={clsx(
                                                    "w-12 h-12 rounded-xl flex items-center justify-center",
                                                    vehicle.status === 'AVAILABLE' ? "bg-emerald-100 text-emerald-600" :
                                                        vehicle.status === 'MAINTENANCE' ? "bg-amber-100 text-amber-600" :
                                                            "bg-slate-100 text-slate-600"
                                                )}>
                                                    <VehicleIcon size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-slate-800 text-lg">{vehicle.licensePlate}</h4>
                                                    <p className="text-xs text-slate-500">{vehicle.brand} {vehicle.model}</p>
                                                </div>
                                            </div>
                                            <span className={clsx(
                                                "px-2 py-1 rounded-lg text-[10px] font-bold uppercase",
                                                vehicle.status === 'AVAILABLE' ? "bg-emerald-100 text-emerald-700" :
                                                    vehicle.status === 'MAINTENANCE' ? "bg-amber-100 text-amber-700" :
                                                        "bg-slate-100 text-slate-600"
                                            )}>
                                                {vehicle.status === 'AVAILABLE' ? 'Sẵn sàng' :
                                                    vehicle.status === 'MAINTENANCE' ? 'Bảo dưỡng' : 'Đang dùng'}
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-2 gap-3 text-sm">
                                            <div className="flex items-center gap-2 text-slate-600">
                                                <Users size={14} className="text-slate-400" />
                                                <span>{vehicle.seats} chỗ</span>
                                            </div>
                                            {vehicle.currentKm && (
                                                <div className="flex items-center gap-2 text-slate-600">
                                                    <Gauge size={14} className="text-slate-400" />
                                                    <span>{vehicle.currentKm.toLocaleString()} km</span>
                                                </div>
                                            )}
                                        </div>

                                        {/* Warnings */}
                                        <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                                            {vehicle.registrationExpiry && (
                                                <div className={clsx(
                                                    "flex items-center gap-2 text-xs font-medium rounded-lg px-2 py-1",
                                                    isExpired(vehicle.registrationExpiry) ? "bg-red-100 text-red-700" :
                                                        isExpiringSoon(vehicle.registrationExpiry) ? "bg-amber-100 text-amber-700" :
                                                            "bg-slate-50 text-slate-500"
                                                )}>
                                                    <Calendar size={12} />
                                                    Đăng kiểm: {new Date(vehicle.registrationExpiry).toLocaleDateString('en-GB')}
                                                    {isExpired(vehicle.registrationExpiry) && <span className="ml-auto">Hết hạn!</span>}
                                                </div>
                                            )}
                                            {vehicle.insuranceExpiry && (
                                                <div className={clsx(
                                                    "flex items-center gap-2 text-xs font-medium rounded-lg px-2 py-1",
                                                    isExpired(vehicle.insuranceExpiry) ? "bg-red-100 text-red-700" :
                                                        isExpiringSoon(vehicle.insuranceExpiry) ? "bg-amber-100 text-amber-700" :
                                                            "bg-slate-50 text-slate-500"
                                                )}>
                                                    <Shield size={12} />
                                                    BMDS: {new Date(vehicle.insuranceExpiry).toLocaleDateString('en-GB')}
                                                    {isExpired(vehicle.insuranceExpiry) && <span className="ml-auto">Hết hạn!</span>}
                                                </div>
                                            )}
                                            {vehicle.lastMaintenance && (
                                                <div className="flex items-center gap-2 text-xs font-medium rounded-lg px-2 py-1 bg-slate-50 text-slate-500">
                                                    <Wrench size={12} />
                                                    Bảo trì: {new Date(vehicle.lastMaintenance).toLocaleDateString('en-GB')}
                                                </div>
                                            )}
                                        </div>

                                        <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                                            <div className="text-xs text-slate-400">
                                                {vehicle._count?.trips || 0} chuyến đi
                                            </div>
                                            <div className="flex gap-2">
                                                <button onClick={() => openEditVehicle(vehicle)} className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg transition-colors" title="Chỉnh sửa">
                                                    <Edit size={16} />
                                                </button>
                                                <button onClick={() => handleDeleteVehicle(vehicle.id)} className="text-red-600 hover:bg-red-50 p-2 rounded-lg transition-colors" title="Xóa xe">
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </div>
                                    </motion.div>
                                );
                            })}

                            {!loading && vehicles.length === 0 && (
                                <div className="col-span-full text-center py-16 bg-white rounded-2xl border border-dashed border-slate-200">
                                    <Car className="mx-auto text-slate-300 mb-4" size={48} />
                                    <p className="text-slate-500 font-medium">Chưa có xe nào trong danh sách.</p>
                                </div>
                            )}
                        </div>
                    </div>
                )
            }

            {/* === TAB: STATS === */}
            {
                activeTab === 'STATS' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-sm font-bold text-slate-500 uppercase">Tổng chuyến</span>
                                <CalendarCheck className="text-blue-500" size={24} />
                            </div>
                            <div className="text-3xl font-black text-slate-800">{requests.length}</div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-sm font-bold text-slate-500 uppercase">Hoàn thành</span>
                                <CheckCircle className="text-green-500" size={24} />
                            </div>
                            <div className="text-3xl font-black text-green-600">
                                {requests.filter(r => r.status === 'COMPLETED').length}
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-sm font-bold text-slate-500 uppercase">Cấp cứu</span>
                                <AlertTriangle className="text-red-500" size={24} />
                            </div>
                            <div className="text-3xl font-black text-red-600">
                                {requests.filter(r => r.tripType === 'EMERGENCY').length}
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-sm font-bold text-slate-500 uppercase">Số xe</span>
                                <Car className="text-slate-500" size={24} />
                            </div>
                            <div className="text-3xl font-black text-slate-800">{vehicles.length}</div>
                        </div>
                    </div>
                )
            }

            {/* === MODALS === */}

            {/* Create Trip Modal */}
            <AnimatePresence>
                {isCreateModalOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 20 }}
                            className={clsx(
                                "bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden",
                                isEmergencyMode && "border-2 border-red-500"
                            )}
                        >
                            <div className={clsx(
                                "px-6 py-4 flex justify-between items-center",
                                isEmergencyMode ? "bg-red-600 text-white" : "bg-slate-50 border-b border-slate-100"
                            )}>
                                <h3 className="font-bold text-lg flex items-center gap-2">
                                    {isEmergencyMode ? <><AlertTriangle /> Điều xe CẤP CỨU</> : <>Đặt xe công tác</>}
                                </h3>
                                <button onClick={() => { setIsCreateModalOpen(false); setIsEmergencyMode(false); }} className="p-2 hover:bg-white/20 rounded-full">
                                    <X size={20} />
                                </button>
                            </div>

                            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Người đi</label>
                                        <input required type="text" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={formData.passengerName}
                                            onChange={e => setFormData({ ...formData, passengerName: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Khoa/Phòng</label>
                                        <input required type="text" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={formData.department}
                                            onChange={e => setFormData({ ...formData, department: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="text-sm font-bold text-slate-700">Điểm đến</label>
                                    <input required type="text" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                        value={formData.destination}
                                        onChange={e => setFormData({ ...formData, destination: e.target.value })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Thời gian đón</label>
                                        <input required type="datetime-local" lang="en-GB" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={formData.pickupTime}
                                            onChange={e => setFormData({ ...formData, pickupTime: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Số khách</label>
                                        <input required type="number" min="1" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={formData.passengerCount}
                                            onChange={e => setFormData({ ...formData, passengerCount: parseInt(e.target.value) })}
                                        />
                                    </div>
                                </div>

                                {!isEmergencyMode && (
                                    <div>
                                        <label className="text-sm font-bold text-slate-700 block mb-2">Loại chuyến</label>
                                        <div className="flex gap-4">
                                            <label className="flex items-center gap-2 cursor-pointer">
                                                <input type="radio" name="tripType" value="ONE_WAY"
                                                    checked={formData.tripType === 'ONE_WAY'}
                                                    onChange={e => setFormData({ ...formData, tripType: e.target.value })}
                                                />
                                                <span className="text-sm">Một chiều</span>
                                            </label>
                                            <label className="flex items-center gap-2 cursor-pointer">
                                                <input type="radio" name="tripType" value="ROUND_TRIP"
                                                    checked={formData.tripType === 'ROUND_TRIP'}
                                                    onChange={e => setFormData({ ...formData, tripType: e.target.value })}
                                                />
                                                <span className="text-sm">Khứ hồi</span>
                                            </label>
                                        </div>
                                    </div>
                                )}

                                <div>
                                    <label className="text-sm font-bold text-slate-700">Ghi chú</label>
                                    <textarea className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1" rows={2}
                                        value={formData.note}
                                        onChange={e => setFormData({ ...formData, note: e.target.value })}
                                    />
                                </div>

                                <button type="submit" disabled={submitting} className={clsx(
                                    "w-full py-3 font-bold rounded-xl flex items-center justify-center gap-2",
                                    isEmergencyMode ? "bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-500/30" : "bg-blue-600 text-white hover:bg-blue-700"
                                )}>
                                    {submitting && <Loader2 className="animate-spin" size={20} />}
                                    {isEmergencyMode ? "Điều xe ngay" : "Xác nhận đặt xe"}
                                </button>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Create Vehicle Modal */}
            <AnimatePresence>
                {isVehicleModalOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 20 }}
                            className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden"
                        >
                            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                                <h3 className="font-bold text-lg">{editingVehicleId ? "Cập nhật thông tin xe" : "Thêm xe mới"}</h3>
                                <button onClick={() => { setIsVehicleModalOpen(false); setEditingVehicleId(null); }} className="p-2 hover:bg-slate-200 rounded-full">
                                    <X size={20} />
                                </button>
                            </div>

                            <form onSubmit={handleCreateVehicle} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Biển số xe *</label>
                                        <input required className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1 font-mono uppercase"
                                            placeholder="61A-12345"
                                            value={vehicleForm.licensePlate}
                                            onChange={e => setVehicleForm({ ...vehicleForm, licensePlate: e.target.value.toUpperCase() })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Loại xe</label>
                                        <select className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={vehicleForm.vehicleType}
                                            onChange={e => setVehicleForm({ ...vehicleForm, vehicleType: e.target.value })}
                                        >
                                            <option value="CAR">Xe 4-7 chỗ</option>
                                            <option value="VAN">Xe 16 chỗ</option>
                                            <option value="AMBULANCE">Xe cứu thương</option>
                                            <option value="TRUCK">Xe tải</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Hãng xe</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            placeholder="Toyota, Ford..."
                                            value={vehicleForm.brand}
                                            onChange={e => setVehicleForm({ ...vehicleForm, brand: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Dòng xe</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            placeholder="Camry, Ranger..."
                                            value={vehicleForm.model}
                                            onChange={e => setVehicleForm({ ...vehicleForm, model: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Số chỗ</label>
                                        <input type="number" min="1" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={vehicleForm.seats}
                                            onChange={e => setVehicleForm({ ...vehicleForm, seats: parseInt(e.target.value) })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Km hiện tại</label>
                                        <input type="number" min="0" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={vehicleForm.currentKm}
                                            onChange={e => setVehicleForm({ ...vehicleForm, currentKm: parseInt(e.target.value) })}
                                        />
                                    </div>
                                </div>


                                {/* Dates Section */}
                                <div className="p-4 bg-slate-50 rounded-xl space-y-3 border border-slate-100">
                                    <h4 className="font-bold text-slate-700 text-sm border-b border-slate-200 pb-2 mb-2">Thông tin quản lý</h4>
                                    <div className="grid grid-cols-1 gap-3">
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">Hết hạn Đăng kiểm</label>
                                            <DateInput className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
                                                value={vehicleForm.registrationExpiry}
                                                onChange={(e: any) => setVehicleForm({ ...vehicleForm, registrationExpiry: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">Hết hạn Bảo hiểm (BMDS)</label>
                                            <DateInput className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
                                                value={vehicleForm.insuranceExpiry}
                                                onChange={(e: any) => setVehicleForm({ ...vehicleForm, insuranceExpiry: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 block mb-1">Bảo trì gần nhất</label>
                                            <DateInput className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
                                                value={vehicleForm.lastMaintenance}
                                                onChange={(e: any) => setVehicleForm({ ...vehicleForm, lastMaintenance: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" disabled={submitting} className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 flex items-center justify-center gap-2">
                                    {submitting && <Loader2 className="animate-spin" size={20} />}
                                    Thêm xe
                                </button>
                            </form>
                        </motion.div>
                    </div>
                )
                }
            </AnimatePresence >

            {/* Log Fuel Modal */}
            <AnimatePresence>
                {
                    isFuelModalOpen && (
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: 20 }}
                                className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden"
                            >
                                <div className="px-6 py-4 bg-amber-50 border-b border-amber-100 flex justify-between items-center text-amber-800">
                                    <h3 className="font-bold text-lg flex items-center gap-2">
                                        <Fuel size={20} /> {editingFuelLogId ? "Cập nhật phiếu nhiên liệu" : "Ghi nhận đổ nhiên liệu"}
                                    </h3>
                                    <button onClick={() => { setIsFuelModalOpen(false); setEditingFuelLogId(null); }} className="p-2 hover:bg-amber-100 rounded-full">
                                        <X size={20} />
                                    </button>
                                </div>

                                <form onSubmit={handleCreateFuelLog} className="p-6 space-y-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Chọn xe *</label>
                                        <select required className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1 bg-white"
                                            value={fuelForm.vehicleId}
                                            onChange={e => setFuelForm({ ...fuelForm, vehicleId: e.target.value })}
                                        >
                                            <option value="">-- Chọn xe --</option>
                                            {vehicles.map(v => (
                                                <option key={v.id} value={v.id}>{v.licensePlate} - {v.brand} {v.model}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-sm font-bold text-slate-700">Số lít (L) *</label>
                                            <input required type="number" step="0.01" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                                value={fuelForm.liters}
                                                onChange={e => setFuelForm({ ...fuelForm, liters: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="text-sm font-bold text-slate-700">Đơn giá (₫/L) *</label>
                                            <input required type="number" step="100" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                                value={fuelForm.pricePerLiter}
                                                onChange={e => setFuelForm({ ...fuelForm, pricePerLiter: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Thành tiền (Dự tính)</label>
                                        <div className="w-full px-4 py-2.5 bg-slate-50 rounded-xl mt-1 font-bold text-amber-600">
                                            {(parseFloat(fuelForm.liters || '0') * parseFloat(fuelForm.pricePerLiter || '0')).toLocaleString('vi-VN')} ₫
                                        </div>
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Chỉ số ODO (km) *</label>
                                        <input required type="number" className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            placeholder="Nhập số km hiện tại trên đồng hồ"
                                            value={fuelForm.odoReading}
                                            onChange={e => setFuelForm({ ...fuelForm, odoReading: e.target.value })}
                                        />
                                        <p className="text-[10px] text-slate-400 mt-1">Hệ thống sẽ cập nhật số Km này cho xe.</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Ghi chú</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            placeholder="VD: Đổ đầy bình, Xăng A95..."
                                            value={fuelForm.notes}
                                            onChange={e => setFuelForm({ ...fuelForm, notes: e.target.value })}
                                        />
                                    </div>

                                    <button type="submit" disabled={submitting} className="w-full py-3 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 flex items-center justify-center gap-2">
                                        {submitting && <Loader2 className="animate-spin" size={20} />}
                                        {editingFuelLogId ? "Cập nhật" : "Lưu nhật ký"}
                                    </button>
                                </form>
                            </motion.div>
                        </div>
                    )
                }
            </AnimatePresence >

            {/* Approve Modal */}
            <AnimatePresence>
                {
                    isApproveModalOpen && (
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: 20 }}
                                className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden"
                            >
                                <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                                    <h3 className="font-bold text-lg">Duyệt & Điều xe</h3>
                                    <button onClick={() => setIsApproveModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full">
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleApproveSubmit} className="p-6 space-y-4">
                                    <div>
                                        <label className="text-sm font-bold text-slate-700">Chọn xe</label>
                                        <select
                                            className="w-full px-4 py-2.5 border border-slate-200 rounded-xl mt-1"
                                            value={selectedVehicleId}
                                            onChange={(e) => setSelectedVehicleId(e.target.value)}
                                            required
                                        >
                                            <option value="">-- Chọn xe sẵn sàng --</option>
                                            {vehicles.filter(v => v.status === 'AVAILABLE').map(v => (
                                                <option key={v.id} value={v.id}>
                                                    {v.licensePlate} - {v.seats} chỗ ({v.brand})
                                                </option>
                                            ))}
                                        </select>
                                        <p className="text-xs text-slate-500 mt-2">
                                            Chỉ hiển thị xe đang ở trạng thái Sẵn sàng.
                                        </p>
                                    </div>

                                    <button type="submit" disabled={submitting} className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 flex items-center justify-center gap-2">
                                        {submitting && <Loader2 className="animate-spin" size={20} />}
                                        Xác nhận
                                    </button>
                                </form>
                            </motion.div>
                        </div>
                    )
                }
            </AnimatePresence >

            {
                loading && (
                    <div className="fixed inset-0 bg-white/50 flex items-center justify-center z-30">
                        <Loader2 className="animate-spin text-slate-400" size={32} />
                    </div>
                )
            }

            {/* Confirm Modal */}
            <AnimatePresence>
                {confirmModal.isOpen && (
                    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden"
                        >
                            <div className="p-6">
                                <h3 className={clsx("text-xl font-bold mb-2", confirmModal.isDanger ? "text-red-600" : "text-slate-800")}>
                                    {confirmModal.title}
                                </h3>
                                <p className="text-slate-600 mb-6">
                                    {confirmModal.content}
                                </p>
                                <div className="flex gap-3 justify-end">
                                    <button
                                        onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                                        className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-lg"
                                    >
                                        Hủy
                                    </button>
                                    <button
                                        onClick={confirmModal.action}
                                        className={clsx(
                                            "px-4 py-2 text-white font-bold rounded-lg shadow-lg",
                                            confirmModal.isDanger
                                                ? "bg-red-600 hover:bg-red-700 shadow-red-500/30"
                                                : "bg-blue-600 hover:bg-blue-700 shadow-blue-500/30"
                                        )}
                                    >
                                        Xác nhận
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Toast Notification */}
            <AnimatePresence>
                {toast.isVisible && (
                    <div className="fixed bottom-6 right-6 z-[120]">
                        <motion.div
                            initial={{ opacity: 0, y: 20, scale: 0.9 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 20, scale: 0.9 }}
                            className={clsx(
                                "flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl border bg-white",
                                toast.type === 'success' ? "border-green-200 text-green-700" : "border-red-200 text-red-700"
                            )}
                        >
                            {toast.type === 'success' ? <CheckCircle size={24} className="text-green-500" /> : <AlertTriangle size={24} className="text-red-500" />}
                            <span className="font-bold">{toast.message}</span>
                            <button onClick={() => setToast(prev => ({ ...prev, isVisible: false }))} className="ml-2 hover:bg-slate-100 p-1 rounded-full text-slate-400">
                                <X size={16} />
                            </button>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div >
    );
}

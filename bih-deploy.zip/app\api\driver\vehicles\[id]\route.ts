import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

// Helper: Check permission
function canManageDriver(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    const role = user.role?.toUpperCase();
    const position = user.position?.toUpperCase();

    if (role === 'ADMIN') return true;
    if (role === 'DRIVER' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(position)) return true;
    return false;
}

// PATCH: Edit Vehicle
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const isManager = canManageDriver(user);
        if (!isManager) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const id = parseInt(params.id);
        const body = await request.json();

        // Sanitize date inputs
        const dataToUpdate: any = { ...body };
        if (body.registrationExpiry) dataToUpdate.registrationExpiry = new Date(body.registrationExpiry);
        if (body.insuranceExpiry) dataToUpdate.insuranceExpiry = new Date(body.insuranceExpiry);
        if (body.lastMaintenance) dataToUpdate.lastMaintenance = new Date(body.lastMaintenance);
        if (body.currentKm) dataToUpdate.currentKm = parseInt(body.currentKm);
        if (body.seats) dataToUpdate.seats = parseInt(body.seats);
        if (body.nextMaintenanceKm) dataToUpdate.nextMaintenanceKm = parseInt(body.nextMaintenanceKm);

        delete dataToUpdate.id; // Prevent ID update

        const updatedVehicle = await prisma.vehicle.update({
            where: { id },
            data: dataToUpdate
        });

        return NextResponse.json(updatedVehicle);

    } catch (error: any) {
        console.error("Edit Vehicle Error:", error);
        return NextResponse.json({ error: "Failed to edit vehicle" }, { status: 500 });
    }
}

// DELETE: Delete Vehicle
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const isManager = canManageDriver(user);
        if (!isManager) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const id = parseInt(params.id);

        // Check if vehicle has trips
        const vehicle = await prisma.vehicle.findUnique({
            where: { id },
            include: { _count: { select: { trips: true } } }
        });

        if (vehicle && vehicle._count.trips > 0) {
            return NextResponse.json({ error: "Không thể xóa xe đã có lịch sử chuyến đi." }, { status: 400 });
        }

        await prisma.vehicle.delete({ where: { id } });

        return NextResponse.json({ message: "Deleted successfully" });

    } catch (error: any) {
        console.error("Delete Vehicle Error:", error);
        return NextResponse.json({ error: "Failed to delete vehicle" }, { status: 500 });
    }
}

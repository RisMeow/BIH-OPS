SELECT id, username, role, position FROM "User";

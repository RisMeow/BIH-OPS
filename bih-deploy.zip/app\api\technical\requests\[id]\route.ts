import { NextResponse } from 'next/server';
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can assign/approve in Technical department
function canManageTechnical(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'TECHNICAL' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) return true;
    return false;
}

// GET: Lấy chi tiết ticket
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const requestDetail = await prisma.maintenanceRequest.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                assignments: { include: { user: { select: { id: true, fullName: true } } } },
                comments: { orderBy: { createdAt: 'asc' } }
            }
        });

        if (!requestDetail) return NextResponse.json({ error: "Not found" }, { status: 404 });
        return NextResponse.json(requestDetail);
    } catch (error) {
        return NextResponse.json({ error: "Server Error" }, { status: 500 });
    }
}

// PATCH: Cập nhật thông tin, trạng thái hoặc phân công
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const id = parseInt(params.id);
        const body = await request.json();
        const { assignedToId, assigneeIds, status, title, description, priority, location, rejectReason } = body;

        const updateData: Record<string, unknown> = {};

        // 1. ASSIGNMENT MANAGEMENT
        let newAssigneeIds = assigneeIds;
        if (assignedToId && !assigneeIds) {
            newAssigneeIds = [parseInt(assignedToId)];
        }

        if (newAssigneeIds !== undefined) {
            if (!canManageTechnical(user)) {
                return NextResponse.json({ error: "Permission denied: Only Technical Leader can assign tasks" }, { status: 403 });
            }

            // Transaction to update assignments
            await prisma.$transaction(async (tx) => {
                await tx.maintenanceAssignment.deleteMany({ where: { requestId: id } });

                if (newAssigneeIds && newAssigneeIds.length > 0) {
                    await tx.maintenanceAssignment.createMany({
                        data: newAssigneeIds.map((uid: number) => ({
                            requestId: id,
                            userId: Number(uid)
                        }))
                    });

                    updateData.assignedToId = Number(newAssigneeIds[0]);
                } else {
                    updateData.assignedToId = null;
                }
            });

            // Auto status update
            if (!status || status === 'PENDING') {
                updateData.status = 'ASSIGNED';
            }
        }

        // 2. STATUS CHANGE
        if (status) {
            // APPROVE/REJECT: Only leaders can do this
            if (['APPROVED', 'REJECTED'].includes(status)) {
                if (!canManageTechnical(user)) {
                    return NextResponse.json({ error: "Permission denied: Only Technical Leader can approve/reject" }, { status: 403 });
                }
            }

            // IN_PROGRESS/COMPLETED: Assigned staff or leaders can update
            if (['IN_PROGRESS', 'COMPLETED', 'ON_HOLD'].includes(status)) {
                const currentRequest = await prisma.maintenanceRequest.findUnique({
                    where: { id },
                    include: { assignments: true }
                });

                const isAssignedStaff = currentRequest?.assignments.some(a => a.userId === user.id) || currentRequest?.assignedToId === user.id;
                const isLeader = canManageTechnical(user);

                if (!isAssignedStaff && !isLeader) {
                    return NextResponse.json({ error: "Permission denied: Only assigned staff or leaders can update status" }, { status: 403 });
                }
            }

            updateData.status = status;
        }

        // 3. TICKET DETAILS UPDATE
        if (title || description || priority || location) {
            const isLeader = canManageTechnical(user);

            if (isLeader) {
                if (title) updateData.title = title;
                if (description) updateData.description = description;
                if (priority) updateData.priority = priority;
                if (location) updateData.location = location;
                if (body.quantity) updateData.quantity = parseInt(body.quantity);
                if (body.unit) updateData.unit = body.unit;
            }
        }

        const updatedRequest = await prisma.maintenanceRequest.update({
            where: { id },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                assignments: { include: { user: { select: { id: true, fullName: true } } } }
            }
        });

        // === WORKFLOW TRACKING ===
        // Nếu REJECTED, tạo TicketFeedback để người yêu cầu biết lý do
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'TECHNICAL',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Ghi nhận timeline khi thay đổi trạng thái quan trọng
        if (status && !['PENDING'].includes(status)) {
            const statusLabels: Record<string, string> = {
                'ASSIGNED': 'Đã phân công',
                'IN_PROGRESS': 'Đang thực hiện',
                'COMPLETED': 'Hoàn thành',
                'APPROVED': 'Đã duyệt',
                'REJECTED': 'Từ chối',
                'ON_HOLD': 'Tạm dừng'
            };

            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'TECHNICAL',
                    ticketId: id,
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái: ${statusLabels[status] || status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updatedRequest);
    } catch (error) {
        console.error("Update Request Error:", error);
        return NextResponse.json({ error: 'Failed to update request' }, { status: 500 });
    }
}

// DELETE: Xóa yêu cầu (Only admin or technical leader)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (!canManageTechnical(user)) {
            return NextResponse.json({ error: "Permission denied: Only Technical Leader can delete requests" }, { status: 403 });
        }

        // Also delete related feedback
        await prisma.ticketFeedback.deleteMany({
            where: { ticketType: 'TECHNICAL', ticketId: parseInt(params.id) }
        });

        await prisma.maintenanceRequest.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted' });
    } catch (error) {
        return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
    }
}

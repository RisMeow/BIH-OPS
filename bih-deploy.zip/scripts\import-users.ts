// Script to create user accounts from CSV
// Run with: npx ts-node scripts/import-users.ts

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// Vietnamese to ASCII conversion for username generation
function removeVietnameseAccents(str: string): string {
    const accents = [
        { base: 'a', letters: 'àáạảãâầấậẩẫăằắặẳẵ' },
        { base: 'e', letters: 'èéẹẻẽêềếệểễ' },
        { base: 'i', letters: 'ìíịỉĩ' },
        { base: 'o', letters: 'òóọỏõôồốộổỗơờớợởỡ' },
        { base: 'u', letters: 'ùúụủũưừứựửữ' },
        { base: 'y', letters: 'ỳýỵỷỹ' },
        { base: 'd', letters: 'đ' },
        { base: 'A', letters: 'ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ' },
        { base: 'E', letters: 'ÈÉẸẺẼÊỀẾỆỂỄ' },
        { base: 'I', letters: 'ÌÍỊỈĨ' },
        { base: 'O', letters: 'ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ' },
        { base: 'U', letters: 'ÙÚỤỦŨƯỪỨỰỬỮ' },
        { base: 'Y', letters: 'ỲÝỴỶỸ' },
        { base: 'D', letters: 'Đ' },
    ];

    let result = str;
    for (const accent of accents) {
        for (const letter of accent.letters) {
            result = result.replace(new RegExp(letter, 'g'), accent.base);
        }
    }
    return result;
}

// Generate username from full name
function generateUsername(fullName: string): string {
    const normalized = removeVietnameseAccents(fullName.trim().toLowerCase());
    const parts = normalized.split(/\s+/).filter(Boolean);
    if (parts.length === 0) return 'user';

    // Format: firstname.lastname (e.g., tung.trankt)
    const firstName = parts[parts.length - 1];
    const lastNameInitials = parts.slice(0, -1).map(p => p.charAt(0)).join('');
    return `${firstName}.${lastNameInitials}`;
}

// Determine role and position based on department and gender
function getRoleAndPosition(department: string, gender: string, title: string): { role: string; position: string } {
    const deptLower = department.toLowerCase();
    const titleLower = title.toLowerCase();
    const isFemale = gender === 'Nữ' || gender === 'N?' || gender.includes('N');

    // Determine position
    let position = 'STAFF';
    if (titleLower.includes('trưởng') || titleLower.includes('tr??ng') || titleLower.includes('truong')) {
        position = 'LEADER';
    } else if (titleLower.includes('giám sát') || titleLower.includes('gi?m s?t') || titleLower.includes('giam sat')) {
        position = 'SUPERVISOR';
    } else if (titleLower.includes('chuyên viên') || titleLower.includes('chuy?n vi?n') || titleLower.includes('chuyen vien')) {
        position = 'STAFF';
    } else if (titleLower.includes('kỹ sư') || titleLower.includes('k? s?') || titleLower.includes('ky su')) {
        position = 'LEADER';
    } else if (titleLower.includes('admin')) {
        position = 'LEADER';
    }

    // Determine role
    let role = 'ENVIRONMENT';

    if (deptLower.includes('môi trường') || deptLower.includes('m?i tr??ng') || deptLower.includes('moi truong')) {
        // Environment department - if female, move to Nursing (Hộ lý)
        if (isFemale) {
            role = 'NURSING';
        } else {
            role = 'ENVIRONMENT';
        }
    } else if (deptLower.includes('bảo vệ') || deptLower.includes('b?o v?') || deptLower.includes('bao ve')) {
        role = 'SECURITY';
    } else if (deptLower.includes('cung ứng') || deptLower.includes('cung ?ng') || deptLower.includes('cung ung')) {
        role = 'SUPPLY';
    } else if (deptLower.includes('lái xe') || deptLower.includes('l?i xe') || deptLower.includes('lai xe')) {
        role = 'DRIVER';
    } else if (deptLower.includes('ktvh') || deptLower.includes('kỹ thuật') || deptLower.includes('k? thu?t')) {
        role = 'TECHNICAL';
    }

    return { role, position };
}

async function importUsers() {
    // ESM compatible path resolution
    const scriptDir = new URL('.', import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1');
    const csvPath = scriptDir.replace(/scripts\/$/, 'cleanup/ttlylich.csv');
    console.log('Reading CSV from:', csvPath);

    const content = fs.readFileSync(csvPath, 'utf-8');
    const lines = content.split('\n').filter(line => line.trim());

    const header = lines[0].split(',');
    console.log('Header:', header);

    const users: any[] = [];
    const usernameCount: Record<string, number> = {};

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        if (values.length < 10) continue;

        const stt = values[0].trim();
        const fullName = values[1].trim();
        const birthDate = values[2]?.trim();
        const birthYear = values[3]?.trim();
        const genderCode = values[4]?.trim();
        const genderText = values[5]?.trim();
        const email = values[6]?.trim();
        const phone = values[7]?.trim();
        const department = values[8]?.trim();
        const title = values[9]?.trim();

        if (!fullName) continue;

        // Generate unique username
        let baseUsername = generateUsername(fullName);
        if (usernameCount[baseUsername]) {
            usernameCount[baseUsername]++;
            baseUsername = `${baseUsername}${usernameCount[baseUsername]}`;
        } else {
            usernameCount[baseUsername] = 1;
        }

        const { role, position } = getRoleAndPosition(department, genderText || '', title || '');

        // Default password is phone number or '123456'
        const password = phone || '123456';
        const hashedPassword = await bcrypt.hash(password, 10);

        users.push({
            username: baseUsername,
            password: hashedPassword,
            fullName: fullName,
            email: email || null,
            phoneNumber: phone || null,
            role,
            position,
            // Store original data for reference
            _original: {
                stt,
                department,
                title,
                genderText,
                birthYear
            }
        });
    }

    console.log(`\n=== IMPORT SUMMARY ===`);
    console.log(`Total users to create: ${users.length}`);

    // Group by role for summary
    const byRole: Record<string, number> = {};
    users.forEach(u => {
        byRole[u.role] = (byRole[u.role] || 0) + 1;
    });
    console.log('\nUsers by role:');
    Object.entries(byRole).forEach(([role, count]) => {
        console.log(`  ${role}: ${count}`);
    });

    // Sample users
    console.log('\n=== SAMPLE USERS ===');
    users.slice(0, 5).forEach(u => {
        console.log(`${u.username} | ${u.fullName} | ${u.role} | ${u.position}`);
    });

    // Create users in database
    console.log('\n=== CREATING USERS ===');
    let created = 0;
    let skipped = 0;

    for (const user of users) {
        try {
            // Check if user already exists
            const existing = await prisma.user.findUnique({
                where: { username: user.username }
            });

            if (existing) {
                console.log(`SKIP: ${user.username} (already exists)`);
                skipped++;
                continue;
            }

            await prisma.user.create({
                data: {
                    username: user.username,
                    password: user.password,
                    fullName: user.fullName,
                    email: user.email,
                    phoneNumber: user.phoneNumber,
                    role: user.role,
                    position: user.position,
                }
            });
            console.log(`OK: ${user.username} -> ${user.role}/${user.position}`);
            created++;
        } catch (error: any) {
            console.error(`ERROR: ${user.username} - ${error.message}`);
        }
    }

    console.log(`\n=== DONE ===`);
    console.log(`Created: ${created}`);
    console.log(`Skipped: ${skipped}`);

    await prisma.$disconnect();
}

importUsers().catch(console.error);

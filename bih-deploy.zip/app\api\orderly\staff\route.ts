
import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs"; // Cần bcryptjs để hash password

const prisma = new PrismaClient();

export async function GET() {
    try {
        // Lấy tất cả user có role là NURSING (Hộ lý)
        // Đồng thời lấy kèm thống kê số lần InspectionLog PASS/FAIL
        const staff = await prisma.user.findMany({
            where: {
                role: 'NURSING'
            },
            select: {
                id: true,
                fullName: true,
                position: true,
                phoneNumber: true,
                email: true,
                inspectionLogs: {
                    select: {
                        status: true
                    }
                }
            }
        });

        // Tính toán thống kê từ dữ liệu thô
        const formattedStaff = staff.map(s => {
            const passCount = s.inspectionLogs.filter(l => l.status === 'PASS').length;
            const failCount = s.inspectionLogs.filter(l => l.status === 'FAIL').length;
            return {
                id: s.id,
                name: s.fullName,
                role: s.position,
                passCount,
                failCount,
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(s.fullName)}&background=random` // Auto avatar
            };
        });

        return NextResponse.json(formattedStaff);
    } catch (error) {
        console.error("Error fetching staff:", error);
        return NextResponse.json({ error: "Failed to fetch staff" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { fullName, username, password, position } = body;

        if (!fullName || !username || !password) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        // Hash password (trong thực tế nên dùng bcrypt, ở đây nếu chưa cài thì lưu tạm text hoặc cài thêm)
        // Giả sử ta lưu plain text nếu chưa có lib hoặc dùng thuật toán đơn giản, 
        // nhưng tốt nhất là nên có bcrypt. Ta cứ lưu string tạm.
        // TODO: Install bcryptjs

        const newUser = await prisma.user.create({
            data: {
                fullName,
                username,
                password, // Nên hash
                role: 'NURSING',
                position: position || 'STAFF'
            }
        });

        return NextResponse.json(newUser, { status: 201 });
    } catch (error) {
        console.error("Error creating staff:", error);
        return NextResponse.json({ error: "Failed to create staff" }, { status: 500 });
    }
}

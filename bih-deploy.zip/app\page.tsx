"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Loader2, Lock, User, ArrowRight, Building2, Shield, Heart } from "lucide-react";
import "./globals.css";

import { useLanguage } from "@/app/context/LanguageContext";
import LanguageSwitcher from "@/components/LanguageSwitcher";

export default function LoginPage() {
    const router = useRouter();
    const { t } = useLanguage(); // Init hook
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            const result = await signIn("credentials", {
                username,
                password,
                redirect: false,
            });

            if (result?.error) {
                setError(t.login.errorAuth);
                setLoading(false);
            } else {
                router.push("/dashboard");
                router.refresh();
            }
        } catch {
            setError(t.login.errorGeneric);
            setLoading(false);
        }
    };

    // Staggered animation
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.08,
                delayChildren: 0.1,
            },
        },
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.5, ease: "easeOut" as const },
        },
    };

    return (
        <div className="min-h-screen w-full flex items-center justify-center p-4 bg-slate-50 relative overflow-hidden">
            {/* Ambient Background Elements */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-blue-100 rounded-full blur-[100px] opacity-60 animate-float-slow" />
                <div className="absolute bottom-[-10%] right-[-5%] w-[500px] h-[500px] bg-teal-100 rounded-full blur-[80px] opacity-60 animate-float-delayed" />
                <div className="absolute top-[40%] left-[30%] w-[300px] h-[300px] bg-indigo-50 rounded-full blur-[60px] opacity-40 animate-pulse-slow" />
            </div>

            {/* Language Switcher - Top Right */}
            <div className="absolute top-4 right-4 z-50">
                <LanguageSwitcher />
            </div>

            <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center relative z-10">
                {/* Left Side: Branding */}
                <motion.div
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="p-6 lg:p-0 flex flex-col items-center lg:items-start text-center lg:text-left order-2 lg:order-1"
                >
                    <div className="flex items-center gap-3 mb-8">
                        <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-800 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                            <Building2 size={32} strokeWidth={2.5} />
                        </div>
                        <div>
                            <h1 className="text-2xl font-black text-blue-700 tracking-tight leading-none">BIH</h1>
                            <span className="text-xs font-bold text-teal-600 uppercase tracking-widest">{t.login.brandingTitle}</span>
                        </div>
                    </div>

                    <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
                        {t.login.brandingTitle} <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-500">
                            {t.login.brandingSubtitle}
                        </span>
                    </h2>

                    <p className="text-lg text-slate-500 leading-relaxed max-w-lg mb-8">
                        {t.login.brandingDesc}
                    </p>

                    <div className="flex gap-6 text-sm font-semibold text-slate-600">
                        <div className="flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-slate-100 shadow-sm">
                            <Shield className="text-teal-500" size={18} />
                            <span>{t.login.featureSecurity}</span>
                        </div>
                        <div className="flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-slate-100 shadow-sm">
                            <Heart className="text-red-500" size={18} />
                            <span>{t.login.featureDedication}</span>
                        </div>
                    </div>
                </motion.div>

                {/* Right Side: Login Form */}
                <motion.div
                    initial="hidden"
                    animate="visible"
                    variants={containerVariants}
                    className="w-full max-w-md mx-auto order-1 lg:order-2"
                >
                    <motion.div
                        variants={itemVariants}
                        className="bg-white/80 backdrop-blur-xl border border-white/40 p-8 rounded-3xl shadow-2xl shadow-blue-900/5 relative overflow-hidden"
                    >
                        {/* Decorative shine effect */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-white/20 to-transparent -rotate-45 transform translate-x-10 -translate-y-10 pointer-events-none" />

                        <div className="text-center mb-8">
                            <h3 className="text-2xl font-bold text-slate-800">{t.login.title}</h3>
                            <p className="text-slate-500 text-sm mt-1">{t.login.subtitle}</p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-5">
                            <motion.div variants={itemVariants} className="space-y-1.5">
                                <label className="text-xs font-bold text-slate-700 uppercase tracking-wide ml-1">{t.login.username}</label>
                                <div className="relative group">
                                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">
                                        <User size={18} />
                                    </div>
                                    <input
                                        type="text"
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-sm rounded-xl pl-10 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-slate-400"
                                        placeholder={t.login.usernamePlaceholder}
                                        required
                                    />
                                </div>
                            </motion.div>

                            <motion.div variants={itemVariants} className="space-y-1.5">
                                <label className="text-xs font-bold text-slate-700 uppercase tracking-wide ml-1">{t.login.password}</label>
                                <div className="relative group">
                                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">
                                        <Lock size={18} />
                                    </div>
                                    <input
                                        type="password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-sm rounded-xl pl-10 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-slate-400 font-mono" // font-mono for password dots
                                        placeholder={t.login.passwordPlaceholder}
                                        required
                                    />
                                </div>
                            </motion.div>

                            {error && (
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-xs font-medium text-center"
                                >
                                    {error}
                                </motion.div>
                            )}

                            <motion.button
                                variants={itemVariants}
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                type="submit"
                                disabled={loading}
                                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 transition-all disabled:opacity-70 disabled:cursor-not-allowed"
                            >
                                {loading ? (
                                    <>
                                        <Loader2 size={20} className="animate-spin" />
                                        <span>{t.login.processing}</span>
                                    </>
                                ) : (
                                    <>
                                        <span>{t.login.button}</span>
                                        <ArrowRight size={20} />
                                    </>
                                )}
                            </motion.button>
                        </form>

                        <div className="mt-8 text-center">
                            <p className="text-xs text-slate-400 whitespace-pre-line">
                                {t.login.footer}
                            </p>
                        </div>
                    </motion.div>
                </motion.div>
            </div>

            <style jsx global>{`
                @keyframes float-slow {
                    0%, 100% { transform: translate(0, 0); }
                    50% { transform: translate(20px, 20px); }
                }
                @keyframes float-delayed {
                    0%, 100% { transform: translate(0, 0); }
                    50% { transform: translate(-20px, -15px); }
                }
                 @keyframes pulse-slow {
                    0%, 100% { opacity: 0.4; transform: scale(1); }
                    50% { opacity: 0.3; transform: scale(1.1); }
                }
                .animate-float-slow { animation: float-slow 8s ease-in-out infinite; }
                .animate-float-delayed { animation: float-delayed 10s ease-in-out infinite; }
                .animate-pulse-slow { animation: pulse-slow 12s ease-in-out infinite; }
            `}</style>
        </div>
    );
}

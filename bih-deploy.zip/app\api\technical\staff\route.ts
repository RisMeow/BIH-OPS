import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
    try {
        const staff = await prisma.user.findMany({
            where: {
                role: 'TECHNICAL',
                // Optional: Chỉ lấy nhân viên cấp dưới nếu cần logic phức tạp hơn
            },
            select: {
                id: true,
                fullName: true,
                position: true,
                username: true
            }
        });
        return NextResponse.json(staff);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch staff' }, { status: 500 });
    }
}

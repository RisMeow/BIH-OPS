import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function checkTechnicalAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    const user = session.user as { id: number; role: string; position: string };
    if (user.role !== 'ADMIN' && user.role !== 'TECHNICAL') return null;
    return user;
}

// GET: Get single asset with full details
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const asset = await prisma.asset.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                maintenanceSchedules: true,
                maintenanceHistory: {
                    orderBy: { performedAt: 'desc' },
                    take: 20
                }
            }
        });

        if (!asset) {
            return NextResponse.json({ error: "Asset not found" }, { status: 404 });
        }

        return NextResponse.json(asset);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch asset' }, { status: 500 });
    }
}

// PATCH: Update asset
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== 'ADMIN' && !['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const id = parseInt(params.id);
        const body = await request.json();

        const asset = await prisma.asset.update({
            where: { id },
            data: {
                ...body,
                purchaseDate: body.purchaseDate ? new Date(body.purchaseDate) : undefined,
                warrantyExpiry: body.warrantyExpiry ? new Date(body.warrantyExpiry) : undefined
            }
        });

        return NextResponse.json(asset);
    } catch (error) {
        console.error("Update asset error:", error);
        return NextResponse.json({ error: 'Failed to update asset' }, { status: 500 });
    }
}

// DELETE: Delete asset
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== 'ADMIN' && !['MANAGER', 'LEADER'].includes(user.position)) {
            return NextResponse.json({ error: "Permission denied: Only leaders can delete assets" }, { status: 403 });
        }

        await prisma.asset.delete({ where: { id: parseInt(params.id) } });
        return NextResponse.json({ message: 'Deleted successfully' });
    } catch (error) {
        return NextResponse.json({ error: 'Failed to delete asset' }, { status: 500 });
    }
}

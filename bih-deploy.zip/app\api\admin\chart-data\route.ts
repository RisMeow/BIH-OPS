import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

// GET /api/admin/chart-data
// Returns aggregated request counts by department for chart display
export async function GET(request: Request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || (session.user as any).role !== 'ADMIN') {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const filterType = searchParams.get('filter') || 'month'; // week, month, quarter, year
        const filterValue = searchParams.get('value'); // specific month number, etc.

        // Calculate date ranges based on filter
        const now = new Date();
        let startDate: Date;
        let endDate: Date = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        let labels: string[] = [];
        let groupByFormat: 'day' | 'week' | 'month' = 'day';

        switch (filterType) {
            case 'week':
                // Last 7 days
                startDate = new Date(now);
                startDate.setDate(startDate.getDate() - 6);
                startDate.setHours(0, 0, 0, 0);
                labels = [];
                for (let i = 0; i < 7; i++) {
                    const d = new Date(startDate);
                    d.setDate(d.getDate() + i);
                    labels.push(d.toLocaleDateString('vi-VN', { weekday: 'short', day: 'numeric' }));
                }
                groupByFormat = 'day';
                break;

            case 'month':
                // Current month or specified month
                const month = filterValue ? parseInt(filterValue) - 1 : now.getMonth();
                startDate = new Date(now.getFullYear(), month, 1);
                endDate = new Date(now.getFullYear(), month + 1, 0, 23, 59, 59);
                const daysInMonth = endDate.getDate();
                // Group by weeks within the month
                labels = ['Tuần 1', 'Tuần 2', 'Tuần 3', 'Tuần 4'];
                if (daysInMonth > 28) labels.push('Tuần 5');
                groupByFormat = 'week';
                break;

            case 'quarter':
                // Current quarter
                const currentQuarter = Math.floor(now.getMonth() / 3);
                startDate = new Date(now.getFullYear(), currentQuarter * 3, 1);
                endDate = new Date(now.getFullYear(), (currentQuarter + 1) * 3, 0, 23, 59, 59);
                labels = ['Tháng 1', 'Tháng 2', 'Tháng 3'];
                groupByFormat = 'month';
                break;

            case 'year':
                // Current year
                startDate = new Date(now.getFullYear(), 0, 1);
                endDate = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
                labels = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'];
                groupByFormat = 'month';
                break;

            default:
                startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                labels = ['Tuần 1', 'Tuần 2', 'Tuần 3', 'Tuần 4'];
                groupByFormat = 'week';
        }

        // Fetch data from all request tables
        const [technicalRequests, nursingRequests, driverRequests, securityRequests, supplyRequests, environmentRequests] = await Promise.all([
            prisma.maintenanceRequest.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
            prisma.nursingRequest.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
            prisma.transportRequest.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
            prisma.securityReport.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
            prisma.supplyRequest.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
            prisma.cleaningRequest.findMany({
                where: { createdAt: { gte: startDate, lte: endDate } },
                select: { createdAt: true, status: true }
            }),
        ]);

        // Combine all requests
        const allRequests = [
            ...technicalRequests,
            ...nursingRequests,
            ...driverRequests,
            ...securityRequests,
            ...supplyRequests,
            ...environmentRequests
        ];

        // Group requests into buckets based on the filter type
        const data: number[] = new Array(labels.length).fill(0);
        const completedData: number[] = new Array(labels.length).fill(0);

        allRequests.forEach(req => {
            const reqDate = new Date(req.createdAt);
            let bucketIndex = 0;

            if (groupByFormat === 'day') {
                // For weekly view - each day is a bucket
                const diffTime = reqDate.getTime() - startDate.getTime();
                bucketIndex = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            } else if (groupByFormat === 'week') {
                // For monthly view - group by week
                const dayOfMonth = reqDate.getDate();
                bucketIndex = Math.floor((dayOfMonth - 1) / 7);
            } else if (groupByFormat === 'month') {
                // For quarterly/yearly view - group by month
                if (filterType === 'quarter') {
                    const currentQuarter = Math.floor(now.getMonth() / 3);
                    bucketIndex = reqDate.getMonth() - (currentQuarter * 3);
                } else {
                    bucketIndex = reqDate.getMonth();
                }
            }

            if (bucketIndex >= 0 && bucketIndex < labels.length) {
                data[bucketIndex]++;
                if (req.status === 'COMPLETED' || req.status === 'APPROVED') {
                    completedData[bucketIndex]++;
                }
            }
        });

        // Calculate performance percentage for each bucket
        const performanceData = data.map((total, idx) => {
            if (total === 0) return 0;
            return Math.round((completedData[idx] / total) * 100);
        });

        return NextResponse.json({
            labels,
            data,             // Total requests per period
            completedData,    // Completed requests per period
            performanceData,  // Performance % per period
            total: allRequests.length,
            completed: allRequests.filter(r => r.status === 'COMPLETED' || r.status === 'APPROVED').length,
            filterType,
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString()
        });

    } catch (error) {
        console.error("Chart data fetch error:", error);
        return NextResponse.json({ error: "Failed to fetch chart data" }, { status: 500 });
    }
}

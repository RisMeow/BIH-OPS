import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; fullName: string } | null;
}

// GET: Lấy danh sách khách
export async function GET(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const status = searchParams.get('status');

        const where: any = {};
        if (status) {
            where.status = status;
        }

        const visitors = await prisma.visitor.findMany({
            where,
            orderBy: { checkInTime: 'desc' },
            take: 100
        });
        return NextResponse.json(visitors);
    } catch (error) {
        console.error("Fetch Visitors Error:", error);
        return NextResponse.json({ error: "Failed to fetch visitors" }, { status: 500 });
    }
}

// POST: Ghi nhận khách vào
export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Chỉ SECURITY mới được ghi nhận khách
        if (user.role !== 'SECURITY' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Chỉ nhân viên An ninh mới được ghi nhận khách" }, { status: 403 });
        }

        const body = await request.json();
        const {
            fullName, idNumber, company, phone, purpose,
            hostDepartment, hostPerson, vehicleType, vehiclePlate, tempCardNumber
        } = body;

        if (!fullName || !purpose) {
            return NextResponse.json({ error: "Thiếu thông tin khách (tên, mục đích)" }, { status: 400 });
        }

        const newVisitor = await prisma.visitor.create({
            data: {
                fullName,
                idNumber: idNumber || null,
                company: company || null,
                phone: phone || null,
                purpose,
                hostDepartment: hostDepartment || null,
                hostPerson: hostPerson || null,
                vehicleType: vehicleType || null,
                vehiclePlate: vehiclePlate || null,
                tempCardNumber: tempCardNumber || null,
                status: 'CHECKED_IN',
                createdById: user.id,
                createdByName: user.fullName
            }
        });

        return NextResponse.json(newVisitor, { status: 201 });
    } catch (error) {
        console.error("Create Visitor Error:", error);
        return NextResponse.json({ error: "Failed to create visitor" }, { status: 500 });
    }
}

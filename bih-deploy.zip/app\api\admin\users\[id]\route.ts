import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// Helper: Kiểm tra quyền Admin
async function checkAdminAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user || session.user.role !== 'ADMIN') {
        return false;
    }
    return true;
}

// GET: Lấy thông tin chi tiết một user
export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const id = parseInt(params.id);
        const user = await prisma.user.findUnique({
            where: { id },
            select: {
                id: true,
                username: true,
                fullName: true,
                email: true,
                phoneNumber: true,
                department: true,
                role: true,
                position: true,
                manager: {
                    select: { id: true, fullName: true }
                },
                staff: {
                    select: { id: true, fullName: true, position: true }
                },
                createdAt: true,
                updatedAt: true,
            },
        });

        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        return NextResponse.json(user);
    } catch (error) {
        console.error("Get user error:", error);
        return NextResponse.json({ error: 'Failed to get user' }, { status: 500 });
    }
}

// PUT: Cập nhật thông tin user (CHỈ ADMIN)
export async function PUT(
    request: Request,
    { params }: { params: { id: string } }
) {
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const id = parseInt(params.id);
        const body = await request.json();
        const { username, password, fullName, email, phoneNumber, department, role, position, managerId } = body;

        // Kiểm tra user tồn tại
        const existingUser = await prisma.user.findUnique({ where: { id } });
        if (!existingUser) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        // Kiểm tra username trùng (nếu thay đổi)
        if (username !== existingUser.username) {
            const duplicateUsername = await prisma.user.findUnique({ where: { username } });
            if (duplicateUsername) {
                return NextResponse.json({ error: 'Tên đăng nhập đã tồn tại' }, { status: 400 });
            }
        }

        // Kiểm tra email trùng (nếu thay đổi)
        if (email && email !== existingUser.email) {
            const duplicateEmail = await prisma.user.findUnique({ where: { email } });
            if (duplicateEmail) {
                return NextResponse.json({ error: 'Email đã được sử dụng' }, { status: 400 });
            }
        }

        // Prepare update data
        const updateData: any = {
            username,
            fullName,
            email: email || null,
            phoneNumber: phoneNumber || null,
            department: department || null,
            role,
            position,
            managerId: managerId ? parseInt(managerId) : null,
        };

        // Only hash and update password if provided
        if (password && password.trim() !== '') {
            updateData.password = await bcrypt.hash(password, 10);
        }

        const updatedUser = await prisma.user.update({
            where: { id },
            data: updateData,
        });

        // Remove password from response
        const { password: _, ...userWithoutPassword } = updatedUser;

        return NextResponse.json(userWithoutPassword);
    } catch (error: any) {
        console.error("Update error:", error);
        return NextResponse.json({
            error: error.message || 'Failed to update user',
            details: error.meta || {}
        }, { status: 500 });
    }
}

// DELETE: Xóa user (CHỈ ADMIN)
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const id = parseInt(params.id);
        const session = await getServerSession(authOptions);

        // Không cho phép xóa chính mình
        if (session?.user?.id === id) {
            return NextResponse.json({ error: 'Không thể tự xóa tài khoản của mình' }, { status: 400 });
        }

        // Kiểm tra user có tồn tại không
        const user = await prisma.user.findUnique({ where: { id } });
        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        // Xóa các liên kết trước (MaintenanceAssignment, etc.)
        await prisma.maintenanceAssignment.deleteMany({
            where: { userId: id }
        });

        // Cập nhật các user có managerId là user này
        await prisma.user.updateMany({
            where: { managerId: id },
            data: { managerId: null }
        });

        // Xóa user
        await prisma.user.delete({
            where: { id },
        });

        return NextResponse.json({ message: 'User deleted successfully' });
    } catch (error: any) {
        console.error("Delete error:", error);
        return NextResponse.json({ error: 'Failed to delete user' }, { status: 500 });
    }
}

// PATCH: Reset password (CHỈ ADMIN)
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    const isAdmin = await checkAdminAccess();
    if (!isAdmin) {
        return NextResponse.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    try {
        const id = parseInt(params.id);
        const body = await request.json();
        const { action, newPassword } = body;

        if (action === 'reset_password') {
            if (!newPassword || newPassword.length < 6) {
                return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
            }

            const hashedPassword = await bcrypt.hash(newPassword, 10);

            await prisma.user.update({
                where: { id },
                data: { password: hashedPassword }
            });

            return NextResponse.json({ message: 'Password reset successfully' });
        }

        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    } catch (error: any) {
        console.error("Patch error:", error);
        return NextResponse.json({ error: 'Operation failed' }, { status: 500 });
    }
}

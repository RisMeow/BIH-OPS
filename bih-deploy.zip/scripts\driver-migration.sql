-- Extend TransportRequest table
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "pickupLocation" VARCHAR(255);
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "returnTime" TIMESTAMP;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS purpose VARCHAR(100);
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS note TEXT;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "startKm" INTEGER;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "endKm" INTEGER;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "fuelUsed" FLOAT;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP DEFAULT NOW();
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "completedAt" TIMESTAMP;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "vehicleId" INTEGER;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "requestedById" INTEGER;
ALTER TABLE "TransportRequest" ADD COLUMN IF NOT EXISTS "requestedBy" VARCHAR(255);

-- Create Vehicle table
CREATE TABLE IF NOT EXISTS "Vehicle" (
    id SERIAL PRIMARY KEY,
    "licensePlate" VARCHAR(50) UNIQUE NOT NULL,
    "vehicleType" VARCHAR(50) NOT NULL,
    brand VARCHAR(100),
    model VARCHAR(100),
    color VARCHAR(50),
    seats INTEGER DEFAULT 4,
    status VARCHAR(50) DEFAULT 'AVAILABLE',
    "currentKm" INTEGER,
    "registrationExpiry" TIMESTAMP,
    "insuranceExpiry" TIMESTAMP,
    "nextMaintenanceKm" INTEGER,
    "createdAt" TIMESTAMP DEFAULT NOW(),
    "updatedAt" TIMESTAMP DEFAULT NOW()
);

-- Add foreign key constraint
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'TransportRequest_vehicleId_fkey'
    ) THEN
        ALTER TABLE "TransportRequest" 
        ADD CONSTRAINT "TransportRequest_vehicleId_fkey" 
        FOREIGN KEY ("vehicleId") REFERENCES "Vehicle"(id);
    END IF;
END $$;

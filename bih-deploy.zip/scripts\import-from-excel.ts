// Script to import users from Excel file
// Run with: npx ts-node scripts/import-from-excel.ts

import { PrismaClient } from '@prisma/client';
import XLSX from 'xlsx';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// Vietnamese to ASCII conversion for username generation
function removeVietnameseAccents(str: string): string {
    const accents = [
        { base: 'a', letters: 'àáạảãâầấậẩẫăằắặẳẵ' },
        { base: 'e', letters: 'èéẹẻẽêềếệểễ' },
        { base: 'i', letters: 'ìíịỉĩ' },
        { base: 'o', letters: 'òóọỏõôồốộổỗơờớợởỡ' },
        { base: 'u', letters: 'ùúụủũưừứựửữ' },
        { base: 'y', letters: 'ỳýỵỷỹ' },
        { base: 'd', letters: 'đ' },
        { base: 'A', letters: 'ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ' },
        { base: 'E', letters: 'ÈÉẸẺẼÊỀẾỆỂỄ' },
        { base: 'I', letters: 'ÌÍỊỈĨ' },
        { base: 'O', letters: 'ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ' },
        { base: 'U', letters: 'ÙÚỤỦŨƯỪỨỰỬỮ' },
        { base: 'Y', letters: 'ỲÝỴỶỸ' },
        { base: 'D', letters: 'Đ' },
    ];

    let result = str;
    for (const accent of accents) {
        for (const letter of accent.letters) {
            result = result.replace(new RegExp(letter, 'g'), accent.base);
        }
    }
    return result;
}

// Generate username from full name: firstname.lastname
function generateUsername(fullName: string): string {
    const normalized = removeVietnameseAccents(fullName.trim().toLowerCase());
    const parts = normalized.split(/\s+/).filter(Boolean);
    if (parts.length === 0) return 'user';

    // Format: firstname.lastname (e.g., tri.le for "Lê Minh Trí")
    const firstName = parts[parts.length - 1]; // Last word is first name
    const lastName = parts[0]; // First word is last name
    return `${firstName}.${lastName}`;
}

// Determine role and position based on department, gender, and title
function getRoleAndPosition(
    department: string,
    genderCode: string | number,
    title: string
): { role: string; position: string } {
    const deptLower = (department || '').toLowerCase();
    const titleLower = (title || '').toLowerCase();

    // Check if female using genderCode (1 = Female)
    const isFemale = genderCode === 1 || genderCode === '1';

    // Determine position based on title
    let position = 'STAFF';
    if (titleLower.includes('trưởng') || titleLower.includes('truong')) {
        position = 'LEADER';
    } else if (titleLower.includes('giám sát') || titleLower.includes('giam sat')) {
        position = 'SUPERVISOR';
    } else if (titleLower.includes('kỹ sư') || titleLower.includes('ky su')) {
        position = 'LEADER';
    } else if (titleLower.includes('admin')) {
        position = 'LEADER';
    }

    // Determine role based on department
    let role = 'ENVIRONMENT';

    if (deptLower.includes('môi trường') || deptLower.includes('moi truong')) {
        // Environment department - if female, assign to NURSING
        role = isFemale ? 'NURSING' : 'ENVIRONMENT';
    } else if (deptLower.includes('bảo vệ') || deptLower.includes('bao ve')) {
        role = 'SECURITY';
    } else if (deptLower.includes('cung ứng') || deptLower.includes('cung ung')) {
        role = 'SUPPLY';
    } else if (deptLower.includes('lái xe') || deptLower.includes('lai xe')) {
        role = 'DRIVER';
    } else if (deptLower.includes('ktvh') || deptLower.includes('kỹ thuật') || deptLower.includes('ky thuat')) {
        role = 'TECHNICAL';
    }

    return { role, position };
}

async function importFromExcel() {
    // Read Excel file
    const scriptDir = new URL('.', import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1');
    const excelPath = scriptDir.replace(/scripts\/$/, 'cleanup/ttlylich.xlsx');
    console.log('Reading Excel from:', excelPath);

    const workbook = XLSX.readFile(excelPath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data: any[] = XLSX.utils.sheet_to_json(worksheet);

    console.log(`Found ${data.length} rows in Excel file\n`);

    const users: any[] = [];
    const usernameCount: Record<string, number> = {};

    for (const row of data) {
        const fullName = row['HOTEN']?.toString().trim();
        if (!fullName) continue;

        const genderCode = row['PHAI']; // 1 = Female, empty/0 = Male
        const email = row['EMAIL']?.toString().trim();
        const phone = row['DIENTHOAI']?.toString().trim();
        const department = row['TENTO']?.toString().trim();
        const title = row['TENCHUCDANH']?.toString().trim();

        // Generate unique username
        let baseUsername = generateUsername(fullName);
        if (usernameCount[baseUsername]) {
            usernameCount[baseUsername]++;
            baseUsername = `${baseUsername}${usernameCount[baseUsername]}`;
        } else {
            usernameCount[baseUsername] = 1;
        }

        const { role, position } = getRoleAndPosition(department || '', genderCode, title || '');

        // Password is always "1" as requested
        const hashedPassword = await bcrypt.hash('1', 10);

        users.push({
            username: baseUsername,
            password: hashedPassword,
            fullName: fullName,
            email: email || null,
            phoneNumber: phone || null,
            role,
            position,
            _original: {
                department,
                title,
                genderCode,
            }
        });
    }

    console.log(`\n=== IMPORT SUMMARY ===`);
    console.log(`Total users to create: ${users.length}`);

    // Group by role
    const byRole: Record<string, number> = {};
    users.forEach(u => {
        byRole[u.role] = (byRole[u.role] || 0) + 1;
    });
    console.log('\nUsers by role:');
    Object.entries(byRole).forEach(([role, count]) => {
        console.log(`  ${role}: ${count}`);
    });

    // Sample users
    console.log('\n=== SAMPLE USERS (First 10) ===');
    users.slice(0, 10).forEach(u => {
        console.log(`${u.username} | ${u.fullName} | ${u.role} | ${u.position} | Gender: ${u._original.genderCode}`);
    });

    // Delete all existing users first (except admin)
    console.log('\n=== DELETING EXISTING USERS (except admin) ===');

    // First, delete all related records to avoid foreign key constraints
    console.log('Deleting related records...');
    await prisma.inspectionLog.deleteMany({});
    await prisma.maintenanceAssignment.deleteMany({});
    await prisma.ticketComment.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.inventoryTransaction.deleteMany({});
    await prisma.fuelLog.deleteMany({});
    await prisma.wasteCollectionLog.deleteMany({});
    await prisma.landscapeTask.deleteMany({});
    await prisma.patientTransport.deleteMany({});
    await prisma.linenExchange.deleteMany({});

    console.log('Deleting users...');
    const deleted = await prisma.user.deleteMany({
        where: {
            username: { not: 'admin' }
        }
    });
    console.log(`Deleted ${deleted.count} existing users`);

    // Create users in database
    console.log('\n=== CREATING USERS ===');
    let created = 0;
    let errors = 0;

    for (const user of users) {
        try {
            await prisma.user.create({
                data: {
                    username: user.username,
                    password: user.password,
                    fullName: user.fullName,
                    email: user.email,
                    phoneNumber: user.phoneNumber,
                    role: user.role,
                    position: user.position,
                }
            });
            console.log(`✓ ${user.username} -> ${user.role}/${user.position}`);
            created++;
        } catch (error: any) {
            console.error(`✗ ${user.username} - ${error.message}`);
            errors++;
        }
    }

    console.log(`\n=== DONE ===`);
    console.log(`Created: ${created}`);
    console.log(`Errors: ${errors}`);
    console.log(`\nAll users have password: "1"`);

    // Show final counts
    const counts = await prisma.user.groupBy({
        by: ['role'],
        _count: { id: true }
    });

    console.log('\nFinal user counts by role:');
    counts.forEach(c => {
        console.log(`  ${c.role}: ${c._count.id}`);
    });

    await prisma.$disconnect();
}

importFromExcel().catch(console.error);

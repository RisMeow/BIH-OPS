import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function checkTechnicalAccess() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    const user = session.user as { id: number; role: string; position: string };
    if (user.role !== 'ADMIN' && user.role !== 'TECHNICAL') return null;
    return user;
}

// Helper to calculate next due date based on frequency
function calculateNextDueDate(frequency: string, lastDate: Date = new Date()): Date {
    const next = new Date(lastDate);
    switch (frequency) {
        case 'DAILY':
            next.setDate(next.getDate() + 1);
            break;
        case 'WEEKLY':
            next.setDate(next.getDate() + 7);
            break;
        case 'MONTHLY':
            next.setMonth(next.getMonth() + 1);
            break;
        case 'QUARTERLY':
            next.setMonth(next.getMonth() + 3);
            break;
        case 'YEARLY':
            next.setFullYear(next.getFullYear() + 1);
            break;
        default:
            next.setMonth(next.getMonth() + 1);
    }
    return next;
}

// GET: List all schedules or schedules due soon
export async function GET(request: Request) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const dueSoon = searchParams.get('dueSoon') === 'true';
        const assetId = searchParams.get('assetId');

        const where: any = { isActive: true };

        if (assetId) {
            where.assetId = parseInt(assetId);
        }

        if (dueSoon) {
            const nextWeek = new Date();
            nextWeek.setDate(nextWeek.getDate() + 7);
            where.nextDueAt = { lte: nextWeek };
        }

        const schedules = await prisma.maintenanceSchedule.findMany({
            where,
            include: {
                asset: {
                    select: { id: true, code: true, name: true, location: true, category: true }
                }
            },
            orderBy: { nextDueAt: 'asc' }
        });

        return NextResponse.json(schedules);
    } catch (error) {
        console.error("Fetch schedules error:", error);
        return NextResponse.json({ error: 'Failed to fetch schedules' }, { status: 500 });
    }
}

// POST: Create new maintenance schedule
export async function POST(request: Request) {
    try {
        const user = await checkTechnicalAccess();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== 'ADMIN' && !['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const body = await request.json();
        const { assetId, title, frequency, dayOfWeek, dayOfMonth, monthOfYear, checklistItems, nextDueAt: providedNextDueAt } = body;

        if (!assetId || !title || !frequency) {
            return NextResponse.json({ error: "Missing required fields: assetId, title, frequency" }, { status: 400 });
        }

        // Check asset exists
        const asset = await prisma.asset.findUnique({ where: { id: assetId } });
        if (!asset) {
            return NextResponse.json({ error: "Asset not found" }, { status: 404 });
        }

        const nextDueAt = providedNextDueAt ? new Date(providedNextDueAt) : calculateNextDueDate(frequency);

        const schedule = await prisma.maintenanceSchedule.create({
            data: {
                assetId,
                title,
                frequency,
                dayOfWeek,
                dayOfMonth,
                monthOfYear,
                checklistItems: checklistItems ? JSON.stringify(checklistItems) : null,
                nextDueAt
            },
            include: {
                asset: { select: { id: true, code: true, name: true } }
            }
        });

        return NextResponse.json(schedule, { status: 201 });
    } catch (error) {
        console.error("Create schedule error:", error);
        return NextResponse.json({ error: 'Failed to create schedule' }, { status: 500 });
    }
}

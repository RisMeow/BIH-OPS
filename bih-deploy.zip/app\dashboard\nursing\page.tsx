"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    LayoutGrid, Users, ClipboardList, Search, MapPin,
    CheckCircle2, XCircle, User, History, Building2,
    ChevronRight, MoreVertical, BedDouble, Bath, Armchair,
    Plus, Edit3, Trash2, BrainCircuit, RefreshCw, Save,
    UserPlus, Sparkles, Truck, Shirt, ArrowRightLeft, Scale
} from "lucide-react";
import { clsx } from "clsx";
import { useLanguage } from "@/app/context/LanguageContext";
import { useSession } from "next-auth/react";
import LocationSelector from "@/app/components/LocationSelector";

// --- Data Types ---
interface LocationNode {
    id: string;
    name: string;
    type: string; // 'BLOCK' | 'FLOOR' | 'ROOM' | 'WC' | 'PUBLIC';
    code?: string;
    children?: LocationNode[];
    history?: CheckLog[];
    lastChecked?: string;
    parentId?: string | null;
}

interface Staff {
    id: number;
    name: string;
    role: string;
    avatar?: string;
    passCount: number;
    failCount: number;
    history?: CheckLog[];
}

interface CheckLog {
    id: string;
    timestamp: string;
    cleanerName: string;
    locationName: string;
    status: 'PASS' | 'FAIL';
    note?: string;
}

interface SmartTask {
    id: string;
    locationId?: string;
    locationName: string;
    reason: 'HISTORY_FAIL' | 'RANDOM' | 'LONG_TIME';
    status: 'PENDING' | 'DONE';
}

interface TransportRequest {
    id: number;
    patientName: string;
    fromLocation: string;
    toLocation: string;
    transportMode: string;
    priority: string;
    status: string;
    requestedAt: string;
    assignedTo?: { id: number; fullName: string };
}

interface NursingRequest {
    id: number;
    roomNumber: string;
    requestType: string;
    description?: string;
    priority: string;
    status: string;
    createdAt: string;
    assignedTo?: { id: number; fullName: string };
}

interface LinenLog {
    id: number;
    location: string;
    type: string;
    items: string; // JSON string
    totalWeight?: number;
    handledBy?: { fullName: string };
    createdAt: string;
    notes?: string;
}

export default function OrderlyDashboard() {
    const { t } = useLanguage();
    const { data: session } = useSession(); // Get session
    const [activeTab, setActiveTab] = useState<'LOCATIONS' | 'STAFF' | 'REQUESTS' | 'AUDIT' | 'LINEN'>('LOCATIONS');

    // State for Data
    const [locations, setLocations] = useState<LocationNode[]>([]);
    const [staffList, setStaffList] = useState<Staff[]>([]);
    const [smartTasks, setSmartTasks] = useState<SmartTask[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    // Selection State
    const [selectedLocation, setSelectedLocation] = useState<LocationNode | null>(null);
    const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);

    // Modal State
    const [isEditLocModalOpen, setIsEditLocModalOpen] = useState(false);
    const [locFormData, setLocFormData] = useState({ id: '', name: '', code: '', type: 'ROOM', parentId: '' });

    const [isAddStaffModalOpen, setIsAddStaffModalOpen] = useState(false);
    const [staffFormData, setStaffFormData] = useState({ fullName: '', username: '', password: '123', position: 'STAFF' });

    // Inspection Modal
    const [isInspectModalOpen, setIsInspectModalOpen] = useState(false);
    const [inspectData, setInspectData] = useState({ taskId: '', locationId: '', inspectorId: '', status: 'PASS', note: '' });

    // Transport & Linen State
    const [transportRequests, setTransportRequests] = useState<TransportRequest[]>([]);
    const [nursingRequests, setNursingRequests] = useState<NursingRequest[]>([]);
    const [linenLogs, setLinenLogs] = useState<LinenLog[]>([]);

    const [isTransportModalOpen, setIsTransportModalOpen] = useState(false);
    const [transportFormData, setTransportFormData] = useState({ patientName: '', fromLocation: '', toLocation: '', transportMode: 'WHEELCHAIR', priority: 'NORMAL', notes: '' });

    const [isLinenModalOpen, setIsLinenModalOpen] = useState(false);
    const [linenFormData, setLinenFormData] = useState({ location: '', type: 'CLEAN_IN', items: '', totalWeight: '', notes: '' });

    // --- FETCH DATA ---
    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [locRes, staffRes] = await Promise.all([
                fetch('/api/orderly/locations'),
                fetch('/api/orderly/staff')
            ]);

            if (locRes.ok) {
                const locData = await locRes.json();
                setLocations(locData);
            }
            if (staffRes.ok) {
                const staffData = await staffRes.json();
                setStaffList(staffData);
            }
        } catch (error) {
            console.error("Failed to load data", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    // --- LOGIC: Fetch Tasks ---
    const fetchTasks = async () => {
        try {
            const res = await fetch('/api/orderly/tasks');
            if (res.ok) {
                const data = await res.json();
                setSmartTasks(data);
            }
        } catch (e) {
            console.error(e);
        }
    };

    // --- LOGIC: Smart Audit Algorithm ---
    const generateSmartTasks = async () => {
        try {
            const res = await fetch('/api/orderly/tasks', { method: 'POST' });
            if (res.ok) {
                fetchTasks();
            }
        } catch (e) {
            console.error(e);
        }
    };

    useEffect(() => {
        if (activeTab === 'AUDIT') {
            fetchTasks();
        } else if (activeTab === 'REQUESTS') {
            fetchTransportRequests();
        } else if (activeTab === 'LINEN') {
            fetchLinenLogs();
        }
    }, [activeTab]);

    const fetchTransportRequests = async () => {
        try {
            const res = await fetch('/api/nursing/transport');
            if (res.ok) setTransportRequests(await res.json());

            const resGeneric = await fetch('/api/nursing/requests');
            if (resGeneric.ok) setNursingRequests(await resGeneric.json());
        } catch (e) { console.error(e); }
    };

    const fetchLinenLogs = async () => {
        try {
            const res = await fetch('/api/nursing/linen');
            if (res.ok) setLinenLogs(await res.json());
        } catch (e) { console.error(e); }
    };

    const handleCreateTransport = async () => {
        // Validation
        if (!transportFormData.patientName || !transportFormData.fromLocation || !transportFormData.toLocation) {
            showToast("Vui lòng điền đầy đủ Tên, Nơi đón, Nơi đến", 'error');
            return;
        }

        try {
            const res = await fetch('/api/nursing/transport', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(transportFormData)
            });
            if (res.ok) {
                fetchTransportRequests();
                setIsTransportModalOpen(false);
                setTransportFormData({ patientName: '', fromLocation: '', toLocation: '', transportMode: 'WHEELCHAIR', priority: 'NORMAL', notes: '' });
                showToast("Tạo yêu cầu thành công!", 'success');
            } else {
                const err = await res.json();
                showToast(err.error || "Có lỗi xảy ra", 'error');
            }
        } catch (e) {
            console.error(e);
            showToast("Lỗi kết nối", 'error');
        }
    };

    const handleCreateLinen = async () => {
        try {
            const res = await fetch('/api/nursing/linen', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...linenFormData,
                    items: JSON.parse(linenFormData.items || '[]') // Assume user enters valid JSON or manage via UI helper
                })
            });
            if (res.ok) {
                fetchLinenLogs();
                setIsLinenModalOpen(false);
                setLinenFormData({ location: '', type: 'CLEAN_IN', items: '', totalWeight: '', notes: '' });
            }
        } catch (e) {
            console.error(e);
            alert("Lỗi tạo phiếu đồ vải. Kiểm tra format JSON items.");
        }
    };

    // --- Toast & Confirm State ---
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info'; show: boolean }>({ message: '', type: 'info', show: false });
    const [confirmModal, setConfirmModal] = useState<{ show: boolean; title: string; message: string; onConfirm: () => void }>({ show: false, title: '', message: '', onConfirm: () => { } });

    const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
        setToast({ message, type, show: true });
        setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
    };

    const handleUpdateTransport = async (id: number, updates: any) => {
        try {
            const res = await fetch('/api/nursing/transport', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, ...updates })
            });
            if (res.ok) {
                fetchTransportRequests();
                showToast("Cập nhật thành công!", 'success');
            }
        } catch (e) { console.error(e); }
    };

    const handleUpdateNursingRequest = async (id: number, updates: any) => {
        try {
            const res = await fetch('/api/nursing/requests', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, ...updates })
            });
            if (res.ok) {
                fetchTransportRequests();
                showToast("Cập nhật thành công!", 'success');
            }
        } catch (e) { console.error(e); }
    };

    const handleDeleteGeneric = async (id: number, type: 'transport' | 'general') => {
        setConfirmModal({
            show: true,
            title: "Xóa yêu cầu",
            message: "Bạn có chắc chắn muốn xóa yêu cầu này? Hành động này không thể hoàn tác.",
            onConfirm: async () => {
                try {
                    const endpoint = type === 'transport'
                        ? `/api/nursing/transport?id=${id}`
                        : `/api/nursing/requests?id=${id}`;

                    const res = await fetch(endpoint, { method: 'DELETE' });
                    if (res.ok) {
                        fetchTransportRequests();
                        showToast("Đã xóa yêu cầu", 'success');
                    }
                } catch (e) {
                    console.error(e);
                    showToast("Lỗi khi xóa", 'error');
                }
                setConfirmModal(prev => ({ ...prev, show: false }));
            }
        });
    };

    const handleDeleteTransport = async (id: number) => {
        handleDeleteGeneric(id, 'transport');
    };

    // --- LOGIC: Inspection ---
    const openInspectModal = (task: SmartTask) => {
        const defaultInspector = staffList.length > 0 ? staffList[0].id : 1;

        setInspectData({
            taskId: task.id,
            locationId: task.locationId || '',
            inspectorId: defaultInspector.toString(),
            status: 'PASS',
            note: ''
        });
        setIsInspectModalOpen(true);
    };

    const handleSaveInspection = async () => {
        try {
            const res = await fetch('/api/orderly/inspections', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(inspectData)
            });
            if (res.ok) {
                setIsInspectModalOpen(false);
                fetchTasks();
                fetchData();
            }
        } catch (e) {
            console.error(e);
        }
    };

    useEffect(() => {
        if (activeTab === 'AUDIT' && smartTasks.length === 0) {
            generateSmartTasks();
        }
    }, [activeTab]);

    // --- LOGIC: CRUD ---
    const handleSaveLocation = async () => {
        try {
            if (!locFormData.id) {
                const res = await fetch('/api/orderly/locations', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: locFormData.name,
                        code: locFormData.code,
                        type: locFormData.type,
                        parentId: locFormData.parentId || null
                    })
                });
                if (res.ok) {
                    fetchData();
                    setIsEditLocModalOpen(false);
                }
            } else {
                const res = await fetch(`/api/orderly/locations/${locFormData.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: locFormData.name,
                        code: locFormData.code,
                        type: locFormData.type
                    })
                });
                if (res.ok) {
                    fetchData();
                    setIsEditLocModalOpen(false);
                } else {
                    alert("Có lỗi khi cập nhật.");
                }
            }
        } catch (e) {
            console.error(e);
            alert("Lỗi kết nối.");
        }
    };



    const handleDeleteLocation = async (id: string, name: string) => {
        if (!confirm(`Bạn có chắc chắn muốn xóa vị trí "${name}"? Hành động này không thể hoàn tác.`)) return;

        try {
            const res = await fetch(`/api/orderly/locations/${id}`, {
                method: 'DELETE',
            });

            if (res.ok) {
                alert("Đã xóa vị trí thành công.");
                setSelectedLocation(null);
                fetchData();
            } else {
                const data = await res.json();
                alert(`Không thể xóa: ${data.error || 'Lỗi không xác định'}`);
            }
        } catch (e) {
            console.error("Failed to delete", e);
            alert("Lỗi kết nối khi xóa.");
        }
    };

    const handleCreateStaff = async () => {
        try {
            const res = await fetch('/api/orderly/staff', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(staffFormData)
            });
            if (res.ok) {
                fetchData();
                setIsAddStaffModalOpen(false);
                setStaffFormData({ fullName: '', username: '', password: '123', position: 'STAFF' });
            }
        } catch (e) {
            console.error(e);
        }
    };

    const openAddLocation = () => {
        setLocFormData({ id: '', name: '', code: '', type: 'ROOM', parentId: selectedLocation?.id || '' });
        setIsEditLocModalOpen(true);
    };

    const openEditLoc = () => {
        if (selectedLocation) {
            setLocFormData({ id: selectedLocation.id, name: selectedLocation.name, code: selectedLocation.code || '', type: selectedLocation.type, parentId: '' });
            setIsEditLocModalOpen(true);
        }
    };

    const openAddStaff = () => {
        setStaffFormData({ fullName: '', username: '', password: '123', position: 'STAFF' });
        setIsAddStaffModalOpen(true);
    }

    // Helper to render icons based on type
    const getLocationIcon = (type: string) => {
        switch (type) {
            case 'ROOM': return <BedDouble size={16} className="text-blue-500" />;
            case 'WC': return <Bath size={16} className="text-cyan-500" />;
            case 'PUBLIC': return <Armchair size={16} className="text-orange-500" />;
            case 'BLOCK': return <Building2 size={16} className="text-slate-500" />;
            default: return <MapPin size={16} />;
        }
    };

    // Recursive Location Tree Renderer
    const renderLocationTree = (nodes: LocationNode[], level = 0) => {
        return nodes.map(node => (
            <div key={node.id}>
                <div
                    onClick={() => {
                        setSelectedLocation(node);
                    }}
                    className={clsx(
                        "flex items-center gap-2 py-2 px-3 border-b border-slate-50 cursor-pointer hover:bg-slate-50 transition-colors",
                        selectedLocation?.id === node.id && "bg-blue-50 text-blue-700 font-medium",
                        level > 0 && "ml-4 border-l border-slate-100"
                    )}
                >
                    {getLocationIcon(node.type)}
                    <span className="text-sm">{node.name}</span>
                    {node.code && <span className="text-xs text-slate-400 ml-auto bg-slate-100 px-1.5 py-0.5 rounded">{node.code}</span>}
                </div>
                {node.children && renderLocationTree(node.children, level + 1)}
            </div>
        ));
    };

    if (isLoading && locations.length === 0 && staffList.length === 0) {
        return <div className="h-full flex items-center justify-center text-slate-400">Loading data...</div>;
    }

    return (
        <div className="h-[calc(100vh-8rem)] flex flex-col">
            {/* Header */}
            <div className="mb-4 shrink-0">
                <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center">
                        <Sparkles size={22} />
                    </div>
                    {t.orderly.title}
                </h1>
                <p className="text-slate-500 mt-1">Dọn dẹp vệ sinh & Hỗ trợ vận chuyển bệnh nhân đến phòng mổ</p>
            </div>

            {/* Top Navigation Tabs */}
            <div className="flex gap-4 border-b border-slate-200 mb-4 shrink-0 overflow-x-auto">
                <button onClick={() => setActiveTab('LOCATIONS')} className={clsx("pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap", activeTab === 'LOCATIONS' ? "border-teal-600 text-teal-600" : "border-transparent text-slate-500 hover:text-slate-700")}>
                    <MapPin size={18} /> {t.orderlyManager.tabLocations}
                </button>
                <button onClick={() => setActiveTab('STAFF')} className={clsx("pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap", activeTab === 'STAFF' ? "border-teal-600 text-teal-600" : "border-transparent text-slate-500 hover:text-slate-700")}>
                    <Users size={18} /> {t.orderlyManager.tabStaff}
                </button>
                <button onClick={() => setActiveTab('AUDIT')} className={clsx("pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap", activeTab === 'AUDIT' ? "border-teal-600 text-teal-600" : "border-transparent text-slate-500 hover:text-slate-700")}>
                    <BrainCircuit size={18} /> {t.orderlyManager.tabAudit}
                </button>
                <button onClick={() => setActiveTab('REQUESTS')} className={clsx("pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap", activeTab === 'REQUESTS' ? "border-teal-600 text-teal-600" : "border-transparent text-slate-500 hover:text-slate-700")}>
                    <Truck size={18} /> {t.orderlyManager?.tabRequests || "Vận chuyển"}
                </button>
                <button onClick={() => setActiveTab('LINEN')} className={clsx("pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap", activeTab === 'LINEN' ? "border-teal-600 text-teal-600" : "border-transparent text-slate-500 hover:text-slate-700")}>
                    <Shirt size={18} /> Quản lý Đồ vải
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-hidden relative">

                {/* --- TAB 1: LOCATIONS --- */}
                {activeTab === 'LOCATIONS' && (
                    <div className="flex h-full gap-6">
                        {/* Sidebar: Tree */}
                        <div className="w-1/3 min-w-[280px] bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                            <div className="p-3 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
                                <div className="relative flex-1">
                                    <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
                                    <input className="w-full pl-9 pr-4 py-2 text-sm border rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20" placeholder={t.orderlyManager.searchLocation} />
                                </div>
                                <button onClick={openAddLocation} className="p-2 bg-teal-600 text-white rounded-xl shadow-lg shadow-teal-500/20 hover:bg-teal-700" title={t.orderlyManager.addLocation}>
                                    <Plus size={18} />
                                </button>
                            </div>
                            <div className="overflow-y-auto flex-1 p-2">
                                {locations.length > 0 ? renderLocationTree(locations) : <div className="text-center text-sm text-slate-400 mt-4">Chưa có dữ liệu vị trí</div>}
                            </div>
                        </div>

                        {/* Main: Details */}
                        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                            {selectedLocation ? (
                                <>
                                    <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
                                        <div>
                                            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                                                {selectedLocation.name}
                                                <span className="text-sm font-semibold bg-teal-100 text-teal-700 px-2 py-0.5 rounded-md">{selectedLocation.code}</span>
                                            </h2>
                                            <div className="flex gap-4 mt-2 text-sm text-slate-500">
                                                <span><strong className="text-slate-700">{t.orderlyManager.locationType}:</strong> {selectedLocation.type}</span>
                                                {selectedLocation.lastChecked && <span><strong className="text-slate-700">Check cuối:</strong> {selectedLocation.lastChecked}</span>}
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            {session?.user?.role === 'ADMIN' && (
                                                <button
                                                    onClick={() => selectedLocation && handleDeleteLocation(selectedLocation.id, selectedLocation.name)}
                                                    className="flex items-center gap-2 px-3 py-2 bg-red-100 text-red-600 font-semibold rounded-xl hover:bg-red-200 transition-colors"
                                                    title="Xóa vị trí (Chỉ Admin)"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            )}
                                            <button onClick={openEditLoc} className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-600 font-semibold rounded-xl hover:bg-slate-200 transition-colors">
                                                <Edit3 size={18} /> {t.common.edit}
                                            </button>
                                        </div>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30">
                                        <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
                                            <History size={18} /> {t.orderlyManager.historyTitle}
                                            <span className="text-xs bg-slate-200 px-2 py-0.5 rounded-full text-slate-600">0</span>
                                        </h3>
                                        <div className="flex flex-col items-center justify-center p-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                                            <History size={32} className="mb-2 opacity-50" />
                                            <p>Chưa có dữ liệu lịch sử kiểm tra.</p>
                                        </div>
                                    </div>
                                </>
                            ) : (
                                <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                                    <MapPin size={48} className="mb-4 text-slate-200" />
                                    <p>Chọn một vị trí để xem chi tiết</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* --- TAB 2: STAFF --- */}
                {activeTab === 'STAFF' && (
                    <div className="flex h-full gap-6">
                        {/* Staff List */}
                        <div className="w-1/3 min-w-[300px] flex flex-col gap-4">
                            <div className="relative shrink-0 flex gap-2">
                                <div className="relative flex-1">
                                    <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
                                    <input className="w-full pl-9 pr-4 py-2 text-sm border rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20" placeholder={t.orderlyManager.searchStaff} />
                                </div>
                                <button onClick={openAddStaff} className="p-2 bg-teal-600 text-white rounded-xl shadow-lg shadow-teal-500/20 hover:bg-teal-700">
                                    <UserPlus size={18} />
                                </button>
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                                {staffList.map(staff => (
                                    <div
                                        key={staff.id}
                                        onClick={() => setSelectedStaff(staff)}
                                        className={clsx(
                                            "bg-white p-4 rounded-xl border shadow-sm cursor-pointer transition-all hover:shadow-md flex items-center gap-4",
                                            selectedStaff?.id === staff.id ? "border-teal-500 ring-1 ring-teal-500" : "border-slate-100"
                                        )}
                                    >
                                        <img src={staff.avatar} alt={staff.name} className="w-12 h-12 rounded-full object-cover" />
                                        <div className="min-w-0 flex-1">
                                            <h4 className="font-bold text-slate-800 text-sm truncate">{staff.name}</h4>
                                            <p className="text-xs text-slate-500">{staff.role}</p>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-emerald-600 font-bold text-sm">{staff.passCount}</div>
                                            <div className="text-[10px] text-slate-400 text-uppercase">Đạt</div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Staff Detail */}
                        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                            {selectedStaff ? (
                                <div className="flex flex-col h-full">
                                    <div className="p-8 flex items-center justify-between border-b border-slate-100 bg-slate-50/50">
                                        <div className="flex items-center gap-6">
                                            <img src={selectedStaff.avatar} alt={selectedStaff.name} className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg" />
                                            <div>
                                                <h2 className="text-2xl font-bold text-slate-900">{selectedStaff.name}</h2>
                                                <p className="text-slate-500 font-medium">{selectedStaff.role}</p>
                                                <div className="flex gap-4 mt-4">
                                                    <div className="flex items-center gap-2">
                                                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                                                        <span className="text-sm font-bold text-slate-700">{selectedStaff.passCount} Đạt</span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <span className="w-2 h-2 rounded-full bg-red-500"></span>
                                                        <span className="text-sm font-bold text-slate-700">{selectedStaff.failCount} Không đạt</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-600 font-semibold rounded-xl hover:bg-slate-200 transition-colors">
                                            <Edit3 size={18} /> {t.orderlyManager.editStaff}
                                        </button>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-6">
                                        <h3 className="font-bold text-slate-700 mb-4">{t.orderlyManager.workHistory}</h3>
                                        <div className="flex flex-col items-center justify-center p-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                                            <History size={32} className="mb-2 opacity-50" />
                                            <p>Chưa có dữ liệu công việc.</p>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                                    <User size={48} className="mb-4 text-slate-200" />
                                    <p>Chọn nhân viên để xem hồ sơ</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* --- TAB 3: AUDIT (Smart Supervisor Tasks) --- */}
                {activeTab === 'AUDIT' && (
                    <div className="max-w-4xl mx-auto py-8">
                        <div className="bg-gradient-to-br from-teal-600 to-emerald-600 rounded-3xl p-8 text-white shadow-2xl mb-8 relative overflow-hidden">
                            <div className="relative z-10">
                                <h1 className="text-3xl font-bold mb-2">{t.orderlyManager.smartTaskTitle}</h1>
                                <p className="text-teal-100 mb-6">{t.orderlyManager.smartTaskSubtitle}</p>
                                <button onClick={generateSmartTasks} className="bg-white text-teal-600 px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-teal-50 transition-colors flex items-center gap-2">
                                    <RefreshCw size={18} /> {t.orderlyManager.btnGenerateTasks}
                                </button>
                            </div>
                            <BrainCircuit size={200} className="absolute -right-10 -bottom-10 opacity-10" />
                        </div>

                        <div className="space-y-4">
                            {smartTasks.map((task, idx) => (
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.1 }}
                                    key={task.id}
                                    className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition-all"
                                >
                                    <div className="flex items-center gap-4">
                                        <div className={clsx("w-12 h-12 rounded-xl flex items-center justify-center font-bold text-white shadow-lg",
                                            task.reason === 'HISTORY_FAIL' ? "bg-red-500" : task.reason === 'LONG_TIME' ? "bg-amber-500" : "bg-teal-500"
                                        )}>
                                            {task.reason === 'HISTORY_FAIL' ? "!" : idx + 1}
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-lg text-slate-800">{task.locationName}</h3>
                                            <p className="text-sm font-medium text-slate-500 flex items-center gap-2">
                                                Lý do:
                                                <span className={clsx("px-2 py-0.5 rounded text-xs font-bold uppercase",
                                                    task.reason === 'HISTORY_FAIL' ? "bg-red-100 text-red-600" : task.reason === 'LONG_TIME' ? "bg-amber-100 text-amber-600" : "bg-teal-100 text-teal-600"
                                                )}>
                                                    {task.reason === 'HISTORY_FAIL' ? t.orderlyManager.reasonFail : task.reason === 'LONG_TIME' ? t.orderlyManager.reasonOld : t.orderlyManager.reasonRandom}
                                                </span>
                                            </p>
                                        </div>
                                    </div>
                                    <button onClick={() => openInspectModal(task as any)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-colors">
                                        Tiến hành kiểm tra
                                    </button>
                                </motion.div>
                            ))}
                            {smartTasks.length === 0 && (
                                <div className="text-center py-10 text-slate-400">
                                    Hiện chưa có nhiệm vụ nào. Nhấn nút trên để tạo nhiệm vụ mới.
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* --- TAB 4: REQUESTS (Patient Transport & Support) --- */}
                {activeTab === 'REQUESTS' && (
                    <div className="flex h-full gap-6">
                        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                                <h3 className="font-bold text-slate-700 flex items-center gap-2"><Truck size={20} /> Vận chuyển người bệnh & Hỗ trợ</h3>
                                <button onClick={() => setIsTransportModalOpen(true)} className="px-4 py-2 bg-teal-600 text-white rounded-xl shadow hover:bg-teal-700 flex items-center gap-2">
                                    <Plus size={18} /> Tạo yêu cầu
                                </button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                                {transportRequests.map(req => (
                                    <div key={`trans-${req.id}`} className={clsx(
                                        "bg-white p-4 rounded-xl border shadow-sm flex items-center justify-between hover:shadow-md transition-all",
                                        req.status === 'COMPLETED' ? "border-emerald-100 bg-emerald-50/30" : "border-slate-100"
                                    )}>
                                        <div className="flex items-center gap-4 flex-1">
                                            <div className={clsx("w-12 h-12 rounded-full flex items-center justify-center shrink-0",
                                                req.status === 'COMPLETED' ? "bg-emerald-100 text-emerald-600" : "bg-blue-50 text-blue-600"
                                            )}>
                                                {req.status === 'COMPLETED' ? <CheckCircle2 size={24} /> : <User size={24} />}
                                            </div>
                                            <div className="min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <h4 className="font-bold text-slate-800 text-lg">{req.patientName || "Bệnh nhân"} (Vận chuyển)</h4>
                                                    <span className={clsx("px-2 py-0.5 rounded text-xs font-bold uppercase",
                                                        req.priority === 'URGENT' ? "bg-red-100 text-red-600" : "bg-slate-100 text-slate-600"
                                                    )}>{req.priority}</span>
                                                    {req.status === 'COMPLETED' && <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded font-bold">Hoàn thành</span>}
                                                </div>
                                                <div className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                                                    <span className="font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1"><MapPin size={12} /> {req.fromLocation}</span>
                                                    <ArrowRightLeft size={14} className="text-slate-300" />
                                                    <span className="font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1"><MapPin size={12} /> {req.toLocation}</span>
                                                    <span className="text-slate-400">|</span>
                                                    <span>{req.transportMode}</span>
                                                </div>
                                                <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                                                    <History size={12} /> {new Date(req.requestedAt).toLocaleString('en-GB')}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-4 pl-4 border-l border-slate-100 ml-4">
                                            <div className="flex flex-col items-end">
                                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Người thực hiện</label>
                                                <select
                                                    className="text-sm border border-slate-200 rounded-lg p-1.5 min-w-[150px] outline-none focus:ring-2 focus:ring-teal-500/20 bg-white"
                                                    value={req.assignedTo?.id || ""}
                                                    onChange={(e) => {
                                                        const staff = staffList.find(s => s.id.toString() === e.target.value);
                                                        if (staff) handleUpdateTransport(req.id, { assignedToId: staff.id });
                                                    }}
                                                >
                                                    <option value="">-- Chưa phân công --</option>
                                                    {staffList.map(s => (
                                                        <option key={s.id} value={s.id}>{s.name} ({s.passCount} task)</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                {req.status !== 'COMPLETED' ? (
                                                    <button
                                                        onClick={() => handleUpdateTransport(req.id, { status: 'COMPLETED' })}
                                                        className="p-2 bg-emerald-100 text-emerald-600 rounded-lg hover:bg-emerald-200 transition-colors"
                                                        title="Hoàn thành"
                                                    >
                                                        <CheckCircle2 size={18} />
                                                    </button>
                                                ) : (
                                                    <button
                                                        onClick={() => handleUpdateTransport(req.id, { status: 'PENDING' })}
                                                        className="p-2 bg-amber-100 text-amber-600 rounded-lg hover:bg-amber-200 transition-colors"
                                                        title="Mở lại"
                                                    >
                                                        <RefreshCw size={18} />
                                                    </button>
                                                )}
                                                <button
                                                    onClick={() => handleDeleteGeneric(req.id, 'transport')}
                                                    className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                                                    title="Xóa yêu cầu"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                {/* --- General Nursing Requests --- */}
                                {nursingRequests.length > 0 && <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-6 mb-2">Yêu cầu Vệ sinh & Khác</div>}
                                {nursingRequests.map(req => (
                                    <div key={`gen-${req.id}`} className={clsx(
                                        "bg-white p-4 rounded-xl border shadow-sm flex items-center justify-between hover:shadow-md transition-all",
                                        req.status === 'COMPLETED' ? "border-emerald-100 bg-emerald-50/30" : "border-slate-100"
                                    )}>
                                        <div className="flex items-center gap-4 flex-1">
                                            <div className={clsx("w-12 h-12 rounded-full flex items-center justify-center shrink-0",
                                                req.status === 'COMPLETED' ? "bg-emerald-100 text-emerald-600" : "bg-purple-50 text-purple-600"
                                            )}>
                                                {req.status === 'COMPLETED' ? <CheckCircle2 size={24} /> : <Sparkles size={24} />}
                                            </div>
                                            <div className="min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <h4 className="font-bold text-slate-800 text-lg">{req.requestType}</h4>
                                                    <span className={clsx("px-2 py-0.5 rounded text-xs font-bold uppercase",
                                                        req.priority === 'URGENT' ? "bg-red-100 text-red-600" :
                                                            req.priority === 'HIGH' ? "bg-orange-100 text-orange-600" : "bg-slate-100 text-slate-600"
                                                    )}>{req.priority}</span>
                                                    {req.status === 'COMPLETED' && <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded font-bold">Hoàn thành</span>}
                                                </div>
                                                <div className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                                                    <span className="font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1"><MapPin size={12} /> {req.roomNumber}</span>
                                                    {req.description && <span className="text-slate-400">| {req.description}</span>}
                                                </div>
                                                <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                                                    <History size={12} /> {new Date(req.createdAt).toLocaleString('en-GB')}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-4 pl-4 border-l border-slate-100 ml-4">
                                            <div className="flex flex-col items-end">
                                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Người thực hiện</label>
                                                <select
                                                    className="text-sm border border-slate-200 rounded-lg p-1.5 min-w-[150px] outline-none focus:ring-2 focus:ring-teal-500/20 bg-white"
                                                    value={req.assignedTo?.id || ""}
                                                    onChange={(e) => {
                                                        const staff = staffList.find(s => s.id.toString() === e.target.value);
                                                        if (staff) handleUpdateNursingRequest(req.id, { assignedToId: staff.id });
                                                    }}
                                                >
                                                    <option value="">-- Chưa phân công --</option>
                                                    {staffList.map(s => (
                                                        <option key={s.id} value={s.id}>{s.name} ({s.passCount} task)</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                {req.status !== 'COMPLETED' ? (
                                                    <button
                                                        onClick={() => handleUpdateNursingRequest(req.id, { status: 'COMPLETED' })}
                                                        className="p-2 bg-emerald-100 text-emerald-600 rounded-lg hover:bg-emerald-200 transition-colors"
                                                        title="Hoàn thành"
                                                    >
                                                        <CheckCircle2 size={18} />
                                                    </button>
                                                ) : (
                                                    <button
                                                        onClick={() => handleUpdateNursingRequest(req.id, { status: 'PENDING' })}
                                                        className="p-2 bg-amber-100 text-amber-600 rounded-lg hover:bg-amber-200 transition-colors"
                                                        title="Mở lại"
                                                    >
                                                        <RefreshCw size={18} />
                                                    </button>
                                                )}
                                                <button
                                                    onClick={() => handleDeleteGeneric(req.id, 'general')}
                                                    className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                                                    title="Xóa yêu cầu"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                {transportRequests.length === 0 && nursingRequests.length === 0 && <div className="text-center py-10 text-slate-400">Chưa có yêu cầu hỗ trợ nào.</div>}
                            </div>
                        </div>
                    </div>
                )}

                {/* --- TAB 5: LINEN (Laundry) --- */}
                {activeTab === 'LINEN' && (
                    <div className="flex h-full gap-6">
                        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                                <h3 className="font-bold text-slate-700 flex items-center gap-2"><Shirt size={20} /> Giao nhận đồ vải</h3>
                                <button onClick={() => setIsLinenModalOpen(true)} className="px-4 py-2 bg-teal-600 text-white rounded-xl shadow hover:bg-teal-700 flex items-center gap-2">
                                    <Plus size={18} /> Nhập liệu
                                </button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                                {linenLogs.map(log => (
                                    <div key={log.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                                        <div className="flex items-center gap-4">
                                            <div className={clsx("w-12 h-12 rounded-full flex items-center justify-center",
                                                log.type === 'CLEAN_IN' ? "bg-emerald-100 text-emerald-600" : "bg-amber-100 text-amber-600"
                                            )}>
                                                {log.type === 'CLEAN_IN' ? <Sparkles size={20} /> : <Trash2 size={20} />}
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-slate-800">{log.location}</h4>
                                                <p className="text-sm text-slate-500">{log.type === 'CLEAN_IN' ? 'Nhập đồ sạch' : 'Thu gom đồ bẩn'}</p>
                                                <div className="mt-1 text-xs text-slate-700 bg-slate-50 p-1 rounded inline-block">
                                                    {log.items}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className="font-bold text-slate-700">{log.totalWeight} kg</div>
                                            <div className="text-xs text-slate-400">{new Date(log.createdAt).toLocaleString('en-GB')}</div>
                                            <div className="text-xs text-slate-400 mt-1">{log.handledBy?.fullName}</div>
                                        </div>
                                    </div>
                                ))}
                                {linenLogs.length === 0 && <div className="text-center py-10 text-slate-400">Chưa có dữ liệu giao nhận đồ vải.</div>}
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* --- MODALS --- */}
            {/* Transport Request Modal */}
            <AnimatePresence>
                {isTransportModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                            <h3 className="font-bold text-lg mb-4">Tạo yêu cầu Vận chuyển</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-500 mb-1 block">Tên bệnh nhân <span className="text-red-500">*</span></label>
                                    <input value={transportFormData.patientName} onChange={e => setTransportFormData({ ...transportFormData, patientName: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl outline-none focus:border-teal-500" placeholder="Nhập tên bệnh nhân" />
                                </div>
                                <div className="grid grid-cols-1 gap-3">
                                    <LocationSelector
                                        label="Nơi đón"
                                        value={transportFormData.fromLocation}
                                        onChange={(val) => setTransportFormData({ ...transportFormData, fromLocation: val })}
                                    />
                                    <LocationSelector
                                        label="Nơi đến"
                                        value={transportFormData.toLocation}
                                        onChange={(val) => setTransportFormData({ ...transportFormData, toLocation: val })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="text-xs font-bold text-slate-500 mb-1 block">Phương tiện</label>
                                        <select value={transportFormData.transportMode} onChange={e => setTransportFormData({ ...transportFormData, transportMode: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl outline-none bg-white">
                                            <option value="WHEELCHAIR">Xe đẩy</option>
                                            <option value="STRETCHER">Cáng</option>
                                            <option value="BED">Giường bệnh</option>
                                            <option value="WALK">Đi bộ</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold text-slate-500 mb-1 block">Ưu tiên</label>
                                        <select value={transportFormData.priority} onChange={e => setTransportFormData({ ...transportFormData, priority: e.target.value })} className="w-full p-2.5 border border-slate-200 rounded-xl outline-none bg-white">
                                            <option value="NORMAL">Bình thường</option>
                                            <option value="URGENT">Khẩn cấp</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsTransportModalOpen(false)} className="flex-1 py-2.5 text-slate-500 font-bold bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors">{t.common.cancel}</button>
                                <button onClick={handleCreateTransport} className="flex-1 py-2.5 text-white font-bold bg-teal-600 rounded-xl hover:bg-teal-700 transition-colors shadow-lg shadow-teal-600/20">Gửi yêu cầu</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Linen Modal */}
            <AnimatePresence>
                {isLinenModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                            <h3 className="font-bold text-lg mb-4">Ghi nhận Đồ vải</h3>
                            <div className="space-y-3">
                                <input value={linenFormData.location} onChange={e => setLinenFormData({ ...linenFormData, location: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Khoa/Phòng" />
                                <select value={linenFormData.type} onChange={e => setLinenFormData({ ...linenFormData, type: e.target.value })} className="w-full p-2 border rounded-lg">
                                    <option value="CLEAN_IN">Cấp phát đồ sạch</option>
                                    <option value="DIRTY_OUT">Thu gom đồ bẩn</option>
                                </select>
                                <input value={linenFormData.totalWeight} onChange={e => setLinenFormData({ ...linenFormData, totalWeight: e.target.value })} className="w-full p-2 border rounded-lg" type="number" placeholder="Tổng trọng lượng (kg)" />
                                <div>
                                    <label className="text-xs text-slate-500 block mb-1">Danh sách (JSON mẫu: {"[{\"name\":\"Ga\",\"qty\":5}]"})</label>
                                    <textarea value={linenFormData.items} onChange={e => setLinenFormData({ ...linenFormData, items: e.target.value })} className="w-full p-2 border rounded-lg font-mono text-sm h-20" placeholder='[{"name":"Ga","qty":10}]' />
                                </div>
                            </div>
                            <div className="flex gap-2 mt-4 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsLinenModalOpen(false)} className="flex-1 py-2 text-slate-500 font-bold bg-slate-100 rounded-xl">{t.common.cancel}</button>
                                <button onClick={handleCreateLinen} className="flex-1 py-2 text-white font-bold bg-teal-600 rounded-xl">Lưu phiếu</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
            {/* Edit/Add Location Modal */}
            <AnimatePresence>
                {isEditLocModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                            <h3 className="font-bold text-lg mb-4">{!locFormData.id ? t.orderlyManager.addLocation : t.orderlyManager.editLocation}</h3>
                            <div className="space-y-3">
                                <input value={locFormData.name} onChange={e => setLocFormData({ ...locFormData, name: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Tên vị trí" />
                                <input value={locFormData.code} onChange={e => setLocFormData({ ...locFormData, code: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Mã vị trí (VD: P-101)" />
                                <select value={locFormData.type} onChange={e => setLocFormData({ ...locFormData, type: e.target.value })} className="w-full p-2 border rounded-lg">
                                    <option value="BLOCK">Khu/Tòa nhà</option>
                                    <option value="FLOOR">Tầng</option>
                                    <option value="ROOM">Phòng</option>
                                    <option value="WC">Nhà vệ sinh</option>
                                    <option value="PUBLIC">Công cộng</option>
                                </select>
                            </div>
                            <div className="flex gap-2 mt-4 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsEditLocModalOpen(false)} className="flex-1 py-2 text-slate-500 font-bold bg-slate-100 rounded-xl">{t.common.cancel}</button>
                                <button onClick={handleSaveLocation} className="flex-1 py-2 text-white font-bold bg-teal-600 rounded-xl">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Add Staff Modal */}
            <AnimatePresence>
                {isAddStaffModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                            <h3 className="font-bold text-lg mb-4">{t.orderlyManager.addStaff}</h3>
                            <div className="space-y-3">
                                <input value={staffFormData.fullName} onChange={e => setStaffFormData({ ...staffFormData, fullName: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Họ và tên" />
                                <input value={staffFormData.username} onChange={e => setStaffFormData({ ...staffFormData, username: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Tên đăng nhập" />
                                <input value={staffFormData.password} onChange={e => setStaffFormData({ ...staffFormData, password: e.target.value })} className="w-full p-2 border rounded-lg" type="password" placeholder="Mật khẩu (Default: 123)" />
                                <input value={staffFormData.position} onChange={e => setStaffFormData({ ...staffFormData, position: e.target.value })} className="w-full p-2 border rounded-lg" placeholder="Chức vụ" />
                            </div>
                            <div className="flex gap-2 mt-4 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsAddStaffModalOpen(false)} className="flex-1 py-2 text-slate-500 font-bold bg-slate-100 rounded-xl">{t.common.cancel}</button>
                                <button onClick={handleCreateStaff} className="flex-1 py-2 text-white font-bold bg-teal-600 rounded-xl">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Inspection Modal */}
            <AnimatePresence>
                {isInspectModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
                        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
                            <h3 className="font-bold text-lg mb-4">Kết quả kiểm tra vệ sinh</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-bold text-slate-500 mb-1">Trạng thái</label>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => setInspectData({ ...inspectData, status: 'PASS' })}
                                            className={clsx("flex-1 py-2 rounded-xl font-bold border transition-all", inspectData.status === 'PASS' ? "bg-emerald-500 text-white border-emerald-500" : "bg-white text-slate-400 border-slate-200 hover:bg-emerald-50")}
                                        >
                                            ĐẠT
                                        </button>
                                        <button
                                            onClick={() => setInspectData({ ...inspectData, status: 'FAIL' })}
                                            className={clsx("flex-1 py-2 rounded-xl font-bold border transition-all", inspectData.status === 'FAIL' ? "bg-red-500 text-white border-red-500" : "bg-white text-slate-400 border-slate-200 hover:bg-red-50")}
                                        >
                                            KHÔNG ĐẠT
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-500 mb-1">Ghi chú</label>
                                    <textarea
                                        value={inspectData.note}
                                        onChange={e => setInspectData({ ...inspectData, note: e.target.value })}
                                        className="w-full p-2 border rounded-xl h-24 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                                        placeholder="Nhập ghi chú chi tiết..."
                                    ></textarea>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-500 mb-1">Người kiểm tra</label>
                                    <select
                                        value={inspectData.inspectorId}
                                        onChange={e => setInspectData({ ...inspectData, inspectorId: e.target.value })}
                                        className="w-full p-2 border rounded-xl bg-white"
                                    >
                                        {staffList.map(s => (
                                            <option key={s.id} value={s.id}>{s.name}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                            <div className="flex gap-2 mt-6 pt-4 border-t border-slate-100">
                                <button onClick={() => setIsInspectModalOpen(false)} className="flex-1 py-2 text-slate-500 font-bold bg-slate-100 rounded-xl">{t.common.cancel}</button>
                                <button onClick={handleSaveInspection} className="flex-1 py-2 text-white font-bold bg-teal-600 rounded-xl">{t.common.save}</button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
            {/* --- Global Components --- */}
            {/* Custom Toast */}
            <AnimatePresence>
                {toast.show && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, x: '-50%' }}
                        animate={{ opacity: 1, y: 0, x: '-50%' }}
                        exit={{ opacity: 0, y: 20, x: '-50%' }}
                        className={clsx(
                            "fixed bottom-6 left-1/2 z-50 px-6 py-3 rounded-xl shadow-xl flex items-center gap-3 font-bold border",
                            toast.type === 'success' && "bg-white text-emerald-600 border-emerald-100",
                            toast.type === 'error' && "bg-white text-red-600 border-red-100",
                            toast.type === 'info' && "bg-white text-slate-600 border-slate-100"
                        )}
                    >
                        {toast.type === 'success' && <CheckCircle2 size={20} />}
                        {toast.type === 'error' && <XCircle size={20} />}
                        {toast.message}
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Custom Confirm Modal */}
            <AnimatePresence>
                {confirmModal.show && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden"
                        >
                            <div className="p-6 text-center">
                                <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
                                    <Trash2 className="text-red-500" size={32} />
                                </div>
                                <h3 className="text-xl font-bold text-slate-800 mb-2">{confirmModal.title}</h3>
                                <p className="text-slate-500">{confirmModal.message}</p>
                            </div>
                            <div className="flex border-t border-slate-100 divide-x divide-slate-100 bg-slate-50">
                                <button
                                    onClick={() => setConfirmModal(prev => ({ ...prev, show: false }))}
                                    className="flex-1 py-3 text-slate-600 font-bold hover:bg-slate-100 transition-colors"
                                >
                                    Hủy
                                </button>
                                <button
                                    onClick={confirmModal.onConfirm}
                                    className="flex-1 py-3 text-red-600 font-bold hover:bg-red-50 transition-colors"
                                >
                                    Xóa ngay
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

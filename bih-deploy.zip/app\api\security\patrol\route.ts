import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; fullName: string } | null;
}

// GET: Lấy danh sách nhật ký tuần tra
export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const logs = await prisma.patrolLog.findMany({
            orderBy: { createdAt: 'desc' },
            take: 100 // Giới hạn 100 bản ghi gần nhất
        });
        return NextResponse.json(logs);
    } catch (error) {
        console.error("Fetch PatrolLog Error:", error);
        return NextResponse.json({ error: "Failed to fetch patrol logs" }, { status: 500 });
    }
}

// POST: Tạo bản ghi tuần tra mới (Check-in điểm tuần tra)
export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Chỉ SECURITY mới được check-in tuần tra
        if (user.role !== 'SECURITY' && user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Chỉ nhân viên An ninh mới được ghi nhận tuần tra" }, { status: 403 });
        }

        const body = await request.json();
        const { checkpoint, checkpointCode, status, note, imageUrl } = body;

        if (!checkpoint) {
            return NextResponse.json({ error: "Thiếu thông tin điểm tuần tra" }, { status: 400 });
        }

        const newLog = await prisma.patrolLog.create({
            data: {
                checkpoint,
                checkpointCode: checkpointCode || null,
                status: status || 'NORMAL',
                note: note || null,
                imageUrl: imageUrl || null,
                guardId: user.id,
                guardName: user.fullName
            }
        });

        return NextResponse.json(newLog, { status: 201 });
    } catch (error) {
        console.error("Create PatrolLog Error:", error);
        return NextResponse.json({ error: "Failed to create patrol log" }, { status: 500 });
    }
}

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    const passwordHash = await bcrypt.hash('123456', 10);

    console.log('Clearing old data...');
    await prisma.maintenanceRequest.deleteMany();
    await prisma.nursingRequest.deleteMany();
    // ... delete other requests if needed
    await prisma.user.deleteMany();

    console.log('Seeding hierarchy...');

    // 1. Quản trị hệ thống (Admin)
    const admin = await prisma.user.create({
        data: {
            username: 'admin',
            password: passwordHash,
            fullName: 'Quản trị viên Hệ thống',
            email: 'admin@bih.vn',
            phoneNumber: '0901234567',
            role: 'ADMIN',
            position: 'MANAGER',
        }
    });

    // 2. Kỹ thuật (Technical)
    // 2.1 Tổ trưởng
    const techLead = await prisma.user.create({
        data: {
            username: 'tech_leader',
            password: passwordHash,
            fullName: 'Tổ trưởng Kỹ thuật',
            email: 'tech.lead@bih.vn',
            phoneNumber: '0901111222',
            role: 'TECHNICAL',
            position: 'LEADER',
            managerId: admin.id
        }
    });
    // 2.2 Nhân viên
    await prisma.user.create({
        data: {
            username: 'tech_staff_1',
            password: passwordHash,
            fullName: 'NV Kỹ thuật 1',
            email: 'tech.staff1@bih.vn',
            phoneNumber: '0901111333',
            role: 'TECHNICAL',
            position: 'STAFF',
            managerId: techLead.id
        }
    });

    // 3. Hộ lý (Nursing)
    // 3.1 Tổ trưởng
    const nurseLead = await prisma.user.create({
        data: {
            username: 'nursing_leader',
            password: passwordHash,
            fullName: 'Tổ trưởng Hộ lý',
            email: 'nursing.lead@bih.vn',
            phoneNumber: '0902222111',
            role: 'NURSING',
            position: 'LEADER',
            managerId: admin.id
        }
    });
    // 3.2 Giám sát (2 người)
    const nurseSup1 = await prisma.user.create({
        data: {
            username: 'nursing_sup_1',
            password: passwordHash,
            fullName: 'Giám sát Hộ lý A',
            email: 'nursing.sup1@bih.vn',
            phoneNumber: '0902222222',
            role: 'NURSING',
            position: 'SUPERVISOR',
            managerId: nurseLead.id
        }
    });
    const nurseSup2 = await prisma.user.create({
        data: {
            username: 'nursing_sup_2',
            password: passwordHash,
            fullName: 'Giám sát Hộ lý B',
            email: 'nursing.sup2@bih.vn',
            phoneNumber: '0902222333',
            role: 'NURSING',
            position: 'SUPERVISOR',
            managerId: nurseLead.id
        }
    });
    // 3.3 Nhân viên (Thuộc giám sát 1)
    await prisma.user.create({
        data: {
            username: 'nursing_staff_1',
            password: passwordHash,
            fullName: 'Hộ lý Viên 1',
            email: 'nursing.staff1@bih.vn',
            phoneNumber: '0902222444',
            role: 'NURSING',
            position: 'STAFF',
            managerId: nurseSup1.id
        }
    });

    // 5. Locations (Orderly Module)
    console.log('Seeding locations...');

    // Clear old locations
    await prisma.inspectionLog.deleteMany();
    await prisma.orderlyTask.deleteMany();
    await prisma.location.deleteMany();

    // 5.1 Khu Nội Trú (Block)
    const blockInpatient = await prisma.location.create({
        data: { name: 'Khu Nội Trú', code: 'BLOCK-A', type: 'BLOCK' }
    });

    // 5.2 Tầng 3 (Floor)
    const floor3 = await prisma.location.create({
        data: { name: 'Tầng 3 - Khoa Nội', code: 'F03', type: 'FLOOR', parentId: blockInpatient.id }
    });

    // 5.3 Phòng bệnh (Rooms)
    const room301 = await prisma.location.create({
        data: { name: 'Phòng 301', code: 'P-301', type: 'ROOM', parentId: floor3.id }
    });
    const room302 = await prisma.location.create({
        data: { name: 'Phòng 302', code: 'P-302', type: 'ROOM', parentId: floor3.id }
    });

    // 5.4 WC
    await prisma.location.create({
        data: { name: 'WC Nam Tầng 3', code: 'WC-03-M', type: 'WC', parentId: floor3.id }
    });

    // 5.5 Sảnh Chính (Public)
    const lobby = await prisma.location.create({
        data: { name: 'Sảnh Chính', code: 'LOBBY', type: 'PUBLIC' }
    });


    // 6. Inspection Logs (Sample Data)
    console.log('Seeding inspection logs...');

    // Tạo log kiểm tra mẫu cho Phòng 301
    await prisma.inspectionLog.create({
        data: {
            status: 'PASS',
            locationId: room301.id,
            inspectorId: nurseSup1.id,
            createdAt: new Date(new Date().setDate(new Date().getDate() - 1)) // Hôm qua
        }
    });

    // Tạo log FAIL cho Phòng 302 (để test thuật toán Smart Audit)
    await prisma.inspectionLog.create({
        data: {
            status: 'FAIL',
            note: 'Sàn nhà bẩn, thùng rác đầy',
            locationId: room302.id,
            inspectorId: nurseSup2.id,
            createdAt: new Date(new Date().setDate(new Date().getDate() - 2)) // 2 ngày trước
        }
    });

    console.log('Seeding finished.');
}

main()
    .then(async () => await prisma.$disconnect())
    .catch(async (e) => {
        console.error(e);
        await prisma.$disconnect();
        process.exit(1);
    });

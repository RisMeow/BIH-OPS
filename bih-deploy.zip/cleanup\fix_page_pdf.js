
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // 1. Remove the "In" (Print) button
    // It looks like: 
    // <button onClick={() => window.print()} className="...">
    //     <Printer size={18} /> In
    // </button>
    // I will regex key parts of it.
    const printBtnRegex = /<button onClick=\{\(\) => window\.print\(\)\}[\s\S]*?In\s*<\/button>/;
    if (printBtnRegex.test(content)) {
        content = content.replace(printBtnRegex, '');
        console.log("Print button removed.");
    } else {
        console.log("Print button not found.");
    }

    // 2. Add VAT input to the Create Plan modal
    // Target the specific row of inputs.
    // <input className="flex-[3] p-2 border rounded-lg text-sm" placeholder="Hạng mục" -> This is top row.
    // Bottom row:
    // <input className="flex-1 p-2 border rounded-lg text-sm" placeholder="ĐVT" ... />
    // <input type="number" ... placeholder="SL" ... />
    // <input type="number" ... placeholder="Đơn giá" ... />

    // Original block to replace:
    /*
    <div className="flex gap-2">
        <input className="flex-1 p-2 border rounded-lg text-sm" placeholder="ĐVT" value={item.unit} onChange={e => handleItemChange(idx, 'unit', e.target.value)} />
        <input type="number" className="flex-1 p-2 border rounded-lg text-sm" placeholder="SL" value={item.quantity} onChange={e => handleItemChange(idx, 'quantity', parseFloat(e.target.value))} />
        <input type="number" className="flex-[2] p-2 border rounded-lg text-sm" placeholder="Đơn giá" value={item.unitPrice} onChange={e => handleItemChange(idx, 'unitPrice', parseFloat(e.target.value))} />
    </div>
    */

    const rowRegex = /<div className="flex gap-2">\s*<input className="flex-1 p-2 border rounded-lg text-sm" placeholder="ĐVT" value=\{item\.unit\}[\s\S]*?placeholder="Đơn giá" value=\{item\.unitPrice\} onChange=\{e => handleItemChange\(idx, 'unitPrice', parseFloat\(e\.target\.value\)\)\} \/>\s*<\/div>/;

    const newRow = `<div className="flex gap-2">
                                                        <input className="w-20 p-2 border rounded-lg text-sm" placeholder="ĐVT" value={item.unit} onChange={e => handleItemChange(idx, 'unit', e.target.value)} />
                                                        <input type="number" className="w-20 p-2 border rounded-lg text-sm" placeholder="SL" value={item.quantity} onChange={e => handleItemChange(idx, 'quantity', parseFloat(e.target.value))} />
                                                        <input type="number" className="flex-1 p-2 border rounded-lg text-sm" placeholder="Đơn giá" value={item.unitPrice} onChange={e => handleItemChange(idx, 'unitPrice', parseFloat(e.target.value))} />
                                                        <input type="number" className="w-20 p-2 border rounded-lg text-sm font-bold text-slate-700" placeholder="VAT%" title="VAT %" value={item.vat} onChange={e => handleItemChange(idx, 'vat', parseFloat(e.target.value))} />
                                                    </div>`;

    if (rowRegex.test(content)) {
        content = content.replace(rowRegex, newRow);
        console.log("VAT input added.");
    } else {
        console.log("Item input row not found.");
    }

    fs.writeFileSync(path, content);

} catch (e) {
    console.error("Error:", e);
}

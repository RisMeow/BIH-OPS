"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
    ShieldAlert, Siren, MapPin, Eye, Plus, X, Loader2, Lock, Unlock,
    UserX, AlertTriangle, BadgeAlert, CheckCircle, Clock, Users,
    QrCode, Clipboard, LogIn, LogOut, Car, Phone, Building2, User, Edit, Trash2
} from "lucide-react";
import { clsx } from "clsx";
import Toast, { ToastType } from "@/app/components/Toast";
import ConfirmModal from "@/app/components/ConfirmModal";

// Types
interface SecurityReport {
    id: number;
    location: string;
    incidentType: string;
    description: string;
    severity: string;
    status: string;
    createdAt: string;
    reportedBy?: string;
    assignedTo?: { fullName: string };
}

interface PatrolLog {
    id: number;
    checkpoint: string;
    checkpointCode?: string;
    status: string;
    note?: string;
    guardName: string;
    createdAt: string;
}

interface Visitor {
    id: number;
    fullName: string;
    idNumber?: string;
    company?: string;
    phone?: string;
    purpose: string;
    hostDepartment?: string;
    hostPerson?: string;
    vehicleType?: string;
    vehiclePlate?: string;
    tempCardNumber?: string;
    checkInTime: string;
    checkOutTime?: string;
    status: string;
    createdByName?: string;
}

export default function SecurityDashboard() {
    const { data: session } = useSession();
    const [activeTab, setActiveTab] = useState<'INCIDENTS' | 'PATROL' | 'VISITORS'>('INCIDENTS');

    // Data states
    const [incidents, setIncidents] = useState<SecurityReport[]>([]);
    const [patrolLogs, setPatrolLogs] = useState<PatrolLog[]>([]);
    const [visitors, setVisitors] = useState<Visitor[]>([]);
    const [loading, setLoading] = useState(true);

    // Modal states
    const [isIncidentModalOpen, setIsIncidentModalOpen] = useState(false);
    const [isPatrolModalOpen, setIsPatrolModalOpen] = useState(false);
    const [isVisitorModalOpen, setIsVisitorModalOpen] = useState(false);

    // Forms
    const [incidentForm, setIncidentForm] = useState({
        location: "", incidentType: "SUSPICIOUS", description: "", severity: "LOW"
    });
    const [editingIncidentId, setEditingIncidentId] = useState<number | null>(null);
    const [patrolForm, setPatrolForm] = useState({
        checkpoint: "", checkpointCode: "", status: "NORMAL", note: ""
    });
    const [visitorForm, setVisitorForm] = useState({
        fullName: "", idNumber: "", company: "", phone: "", purpose: "VISIT",
        hostDepartment: "", hostPerson: "", vehicleType: "", vehiclePlate: "", tempCardNumber: ""
    });

    // Global UI
    const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
        message: "", type: 'info', isVisible: false
    });
    const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void; variant: 'danger' | 'info' }>({
        isOpen: false, title: "", message: "", onConfirm: () => { }, variant: 'info'
    });

    const [submitting, setSubmitting] = useState(false);

    const showToast = (message: string, type: ToastType) => {
        setToast({ message, type, isVisible: true });
    };

    // === FETCH DATA ===
    useEffect(() => {
        if (activeTab === 'INCIDENTS') fetchIncidents();
        else if (activeTab === 'PATROL') fetchPatrolLogs();
        else if (activeTab === 'VISITORS') fetchVisitors();
    }, [activeTab]);

    const fetchIncidents = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/security/requests');
            const data = await res.json();
            if (Array.isArray(data)) setIncidents(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const fetchPatrolLogs = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/security/patrol');
            const data = await res.json();
            if (Array.isArray(data)) setPatrolLogs(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const fetchVisitors = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/security/visitors');
            const data = await res.json();
            if (Array.isArray(data)) setVisitors(data);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    // === HANDLERS ===
    const handleSubmitIncident = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const url = editingIncidentId
                ? `/api/security/requests/${editingIncidentId}`
                : '/api/security/requests';

            const method = editingIncidentId ? 'PATCH' : 'POST';

            const body = editingIncidentId
                ? { ...incidentForm }
                : { ...incidentForm, reportedBy: session?.user?.name };

            await fetch(url, {
                method,
                body: JSON.stringify(body),
                headers: { 'Content-Type': 'application/json' }
            });
            setIsIncidentModalOpen(false);
            setIncidentForm({ location: "", incidentType: "SUSPICIOUS", description: "", severity: "LOW" });
            setEditingIncidentId(null);
            fetchIncidents();
            showToast(editingIncidentId ? "Cập nhật yêu cầu thành công" : "Đã tạo yêu cầu mới", 'success');
        } catch (e) {
            console.error(e);
            showToast("Có lỗi xảy ra", 'error');
        }
        finally { setSubmitting(false); }
    };

    const handleEditIncident = (req: SecurityReport) => {
        setIncidentForm({
            location: req.location,
            incidentType: req.incidentType,
            description: req.description,
            severity: req.severity
        });
        setEditingIncidentId(req.id);
        setIsIncidentModalOpen(true);
    };

    const handleDeleteIncident = (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Xóa yêu cầu",
            message: "Bạn có chắc chắn muốn xóa yêu cầu này? Hành động này không thể hoàn tác.",
            variant: 'danger',
            onConfirm: async () => {
                try {
                    await fetch(`/api/security/requests/${id}`, { method: 'DELETE' });
                    fetchIncidents();
                    showToast("Đã xóa yêu cầu", 'success');
                } catch (e) {
                    console.error(e);
                    showToast("Xóa thất bại", 'error');
                }
            }
        });
    };

    const handleApproveIncident = async (id: number) => {
        try {
            await fetch(`/api/security/requests/${id}`, {
                method: 'PATCH',
                body: JSON.stringify({ status: 'APPROVED' }),
                headers: { 'Content-Type': 'application/json' }
            });
            fetchIncidents();
            showToast("Đã duyệt yêu cầu", 'success');
        } catch (e) {
            console.error(e);
            showToast("Có lỗi xảy ra khi duyệt yêu cầu", 'error');
        }
    };

    const handleSubmitPatrol = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await fetch('/api/security/patrol', {
                method: 'POST',
                body: JSON.stringify(patrolForm),
                headers: { 'Content-Type': 'application/json' }
            });
            setIsPatrolModalOpen(false);
            setPatrolForm({ checkpoint: "", checkpointCode: "", status: "NORMAL", note: "" });
            fetchPatrolLogs();
            showToast("Đã ghi nhận tuần tra mới", 'success');
        } catch (e) {
            console.error(e);
            showToast("Có lỗi xảy ra khi ghi nhận tuần tra", 'error');
        }
        finally { setSubmitting(false); }
    };

    const handleSubmitVisitor = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await fetch('/api/security/visitors', {
                method: 'POST',
                body: JSON.stringify(visitorForm),
                headers: { 'Content-Type': 'application/json' }
            });
            setIsVisitorModalOpen(false);
            setVisitorForm({
                fullName: "", idNumber: "", company: "", phone: "", purpose: "VISIT",
                hostDepartment: "", hostPerson: "", vehicleType: "", vehiclePlate: "", tempCardNumber: ""
            });
            fetchVisitors();
            showToast("Đã ghi nhận khách vào", 'success');
        } catch (e) {
            console.error(e);
            showToast("Có lỗi xảy ra khi ghi nhận khách vào", 'error');
        }
        finally { setSubmitting(false); }
    };

    const handleCheckoutVisitor = async (id: number) => {
        try {
            await fetch(`/api/security/visitors/${id}`, { method: 'PATCH' });
            fetchVisitors();
            showToast("Đã checkout khách", 'success');
        } catch (e) {
            console.error(e);
            showToast("Có lỗi xảy ra khi checkout khách", 'error');
        }
    };

    // === HELPERS ===
    const getSeverityColor = (sev: string) => {
        switch (sev) {
            case 'CRITICAL': return 'bg-red-500 text-white';
            case 'HIGH': return 'bg-orange-500 text-white';
            case 'MEDIUM': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-slate-100 text-slate-600';
        }
    };

    const getIncidentIcon = (type: string) => {
        switch (type) {
            case 'THEFT': return UserX;
            case 'FIGHT': return BadgeAlert;
            case 'ACCESS_CONTROL': return Lock;
            default: return AlertTriangle;
        }
    };

    const getIncidentLabel = (type: string) => {
        switch (type) {
            case 'THEFT': return 'Mất cắp / Trộm';
            case 'FIGHT': return 'Gây rối / Xô xát';
            case 'ACCESS_CONTROL': return 'Vi phạm ra vào';
            case 'SUSPICIOUS': return 'Đối tượng khả nghi';
            default: return type;
        }
    };

    const getPurposeLabel = (purpose: string) => {
        switch (purpose) {
            case 'VISIT': return 'Thăm bệnh nhân';
            case 'WORK': return 'Làm việc';
            case 'DELIVERY': return 'Giao hàng';
            case 'CONTRACTOR': return 'Nhà thầu';
            default: return purpose;
        }
    };

    // Stats
    const openIncidents = incidents.filter(i => i.status === 'PENDING' || i.status === 'OPEN').length;
    const todayPatrols = patrolLogs.filter(p =>
        new Date(p.createdAt).toDateString() === new Date().toDateString()
    ).length;
    const currentVisitors = visitors.filter(v => v.status === 'CHECKED_IN').length;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                            <ShieldAlert size={22} />
                        </div>
                        An ninh & Trật tự
                    </h2>
                    <p className="text-slate-500 mt-1">Giám sát và báo cáo sự cố an ninh bệnh viện.</p>
                </div>

                {/* Stats Cards */}
                <div className="flex gap-3">
                    <div className="bg-red-50 border border-red-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-red-600">{openIncidents}</div>
                        <div className="text-[10px] font-bold text-red-500 uppercase">Yêu cầu mở</div>
                    </div>
                    <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-blue-600">{todayPatrols}</div>
                        <div className="text-[10px] font-bold text-blue-500 uppercase">Tuần tra hôm nay</div>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-2 text-center">
                        <div className="text-2xl font-black text-emerald-600">{currentVisitors}</div>
                        <div className="text-[10px] font-bold text-emerald-500 uppercase">Khách đang vào</div>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 border-b border-slate-200">
                <button
                    onClick={() => setActiveTab('INCIDENTS')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'INCIDENTS' ? "border-red-600 text-red-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Siren size={18} /> Yêu cầu An ninh
                </button>
                <button
                    onClick={() => setActiveTab('PATROL')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'PATROL' ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Clipboard size={18} /> Nhật ký tuần tra
                </button>
                <button
                    onClick={() => setActiveTab('VISITORS')}
                    className={clsx(
                        "px-4 py-3 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors",
                        activeTab === 'VISITORS' ? "border-emerald-600 text-emerald-600" : "border-transparent text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Users size={18} /> Khách ra vào
                </button>
            </div>

            {/* === TAB: INCIDENTS === */}
            {activeTab === 'INCIDENTS' && (
                <div>
                    <div className="flex justify-end mb-4">
                        <button
                            onClick={() => {
                                setEditingIncidentId(null);
                                setIncidentForm({ location: "", incidentType: "SUSPICIOUS", description: "", severity: "LOW" });
                                setIsIncidentModalOpen(true);
                            }}
                            className="px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 flex items-center gap-2 font-bold shadow-lg shadow-red-500/30 transition-all"
                        >
                            <Siren size={18} /> Tạo yêu cầu
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <AnimatePresence>
                            {incidents.map((req, idx) => {
                                const Icon = getIncidentIcon(req.incidentType);
                                return (
                                    <motion.div
                                        key={req.id}
                                        initial={{ y: 20, opacity: 0 }}
                                        animate={{ y: 0, opacity: 1 }}
                                        transition={{ delay: idx * 0.05 }}
                                        className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all relative overflow-hidden group"
                                    >
                                        <div className="p-5 pb-12">
                                            {/* Header */}
                                            <div className="flex justify-between items-start mb-3">
                                                <div className="flex items-center gap-2 text-slate-500 font-bold uppercase">
                                                    <MapPin size={16} /> {req.location}
                                                </div>
                                                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    {(req.status === 'PENDING' || req.status === 'OPEN') && (
                                                        <>
                                                            <button
                                                                onClick={() => handleApproveIncident(req.id)}
                                                                className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                                                                title="Duyệt / Tiếp nhận"
                                                            >
                                                                <CheckCircle size={16} />
                                                            </button>
                                                            <button
                                                                onClick={() => handleEditIncident(req)}
                                                                className="p-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                                                                title="Chỉnh sửa"
                                                            >
                                                                <Edit size={16} />
                                                            </button>
                                                        </>
                                                    )}
                                                    <button
                                                        onClick={() => handleDeleteIncident(req.id)}
                                                        className="p-1.5 rounded-lg bg-slate-50 text-slate-400 hover:bg-red-50 hover:text-red-500 transition-colors"
                                                        title="Xóa"
                                                    >
                                                        <Trash2 size={16} />
                                                    </button>
                                                </div>
                                            </div>

                                            {/* Content */}
                                            <div className="mb-4">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <Icon size={20} className="text-slate-800" />
                                                    <h3 className="font-bold text-lg text-slate-900 uppercase">
                                                        {req.incidentType}
                                                    </h3>
                                                </div>
                                                <p className="text-slate-500 font-medium text-sm leading-relaxed">{req.description}</p>
                                            </div>
                                        </div>

                                        {/* Footer */}
                                        <div className="absolute bottom-0 left-0 w-full">
                                            <div className="px-5 py-3 flex justify-between items-center text-xs border-t border-slate-50">
                                                <span className="text-slate-400 font-medium">{new Date(req.createdAt).toLocaleString('en-GB')}</span>
                                                <span className={clsx("font-bold", req.status === 'PENDING' || req.status === 'OPEN' ? "text-red-500" : "text-emerald-500")}>
                                                    {req.status === 'PENDING' || req.status === 'OPEN' ? 'Chờ xử lý' : 'Đã duyệt'}
                                                </span>
                                            </div>
                                            <div className={clsx("h-1 w-full", req.status === 'PENDING' || req.status === 'OPEN' ? 'bg-red-500' : 'bg-emerald-500')} />
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </AnimatePresence>

                        {!loading && incidents.length === 0 && (
                            <div className="col-span-full py-16 text-center border-2 border-dashed border-slate-200 rounded-2xl">
                                <Siren className="mx-auto text-slate-300 mb-3" size={48} />
                                <p className="text-slate-400 font-medium">Hiện không có yêu cầu an ninh nào được ghi nhận.</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* === TAB: PATROL === */}
            {activeTab === 'PATROL' && (
                <div>
                    <div className="flex justify-end mb-4">
                        <button
                            onClick={() => setIsPatrolModalOpen(true)}
                            className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 flex items-center gap-2 font-bold shadow-lg shadow-blue-500/30 transition-all"
                        >
                            <QrCode size={18} /> Check-in điểm tuần tra
                        </button>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                        <table className="w-full">
                            <thead className="bg-slate-50 border-b border-slate-100">
                                <tr>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Điểm tuần tra</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Trạng thái</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Bảo vệ</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Ghi chú</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Thời gian</th>
                                </tr>
                            </thead>
                            <tbody>
                                {patrolLogs.map(log => (
                                    <tr key={log.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <MapPin size={16} className="text-blue-500" />
                                                <span className="font-bold text-slate-700">{log.checkpoint}</span>
                                                {log.checkpointCode && (
                                                    <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">{log.checkpointCode}</span>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={clsx(
                                                "px-2 py-1 rounded-lg text-xs font-bold",
                                                log.status === 'NORMAL' ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                                            )}>
                                                {log.status === 'NORMAL' ? 'Bình thường' : 'Bất thường'}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3 text-sm text-slate-600">{log.guardName}</td>
                                        <td className="px-4 py-3 text-sm text-slate-500">{log.note || '-'}</td>
                                        <td className="px-4 py-3 text-xs text-slate-400">{new Date(log.createdAt).toLocaleString('en-GB')}</td>
                                    </tr>
                                ))}
                                {!loading && patrolLogs.length === 0 && (
                                    <tr>
                                        <td colSpan={5} className="px-4 py-16 text-center text-slate-400">
                                            Chưa có nhật ký tuần tra nào.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* === TAB: VISITORS === */}
            {activeTab === 'VISITORS' && (
                <div>
                    <div className="flex justify-end mb-4">
                        <button
                            onClick={() => setIsVisitorModalOpen(true)}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 flex items-center gap-2 font-bold shadow-lg shadow-emerald-500/30 transition-all"
                        >
                            <LogIn size={18} /> Ghi nhận khách vào
                        </button>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                        <table className="w-full">
                            <thead className="bg-slate-50 border-b border-slate-100">
                                <tr>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Họ tên</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Mục đích</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Gặp ai</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Xe</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Vào lúc</th>
                                    <th className="text-left px-4 py-3 text-xs font-bold text-slate-500 uppercase">Trạng thái</th>
                                    <th className="text-center px-4 py-3 text-xs font-bold text-slate-500 uppercase">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                {visitors.map(v => (
                                    <tr key={v.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-sm">
                                                    {v.fullName.charAt(0)}
                                                </div>
                                                <div>
                                                    <div className="font-bold text-slate-700 text-sm">{v.fullName}</div>
                                                    {v.company && <div className="text-xs text-slate-400">{v.company}</div>}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="px-2 py-1 rounded-lg text-xs font-bold bg-blue-100 text-blue-700">
                                                {getPurposeLabel(v.purpose)}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3 text-sm text-slate-600">
                                            {v.hostPerson || '-'}
                                            {v.hostDepartment && <span className="text-slate-400 text-xs ml-1">({v.hostDepartment})</span>}
                                        </td>
                                        <td className="px-4 py-3 text-sm text-slate-500">
                                            {v.vehiclePlate || '-'}
                                        </td>
                                        <td className="px-4 py-3 text-xs text-slate-400">
                                            {new Date(v.checkInTime).toLocaleString('en-GB')}
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={clsx(
                                                "px-2 py-1 rounded-lg text-xs font-bold",
                                                v.status === 'CHECKED_IN' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
                                            )}>
                                                {v.status === 'CHECKED_IN' ? 'Đang vào' : 'Đã ra'}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3 text-center">
                                            {v.status === 'CHECKED_IN' && (
                                                <button
                                                    onClick={() => handleCheckoutVisitor(v.id)}
                                                    className="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold hover:bg-slate-200 transition-colors flex items-center gap-1 mx-auto"
                                                >
                                                    <LogOut size={14} /> Checkout
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                                {!loading && visitors.length === 0 && (
                                    <tr>
                                        <td colSpan={7} className="px-4 py-16 text-center text-slate-400">
                                            Chưa có khách nào được ghi nhận.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* === MODALS === */}

            {/* Incident Modal */}
            <AnimatePresence>
                {isIncidentModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl"
                        >
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                                    <Siren className="text-red-500" /> {editingIncidentId ? "Cập nhật yêu cầu" : "Tạo yêu cầu mới"}
                                </h3>
                                <button onClick={() => { setIsIncidentModalOpen(false); setEditingIncidentId(null); }} className="text-slate-400 hover:text-red-500"><X size={20} /></button>
                            </div>

                            <form onSubmit={handleSubmitIncident} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Vị trí</label>
                                    <input required className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                                        placeholder="VD: Cổng chính, Khoa A..."
                                        value={incidentForm.location} onChange={e => setIncidentForm({ ...incidentForm, location: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Loại yêu cầu</label>
                                    <select className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white" value={incidentForm.incidentType} onChange={e => setIncidentForm({ ...incidentForm, incidentType: e.target.value })}>
                                        <option value="SUSPICIOUS">Đối tượng khả nghi</option>
                                        <option value="THEFT">Trộm cắp / Mất đồ</option>
                                        <option value="FIGHT">Gây rối / Xô xát</option>
                                        <option value="ACCESS_CONTROL">Vi phạm ra vào</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mức độ nghiêm trọng</label>
                                    <div className="flex gap-2">
                                        {['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(lv => (
                                            <button type="button" key={lv}
                                                onClick={() => setIncidentForm({ ...incidentForm, severity: lv })}
                                                className={clsx("flex-1 py-2 rounded-lg text-[10px] font-bold border transition-all",
                                                    incidentForm.severity === lv ? "bg-slate-800 text-white border-slate-800" : "bg-white text-slate-500 hover:bg-slate-50")}
                                            >
                                                {lv}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mô tả chi tiết</label>
                                    <textarea required className="w-full px-4 py-2 border border-slate-200 rounded-xl" rows={3} placeholder="Mô tả đặc điểm đối tượng, tình huống..." value={incidentForm.description} onChange={e => setIncidentForm({ ...incidentForm, description: e.target.value })}></textarea>
                                </div>
                                <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                                    <button type="button" onClick={() => { setIsIncidentModalOpen(false); setEditingIncidentId(null); }} className="flex-1 py-3 font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200">Hủy</button>
                                    <button type="submit" disabled={submitting} className="flex-1 py-3 font-bold text-white bg-red-600 rounded-xl hover:bg-red-700 shadow-lg shadow-red-500/30 flex items-center justify-center gap-2">
                                        {submitting && <Loader2 className="animate-spin" size={16} />}
                                        {editingIncidentId ? "Cập nhật" : "Gửi yêu cầu"}
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Patrol Modal */}
            <AnimatePresence>
                {isPatrolModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl"
                        >
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                                    <QrCode className="text-blue-500" /> Check-in tuần tra
                                </h3>
                                <button onClick={() => setIsPatrolModalOpen(false)} className="text-slate-400 hover:text-red-500"><X size={20} /></button>
                            </div>

                            <form onSubmit={handleSubmitPatrol} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Điểm tuần tra</label>
                                    <input required className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                        placeholder="VD: Cổng A, Tầng 3, Sảnh chính..."
                                        value={patrolForm.checkpoint} onChange={e => setPatrolForm({ ...patrolForm, checkpoint: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mã điểm (QR/NFC)</label>
                                    <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                        placeholder="VD: CP-001"
                                        value={patrolForm.checkpointCode} onChange={e => setPatrolForm({ ...patrolForm, checkpointCode: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tình trạng</label>
                                    <div className="flex gap-2">
                                        <button type="button"
                                            onClick={() => setPatrolForm({ ...patrolForm, status: 'NORMAL' })}
                                            className={clsx("flex-1 py-2.5 rounded-xl font-bold border transition-all",
                                                patrolForm.status === 'NORMAL' ? "bg-emerald-500 text-white border-emerald-500" : "bg-white text-slate-500 border-slate-200")}
                                        >
                                            <CheckCircle className="inline mr-1" size={16} /> Bình thường
                                        </button>
                                        <button type="button"
                                            onClick={() => setPatrolForm({ ...patrolForm, status: 'ABNORMAL' })}
                                            className={clsx("flex-1 py-2.5 rounded-xl font-bold border transition-all",
                                                patrolForm.status === 'ABNORMAL' ? "bg-red-500 text-white border-red-500" : "bg-white text-slate-500 border-slate-200")}
                                        >
                                            <AlertTriangle className="inline mr-1" size={16} /> Bất thường
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ghi chú</label>
                                    <textarea className="w-full px-4 py-2 border border-slate-200 rounded-xl" rows={2} placeholder="Ghi chú tình trạng nếu có..." value={patrolForm.note} onChange={e => setPatrolForm({ ...patrolForm, note: e.target.value })}></textarea>
                                </div>
                                <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                                    <button type="button" onClick={() => setIsPatrolModalOpen(false)} className="flex-1 py-3 font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200">Hủy</button>
                                    <button type="submit" disabled={submitting} className="flex-1 py-3 font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2">
                                        {submitting && <Loader2 className="animate-spin" size={16} />}
                                        Xác nhận
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Visitor Modal */}
            <AnimatePresence>
                {isVisitorModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-white w-full max-w-lg rounded-2xl p-6 shadow-2xl my-8"
                        >
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                                    <LogIn className="text-emerald-500" /> Ghi nhận khách vào
                                </h3>
                                <button onClick={() => setIsVisitorModalOpen(false)} className="text-slate-400 hover:text-red-500"><X size={20} /></button>
                            </div>

                            <form onSubmit={handleSubmitVisitor} className="space-y-4">
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Họ tên khách *</label>
                                        <input required className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            placeholder="Nhập họ tên đầy đủ"
                                            value={visitorForm.fullName} onChange={e => setVisitorForm({ ...visitorForm, fullName: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CMND/CCCD</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            value={visitorForm.idNumber} onChange={e => setVisitorForm({ ...visitorForm, idNumber: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Điện thoại</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            value={visitorForm.phone} onChange={e => setVisitorForm({ ...visitorForm, phone: e.target.value })}
                                        />
                                    </div>
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Công ty / Đơn vị</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            value={visitorForm.company} onChange={e => setVisitorForm({ ...visitorForm, company: e.target.value })}
                                        />
                                    </div>
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mục đích *</label>
                                        <select className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white" value={visitorForm.purpose} onChange={e => setVisitorForm({ ...visitorForm, purpose: e.target.value })}>
                                            <option value="VISIT">Thăm bệnh nhân</option>
                                            <option value="WORK">Làm việc</option>
                                            <option value="DELIVERY">Giao hàng</option>
                                            <option value="CONTRACTOR">Nhà thầu</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Khoa/Phòng cần gặp</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            value={visitorForm.hostDepartment} onChange={e => setVisitorForm({ ...visitorForm, hostDepartment: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Người cần gặp</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            value={visitorForm.hostPerson} onChange={e => setVisitorForm({ ...visitorForm, hostPerson: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Biển số xe</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            placeholder="VD: 61A-12345"
                                            value={visitorForm.vehiclePlate} onChange={e => setVisitorForm({ ...visitorForm, vehiclePlate: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Số thẻ tạm</label>
                                        <input className="w-full px-4 py-2.5 border border-slate-200 rounded-xl"
                                            placeholder="VD: K001"
                                            value={visitorForm.tempCardNumber} onChange={e => setVisitorForm({ ...visitorForm, tempCardNumber: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                                    <button type="button" onClick={() => setIsVisitorModalOpen(false)} className="flex-1 py-3 font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200">Hủy</button>
                                    <button type="submit" disabled={submitting} className="flex-1 py-3 font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2">
                                        {submitting && <Loader2 className="animate-spin" size={16} />}
                                        Ghi nhận vào
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {loading && (
                <div className="fixed inset-0 bg-white/50 flex items-center justify-center z-30">
                    <Loader2 className="animate-spin text-slate-400" size={32} />
                </div>
            )}

            <Toast
                message={toast.message}
                type={toast.type}
                isVisible={toast.isVisible}
                onClose={() => setToast({ ...toast, isVisible: false })}
            />

            <ConfirmModal
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
                variant={confirmModal.variant}
            />
        </div>
    );
}

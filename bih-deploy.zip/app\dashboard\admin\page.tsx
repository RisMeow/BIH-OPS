"use client";

import { useSession } from "next-auth/react";
import { motion } from "framer-motion";
import {
    Shield, Users, FileText, CheckCircle,
    AlertTriangle, Clock, TrendingUp, DollarSign,
    BarChart2, PieChart, Activity, Download, ChevronDown, Calendar
} from "lucide-react";
import { clsx } from "clsx";
import { useState, useEffect } from "react";

interface DeptStatus {
    id: string;
    name: string;
    pending: number;
    processing: number;
}

interface AdminStats {
    totalRequestsMonth: number;
    completionRate: string;
    totalProcessing: number;
    totalStaff: number;
}

interface ChartData {
    labels: string[];
    data: number[];
    completedData: number[];
    performanceData: number[];
    total: number;
    completed: number;
    filterType: string;
}

type FilterType = 'week' | 'month' | 'quarter' | 'year';

const filterOptions: { value: FilterType; label: string }[] = [
    { value: 'week', label: '7 ngày qua' },
    { value: 'month', label: 'Theo tháng' },
    { value: 'quarter', label: 'Theo quý' },
    { value: 'year', label: 'Cả năm' },
];

const monthOptions = [
    { value: 1, label: 'Tháng 1' },
    { value: 2, label: 'Tháng 2' },
    { value: 3, label: 'Tháng 3' },
    { value: 4, label: 'Tháng 4' },
    { value: 5, label: 'Tháng 5' },
    { value: 6, label: 'Tháng 6' },
    { value: 7, label: 'Tháng 7' },
    { value: 8, label: 'Tháng 8' },
    { value: 9, label: 'Tháng 9' },
    { value: 10, label: 'Tháng 10' },
    { value: 11, label: 'Tháng 11' },
    { value: 12, label: 'Tháng 12' },
];

export default function AdminDashboardPage() {
    const { data: session } = useSession();
    const [isLoading, setIsLoading] = useState(true);
    const [departmentStatus, setDepartmentStatus] = useState<DeptStatus[]>([
        { id: "TECHNICAL", name: "Kỹ Thuật", pending: 0, processing: 0 },
        { id: "NURSING", name: "Hộ Lý", pending: 0, processing: 0 },
        { id: "DRIVER", name: "Đội Xe", pending: 0, processing: 0 },
        { id: "SECURITY", name: "An Ninh", pending: 0, processing: 0 },
        { id: "SUPPLY", name: "Cung Ứng", pending: 0, processing: 0 },
        { id: "ENVIRONMENT", name: "Môi Trường", pending: 0, processing: 0 },
    ]);
    const [statsData, setStatsData] = useState<AdminStats>({
        totalRequestsMonth: 0,
        completionRate: "0%",
        totalProcessing: 0,
        totalStaff: 0
    });

    // Chart State
    const [chartFilter, setChartFilter] = useState<FilterType>('month');
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
    const [chartData, setChartData] = useState<ChartData | null>(null);
    const [chartLoading, setChartLoading] = useState(true);
    const [showFilterDropdown, setShowFilterDropdown] = useState(false);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const res = await fetch('/api/admin/overview');
                if (res.ok) {
                    const data = await res.json();
                    if (data.departments && Array.isArray(data.departments)) {
                        setDepartmentStatus(data.departments);
                    }
                    if (data.stats) {
                        setStatsData(data.stats);
                    }
                }
            } catch (error) {
                console.error("Failed to fetch admin stats", error);
            } finally {
                setIsLoading(false);
            }
        };

        if (session?.user?.role === 'ADMIN') {
            fetchStats();
            const interval = setInterval(fetchStats, 30000);
            return () => clearInterval(interval);
        }
    }, [session]);

    // Fetch Chart Data
    useEffect(() => {
        const fetchChartData = async () => {
            setChartLoading(true);
            try {
                let url = `/api/admin/chart-data?filter=${chartFilter}`;
                if (chartFilter === 'month') {
                    url += `&value=${selectedMonth}`;
                }
                const res = await fetch(url);
                if (res.ok) {
                    const data = await res.json();
                    setChartData(data);
                }
            } catch (error) {
                console.error("Failed to fetch chart data", error);
            } finally {
                setChartLoading(false);
            }
        };

        if (session?.user?.role === 'ADMIN') {
            fetchChartData();
        }
    }, [session, chartFilter, selectedMonth]);

    // Derived stats for the summary cards
    const summaryCards = [
        { label: "Tổng yêu cầu tháng", value: statsData.totalRequestsMonth.toLocaleString(), change: "", icon: FileText, color: "blue" },
        { label: "Tỷ lệ hoàn thành", value: statsData.completionRate, change: "", icon: CheckCircle, color: "emerald" },
        { label: "Sự cố đang xử lý", value: statsData.totalProcessing.toLocaleString(), change: "", icon: AlertTriangle, color: "amber" },
        { label: "Nhân sự hoạt động", value: statsData.totalStaff.toLocaleString(), change: "", icon: Users, color: "purple" },
    ];

    const handleExportCSV = () => {
        const headers = ["Department", "Pending Requests", "Processing Requests"];
        const rows = departmentStatus.map(d => [d.name, d.pending, d.processing]);

        const summaryHeader = ["Metric", "Value"];
        const summaryRows = [
            ["Total Requests (Month)", statsData.totalRequestsMonth],
            ["Completion Rate", statsData.completionRate],
            ["Processing Issues", statsData.totalProcessing],
            ["Active Staff", statsData.totalStaff]
        ];

        const csvContent = [
            summaryHeader.join(","),
            ...summaryRows.map(r => r.join(",")),
            "",
            headers.join(","),
            ...rows.map(r => r.join(","))
        ].join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `bih_report_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const getStatusColor = (pending: number) => {
        if (pending > 10) return "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]";
        if (pending > 5) return "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]";
        return "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]";
    };

    // Calculate max value for chart scaling
    const maxChartValue = chartData ? Math.max(...chartData.data, 1) : 1;

    return (
        <div className="space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                        <Activity className="text-red-500" size={28} />
                        Tổng quan Quản Trị
                    </h1>
                    <p className="text-slate-500">Giám sát hoạt động toàn bệnh viện</p>
                </div>
                <button
                    onClick={handleExportCSV}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
                >
                    <Download size={18} />
                    Xuất báo cáo .CSV
                </button>
            </div>

            {/* Top Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {summaryCards.map((stat, idx) => (
                    <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"
                    >
                        <div className="flex justify-between items-start mb-4">
                            <div className={clsx("p-3 rounded-xl",
                                stat.color === "blue" ? "bg-blue-50 text-blue-600" :
                                    stat.color === "emerald" ? "bg-emerald-50 text-emerald-600" :
                                        stat.color === "amber" ? "bg-amber-50 text-amber-600" :
                                            "bg-purple-50 text-purple-600"
                            )}>
                                <stat.icon size={22} />
                            </div>
                        </div>
                        <h3 className="text-3xl font-bold text-slate-800 mb-1">{stat.value}</h3>
                        <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
                    </motion.div>
                ))}
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                {/* Chart Section - NOW WITH REAL DATA */}
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 }}
                    className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm"
                >
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2">
                            <BarChart2 size={20} className="text-slate-400" />
                            Hiệu suất vận hành
                        </h3>
                        <div className="flex gap-2 relative">
                            {/* Filter Type Dropdown */}
                            <div className="relative">
                                <button
                                    onClick={() => setShowFilterDropdown(!showFilterDropdown)}
                                    className="bg-slate-50 border border-slate-200 text-xs font-bold text-slate-600 rounded-lg px-3 py-1.5 outline-none flex items-center gap-1 hover:bg-slate-100 transition-colors"
                                >
                                    <Calendar size={14} />
                                    {filterOptions.find(f => f.value === chartFilter)?.label}
                                    <ChevronDown size={14} />
                                </button>
                                {showFilterDropdown && (
                                    <div className="absolute right-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-20 min-w-[140px]">
                                        {filterOptions.map(opt => (
                                            <button
                                                key={opt.value}
                                                onClick={() => {
                                                    setChartFilter(opt.value);
                                                    setShowFilterDropdown(false);
                                                }}
                                                className={clsx(
                                                    "w-full text-left px-3 py-2 text-xs font-medium hover:bg-slate-50 transition-colors first:rounded-t-lg last:rounded-b-lg",
                                                    chartFilter === opt.value ? "bg-blue-50 text-blue-600" : "text-slate-600"
                                                )}
                                            >
                                                {opt.label}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Month Selector - Only visible when filter is 'month' */}
                            {chartFilter === 'month' && (
                                <select
                                    value={selectedMonth}
                                    onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                                    className="bg-slate-50 border border-slate-200 text-xs font-bold text-slate-600 rounded-lg px-3 py-1.5 outline-none hover:bg-slate-100 transition-colors cursor-pointer"
                                >
                                    {monthOptions.map(m => (
                                        <option key={m.value} value={m.value}>{m.label}</option>
                                    ))}
                                </select>
                            )}
                        </div>
                    </div>

                    {/* Chart Area */}
                    <div className="h-64 bg-slate-50 rounded-xl border border-dashed border-slate-200 relative overflow-hidden">
                        {chartLoading ? (
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                            </div>
                        ) : chartData && chartData.data.length > 0 ? (
                            <>
                                {/* Bar Chart */}
                                <div className="absolute inset-0 flex items-end justify-between px-4 pb-8 pt-4 gap-2">
                                    {chartData.data.map((value, i) => {
                                        const heightPercent = (value / maxChartValue) * 100;
                                        const isHighest = value === Math.max(...chartData.data);
                                        return (
                                            <div key={i} className="flex-1 flex flex-col items-center group">
                                                {/* Value tooltip */}
                                                <div className="opacity-0 group-hover:opacity-100 transition-opacity mb-1 bg-slate-800 text-white text-[10px] font-bold px-2 py-1 rounded">
                                                    {value} yêu cầu
                                                </div>
                                                {/* Bar */}
                                                <div
                                                    className={clsx(
                                                        "w-full rounded-t-lg transition-all duration-300 cursor-pointer",
                                                        isHighest ? "bg-blue-500" : "bg-blue-400/60",
                                                        "hover:bg-blue-500"
                                                    )}
                                                    style={{ height: `${Math.max(heightPercent, 5)}%` }}
                                                />
                                                {/* Label */}
                                                <span className="text-[10px] text-slate-500 mt-2 font-medium truncate max-w-full">
                                                    {chartData.labels[i]}
                                                </span>
                                            </div>
                                        );
                                    })}
                                </div>
                                {/* Chart Summary */}
                                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm border border-slate-100">
                                    <div className="flex items-center gap-4 text-xs">
                                        <div>
                                            <span className="text-slate-500">Tổng:</span>
                                            <span className="font-bold text-slate-800 ml-1">{chartData.total}</span>
                                        </div>
                                        <div>
                                            <span className="text-slate-500">Hoàn thành:</span>
                                            <span className="font-bold text-emerald-600 ml-1">{chartData.completed}</span>
                                        </div>
                                        <div>
                                            <span className="text-slate-500">Tỷ lệ:</span>
                                            <span className="font-bold text-blue-600 ml-1">
                                                {chartData.total > 0 ? Math.round((chartData.completed / chartData.total) * 100) : 0}%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div className="absolute inset-0 flex items-center justify-center">
                                <p className="text-slate-400 font-medium">Chưa có dữ liệu trong khoảng thời gian này</p>
                            </div>
                        )}
                    </div>
                </motion.div>

                {/* Department Status */}
                <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 }}
                    className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm"
                >
                    <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
                        <PieChart size={20} className="text-slate-400" />
                        Trạng thái các tổ
                    </h3>
                    <div className="space-y-4">
                        {departmentStatus.map((dept, idx) => (
                            <div key={idx} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                                <div className="flex items-center gap-3">
                                    <div className={clsx("w-2 h-2 rounded-full", getStatusColor(dept.pending))} />
                                    <span className="font-bold text-slate-700 text-sm">{dept.name}</span>
                                </div>
                                <div className="flex gap-3 text-xs">
                                    <span className={clsx("font-bold", dept.pending > 0 ? "text-amber-600" : "text-slate-400")}>
                                        {dept.pending} chờ
                                    </span>
                                    <span className="text-blue-600 font-medium">{dept.processing} xử lý</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </motion.div>
            </div>
        </div>
    );
}


// @ts-ignore
import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = params.id;
        const body = await request.json();
        const { name, code, type, description } = body;

        const updatedLocation = await prisma.location.update({
            where: { id },
            data: {
                name,
                code,
                type,
                description
            }
        });

        return NextResponse.json(updatedLocation);
    } catch (error) {
        console.error("Error updating location:", error);
        return NextResponse.json({ error: "Failed to update location" }, { status: 500 });
    }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
    try {
        const session = await getServerSession(authOptions);

        if (!session || session.user.role !== 'ADMIN') {
            return NextResponse.json({ error: "Unauthorized: Admin access required" }, { status: 403 });
        }

        const id = params.id;

        // Check if has children
        const childrenCount = await prisma.location.count({
            where: { parentId: id }
        });

        if (childrenCount > 0) {
            return NextResponse.json({ error: "Cannot delete location with sub-locations." }, { status: 400 });
        }

        await prisma.location.delete({
            where: { id }
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Error deleting location:", error);
        return NextResponse.json({ error: "Failed to delete location" }, { status: 500 });
    }
}

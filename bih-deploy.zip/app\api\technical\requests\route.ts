import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to get current user from session
// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string };
}

export async function GET(request: Request) {
    try {
        const user = await getCurrentUser();

        // Allow viewing for anyone logged in (requests can come from any department)
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const status = searchParams.get('status');

        const whereCondition = status && status !== 'ALL' ? { status } : {};

        const requests = await prisma.maintenanceRequest.findMany({
            where: whereCondition,
            include: {
                // Include both for backward compatibility and new multi-assign
                assignedTo: {
                    select: { id: true, fullName: true }
                },
                assignments: {
                    include: {
                        user: { select: { id: true, fullName: true } }
                    }
                },
                // Include comments for command/reply thread
                comments: {
                    orderBy: { createdAt: 'asc' }
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });

        // Format data matching Frontend Ticket Interface
        const formattedRequests = requests.map(req => {
            // Combine legacy assignedTo and new assignments
            const assignees = req.assignments.map(a => ({
                id: a.user.id,
                name: a.user.fullName,
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(a.user.fullName)}&background=random`
            }));

            // If legacy assignedTo exists but not in assignments, add it (migration support)
            if (req.assignedTo && !assignees.find(a => a.id === req.assignedTo!.id)) {
                assignees.push({
                    id: req.assignedTo.id,
                    name: req.assignedTo.fullName,
                    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(req.assignedTo.fullName)}&background=random`
                });
            }

            return {
                id: req.id,
                title: req.title,
                location: req.location,
                priority: req.priority,
                status: req.status,
                // Assignees list for frontend
                assignees: assignees,
                // Keep single assignedTo for backward compatibility if needed, but frontend should use assignees
                assignedTo: assignees.length > 0 ? assignees[0] : undefined,
                createdAt: req.createdAt.toISOString(),
                description: req.description
            };
        });

        return NextResponse.json(formattedRequests);
    } catch (error) {
        console.error("Error fetching technical requests:", error);
        return NextResponse.json({ error: "Failed to fetch requests" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();

        // Anyone can create a maintenance request (departments submit requests)
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        const { title, location, priority, description, image } = body;

        if (!title || !location) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newRequest = await prisma.maintenanceRequest.create({
            data: {
                title,
                location,
                priority: priority || 'MEDIUM',
                description: description || '',
                image: image || null,
                quantity: parseInt(body.quantity) || 1,
                unit: body.unit || 'Lần',
                status: 'PENDING',
                reportedById: user.id,
                reportedBy: user.fullName
            }
        });

        // NOTIFICATION LOGIC
        // Notify Technical Leaders about new request
        try {
            const leaders = await prisma.user.findMany({
                where: { role: 'TECHNICAL', position: { in: ['LEADER', 'MANAGER'] } },
                select: { id: true }
            });

            const { createNotification } = await import("@/lib/notification"); // Dynamic import to avoid circular dep issues during init

            await Promise.all(leaders.map(leader =>
                createNotification(
                    leader.id,
                    "Yêu cầu sửa chữa mới",
                    `${user.fullName} vừa báo hỏng tại ${location}: ${title}`,
                    "TECHNICAL",
                    newRequest.id,
                    "WARNING"
                )
            ));
        } catch (notifError) {
            console.error("Failed to send notifications", notifError);
        }

        return NextResponse.json(newRequest, { status: 201 });
    } catch (error) {
        console.error("Error creating technical request:", error);
        return NextResponse.json({ error: "Failed to create request" }, { status: 500 });
    }
}

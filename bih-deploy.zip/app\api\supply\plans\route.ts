import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

// Check if user can create procurement plans
function canCreatePlan(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SUPPLY') return true; // Any supply staff can create
    return false;
}

// Check if user can approve plans (Supply Leader)
function canApprovePlan(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SUPPLY' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position)) return true;
    return false;
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Only ADMIN and SUPPLY can view procurement plans
        if (user.role !== 'ADMIN' && user.role !== 'SUPPLY') {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const plans = await prisma.procurementPlan.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                items: true,
                createdBy: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(plans);
    } catch (error) {
        console.error("Fetch Procurement Plans Error:", error);
        return NextResponse.json({ error: "Failed to fetch plans" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (!canCreatePlan(user)) {
            return NextResponse.json({ error: "Permission denied: Only Supply staff can create plans" }, { status: 403 });
        }

        const body = await request.json();
        const { title, description, items, supplierBank } = body;

        if (!title || !items || items.length === 0) {
            return NextResponse.json({ error: "Missing title or items" }, { status: 400 });
        }


        // Validate items content
        const validItems = items.filter((item: any) => item.itemName && item.itemName.trim() !== "");
        if (validItems.length === 0) {
            return NextResponse.json({ error: "Procurement plan must have at least one valid item with a name" }, { status: 400 });
        }

        // Generate Code: DTMH-{DDMMYYYY}-{RANDOM}
        const today = new Date();
        const dateStr = today.toLocaleDateString('en-GB').replace(/\//g, '');
        const code = `DTMH-${dateStr}-${Math.floor(Math.random() * 10000).toString().padStart(5, '0')}`;

        const newPlan = await prisma.procurementPlan.create({
            data: {
                title,
                code,
                description,
                supplierBank: supplierBank || '',
                status: 'PENDING',
                createdById: Number(user.id), // Ensure ID is Int
                items: {
                    create: validItems.map((item: any) => ({
                        itemName: item.itemName,
                        category: item.category || 'OFFICE',
                        quantity: parseInt(item.quantity) || 1,
                        unit: item.unit || 'PCS',
                        supplier: item.supplier || '',
                        unitPrice: parseFloat(item.unitPrice || 0),
                        vat: parseFloat(item.vat || 0),
                        bankAccount: item.bankAccount || '',
                        note: item.note
                    }))
                }
            },
            include: {
                items: true,
                createdBy: { select: { id: true, fullName: true } }
            }
        });

        return NextResponse.json(newPlan, { status: 201 });
    } catch (error) {
        console.error("Create Procurement Plan Error:", error);
        return NextResponse.json({ error: "Failed to create plan: " + (error instanceof Error ? error.message : "Unknown error") }, { status: 500 });
    }
}

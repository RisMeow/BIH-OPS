#!/bin/sh
# Quick script to create admin user
node -e "
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

(async () => {
  const hash = await bcrypt.hash('admin', 10);
  const admin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: hash,
      fullName: 'Administrator',
      email: 'admin@bih.vn',
      role: 'ADMIN',
      position: 'MANAGER'
    }
  });
  console.log('✓ Admin created:', admin.username);
  await prisma.\$disconnect();
})();
"

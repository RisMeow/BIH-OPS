import { NextResponse } from 'next/server';
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

// Helper to get current user from session
// Helper to get current user from session
async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;

    return {
        ...session.user,
        id: parseInt(session.user.id as any) // Ensure ID is a number for Prisma
    } as { id: number; role: string; position: string; fullName: string };
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const data = await prisma.nursingRequest.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(data);
    } catch (error) {
        console.error("Fetch Nursing Requests Error:", error);
        return NextResponse.json({ error: 'Error fetching data' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Anyone logged in can create nursing requests
        const body = await request.json();

        if (!body.roomNumber || !body.requestType) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newData = await prisma.nursingRequest.create({
            data: {
                roomNumber: body.roomNumber,
                requestType: body.requestType,
                description: body.description || '',
                priority: body.priority || 'MEDIUM',
                patientName: body.patientName || null,
                status: 'PENDING',
                // Tracking: Lưu thông tin người gửi yêu cầu
                requestedById: user.id,
                requestedBy: user.fullName
            },
        });

        // Notify Nursing Leaders
        try {
            const leaders = await prisma.user.findMany({
                where: { role: 'NURSING', position: { in: ['LEADER', 'MANAGER'] } },
                select: { id: true }
            });

            const { createNotification } = await import("@/lib/notification");

            await Promise.all(leaders.map(leader =>
                createNotification(
                    leader.id,
                    "Yêu cầu Hộ lý mới",
                    `${user.fullName} gửi yêu cầu: ${body.requestType} tại ${body.roomNumber}`,
                    "NURSING",
                    newData.id,
                    "WARNING"
                )
            ));
        } catch (notifError) {
            console.error("Failed to send notifications", notifError);
        }

        return NextResponse.json(newData, { status: 201 });
    } catch (error) {
        console.error("Create Nursing Request Error:", error);
        return NextResponse.json({ error: 'Error creating data' }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const body = await request.json();
        const { id, status, assignedToId, rejectReason } = body;

        const updateData: Record<string, unknown> = {};
        if (status) updateData.status = status;
        if (assignedToId) updateData.assignedToId = parseInt(assignedToId);

        const updated = await prisma.nursingRequest.update({
            where: { id: parseInt(id) },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });

        // Nếu REJECTED, tạo TicketFeedback để người yêu cầu biết lý do
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'NURSING',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Nếu thay đổi trạng thái, tự động ghi nhận timeline
        if (status && status !== 'PENDING') {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'NURSING',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái đã thay đổi thành: ${status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Update Nursing Request Error:", error);
        return NextResponse.json({ error: 'Error updating data' }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');

        if (!id) return NextResponse.json({ error: "Missing ID" }, { status: 400 });

        await prisma.nursingRequest.delete({
            where: { id: parseInt(id) }
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Delete Nursing Request Error:", error);
        return NextResponse.json({ error: 'Error deleting data' }, { status: 500 });
    }
}

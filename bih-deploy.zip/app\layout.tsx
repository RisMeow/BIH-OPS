import type { Metadata } from "next";
import { Be_Vietnam_Pro } from "next/font/google";
import "./globals.css";
import { Providers } from "./Providers";

// Be Vietnam Pro - Font họ Việt Nam, hỗ trợ tốt dấu tiếng Việt
const beVietnamPro = Be_Vietnam_Pro({
    subsets: ["latin", "vietnamese"],
    weight: ["300", "400", "500", "600", "700", "800"],
    display: "swap"
});

export const metadata: Metadata = {
    title: "BIH Administrative Management",
    description: "Becamex International Hospital Infrastructure Management App",
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="vi">
            <body className={beVietnamPro.className}>
                <Providers>{children}</Providers>
            </body>
        </html>
    );
}

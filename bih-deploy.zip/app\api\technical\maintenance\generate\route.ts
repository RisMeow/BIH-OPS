import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { addDays, addWeeks, addMonths, addYears } from 'date-fns';

export async function POST() {
    try {
        const now = new Date();
        const dueSchedules = await prisma.maintenanceSchedule.findMany({
            where: {
                isActive: true,
                nextDueAt: { lte: now }
            },
            include: { asset: true }
        });

        let generatedCount = 0;

        for (const schedule of dueSchedules) {
            // 1. Create Ticket
            const ticket = await prisma.maintenanceRequest.create({
                data: {
                    title: `Bảo trì định kỳ: ${schedule.title}`,
                    description: `Bảo trì định kỳ cho thiết bị: ${schedule.asset.name} (${schedule.asset.code}).\nHạng mục kiểm tra:\n${schedule.checklistItems || 'Theo quy trình chuẩn.'}`,
                    location: schedule.asset.location,
                    priority: 'MEDIUM',
                    status: 'PENDING',
                    requestType: 'MAINTENANCE',
                    reportedBy: 'SYSTEM',
                    reportedById: null // System generated
                }
            });

            // 2. Calculate Next Due Date
            let nextDue = new Date(schedule.nextDueAt || now);
            switch (schedule.frequency) {
                case 'DAILY': nextDue = addDays(nextDue, 1); break;
                case 'WEEKLY': nextDue = addWeeks(nextDue, 1); break;
                case 'MONTHLY': nextDue = addMonths(nextDue, 1); break;
                case 'QUARTERLY': nextDue = addMonths(nextDue, 3); break;
                case 'YEARLY': nextDue = addYears(nextDue, 1); break;
            }

            // 3. Update Schedule
            await prisma.maintenanceSchedule.update({
                where: { id: schedule.id },
                data: {
                    lastExecutedAt: now,
                    nextDueAt: nextDue
                }
            });

            // 4. Create History Record (Initial placeholder)
            await prisma.maintenanceHistory.create({
                data: {
                    assetId: schedule.assetId,
                    type: 'PREVENTIVE',
                    description: `Đã tạo ticket #${ticket.id} cho bảo trì định kỳ.`,
                    performedAt: now,
                    requestId: ticket.id,
                    cost: 0
                }
            });

            generatedCount++;
        }

        return NextResponse.json({ generatedCount });
    } catch (error) {
        console.error("Error generating tickets:", error);
        return NextResponse.json({ error: "Failed to generate tickets" }, { status: 500 });
    }
}

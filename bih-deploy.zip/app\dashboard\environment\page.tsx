"use client";

import { useState, useEffect } from "react";
import { Trees, Trash2, Sprout, SprayCan, CheckCircle2, Clock, MapPin, AlertTriangle, Leaf, Calendar, Scale, Recycle, Plus, Filter } from "lucide-react";
import { clsx } from "clsx";
import { useLanguage } from "@/app/context/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import ConfirmModal from "@/app/components/ConfirmModal";
import Toast, { ToastType } from "@/app/components/Toast";
import DateInput from "@/app/components/DateInput";

interface Request {
    id: number;
    location: string;
    taskType: string;
    description: string;
    status: string;
    createdAt: string;
}

interface WasteLog {
    id: number;
    wasteType: string;
    weight: number;
    location: string;
    collectedAt: string;
    handler: { fullName: string };
    notes: string;
}

interface LandscapeTask {
    id: number;
    taskType: string;
    area: string;
    scheduledDate: string;
    status: string;
    assignedTo?: { fullName: string };
    notes: string;
}

export default function EnvironmentDashboard() {
    const { t } = useLanguage();
    const [activeTab, setActiveTab] = useState<'REQUESTS' | 'WASTE' | 'LANDSCAPE'>('REQUESTS');
    const [requests, setRequests] = useState<Request[]>([]);
    const [wasteLogs, setWasteLogs] = useState<WasteLog[]>([]);
    const [landscapeTasks, setLandscapeTasks] = useState<LandscapeTask[]>([]);

    // UI Feedback State
    const [toast, setToast] = useState<{ isVisible: boolean, message: string, type: ToastType }>({
        isVisible: false, message: "", type: "info"
    });
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        variant: 'danger' | 'info';
        onConfirm: () => void;
    }>({
        isOpen: false, title: "", message: "", variant: "info", onConfirm: () => { }
    });

    const showToast = (message: string, type: ToastType) => {
        setToast({ isVisible: true, message, type });
    };

    // Forms
    const [wasteForm, setWasteForm] = useState({ wasteType: "MEDICAL", weight: "", location: "", notes: "" });
    const [editingWasteId, setEditingWasteId] = useState<number | null>(null);
    const [landscapeForm, setLandscapeForm] = useState({ taskType: "WATERING", area: "", scheduledDate: "", notes: "" });

    // Filter State
    const [dateFilter, setDateFilter] = useState({ start: "", end: "" });

    const filteredWasteLogs = wasteLogs.filter(log => {
        if (!dateFilter.start && !dateFilter.end) return true;
        const logDate = new Date(log.collectedAt).setHours(0, 0, 0, 0);
        const start = dateFilter.start ? new Date(dateFilter.start).setHours(0, 0, 0, 0) : null;
        const end = dateFilter.end ? new Date(dateFilter.end).setHours(0, 0, 0, 0) : null;

        if (start && end) return logDate >= start && logDate <= end;
        if (start) return logDate >= start;
        if (end) return logDate <= end;
        return true;
    });

    const [isLoading, setIsLoading] = useState(true);

    const reload = () => {
        setIsLoading(true);
        Promise.all([
            fetch('/api/environment/requests').then(r => r.json()),
            fetch('/api/environment/waste').then(r => r.json()),
            fetch('/api/environment/landscape').then(r => r.json())
        ]).then(([reqData, wasteData, landscapeData]) => {
            if (Array.isArray(reqData)) setRequests(reqData);
            if (Array.isArray(wasteData)) setWasteLogs(wasteData);
            if (Array.isArray(landscapeData)) setLandscapeTasks(landscapeData);
            setIsLoading(false);
        }).catch(e => {
            console.error(e);
            showToast(t.common.error, "error");
            setIsLoading(false);
        });
    };

    useEffect(() => { reload(); }, []);

    const updateStatus = (id: number, newStatus: string) => {
        setConfirmModal({
            isOpen: true,
            title: t.environment.titleUpdateWaste || "Update Status",
            message: `Change status to "${newStatus}"?`,
            variant: "info",
            onConfirm: async () => {
                try {
                    const res = await fetch(`/api/environment/requests/${id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ status: newStatus }),
                        headers: { 'Content-Type': 'application/json' }
                    });
                    if (res.ok) {
                        showToast(t.common.success, "success");
                        reload();
                    }
                    else showToast(t.common.error, "error");
                } catch (error) {
                    console.error(error);
                    showToast(t.common.error, "error");
                }
            }
        });
    };

    const deleteRequest = (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: t.common.delete,
            message: t.common.confirmDelete,
            variant: "danger",
            onConfirm: async () => {
                try {
                    const res = await fetch(`/api/environment/requests/${id}`, {
                        method: 'DELETE'
                    });
                    if (res.ok) {
                        showToast(t.common.success, "success");
                        reload();
                    }
                    else showToast(t.common.error, "error");
                } catch (error) {
                    console.error(error);
                    showToast(t.common.error, "error");
                }
            }
        });
    };

    const submitWaste = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const url = editingWasteId ? `/api/environment/waste/${editingWasteId}` : '/api/environment/waste';
            const method = editingWasteId ? 'PATCH' : 'POST';

            await fetch(url, {
                method,
                body: JSON.stringify(wasteForm),
                headers: { 'Content-Type': 'application/json' }
            });

            setWasteForm({ wasteType: "MEDICAL", weight: "", location: "", notes: "" });
            setEditingWasteId(null);
            showToast(t.common.success, "success");
            reload();
        } catch (error) {
            showToast(t.common.error, "error");
        }
    };

    const editWaste = (log: WasteLog) => {
        setWasteForm({
            wasteType: log.wasteType,
            weight: log.weight.toString(),
            location: log.location,
            notes: log.notes || ""
        });
        setEditingWasteId(log.id);
    };

    const cancelEditWaste = () => {
        setWasteForm({ wasteType: "MEDICAL", weight: "", location: "", notes: "" });
        setEditingWasteId(null);
    };

    const submitLandscape = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await fetch('/api/environment/landscape', {
                method: 'POST',
                body: JSON.stringify(landscapeForm),
                headers: { 'Content-Type': 'application/json' }
            });
            setLandscapeForm({ taskType: "WATERING", area: "", scheduledDate: "", notes: "" });
            showToast(t.common.success, "success");
            reload();
        } catch (error) {
            showToast(t.common.error, "error");
        }
    };

    const updateLandscapeStatus = (id: number, newStatus: string) => {
        setConfirmModal({
            isOpen: true,
            title: t.environment.titleUpdateWaste || "Update Status",
            message: `Change status to "${newStatus}"?`,
            variant: "info",
            onConfirm: async () => {
                try {
                    const res = await fetch(`/api/environment/landscape/${id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ status: newStatus }),
                        headers: { 'Content-Type': 'application/json' }
                    });
                    if (res.ok) {
                        showToast(t.common.success, "success");
                        reload();
                    } else showToast(t.common.error, "error");
                } catch (error) {
                    console.error(error);
                    showToast(t.common.error, "error");
                }
            }
        });
    };

    const deleteLandscapeTask = (id: number) => {
        setConfirmModal({
            isOpen: true,
            title: t.common.delete,
            message: t.common.confirmDelete,
            variant: "danger",
            onConfirm: async () => {
                try {
                    const res = await fetch(`/api/environment/landscape/${id}`, {
                        method: 'DELETE'
                    });
                    if (res.ok) {
                        showToast(t.common.success, "success");
                        reload();
                    } else showToast(t.common.error, "error");
                } catch (error) {
                    console.error(error);
                    showToast(t.common.error, "error");
                }
            }
        });
    };

    const taskTypes: Record<string, { label: string, icon: any, color: string }> = {
        'ROUTINE': { label: t.environment.typeRoutine, icon: Sprout, color: 'text-emerald-500 bg-emerald-50' },
        'SPILL': { label: t.environment.typeSpill, icon: AlertTriangle, color: 'text-red-500 bg-red-50' },
        'WASTE': { label: t.environment.typeWaste, icon: Trash2, color: 'text-orange-500 bg-orange-50' },
        'LANDSCAPE': { label: t.environment.typeLandscape, icon: Leaf, color: 'text-green-600 bg-green-50' },
    };

    const wasteTypes: Record<string, { label: string, color: string }> = {
        'MEDICAL': { label: t.environment.wasteMedical, color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
        'HAZARDOUS': { label: t.environment.wasteHazardous, color: 'text-black bg-slate-200 border-slate-300' },
        'RECYCLABLE': { label: t.environment.wasteRecycle, color: 'text-blue-600 bg-blue-50 border-blue-200' },
        'GENERAL': { label: t.environment.wasteGeneral, color: 'text-green-600 bg-green-50 border-green-200' },
    };

    // Helper for status, since we don't have explicit environment status keys, reusing technical or common
    const getStatusLabel = (status: string) => {
        switch (status) {
            case 'PENDING': return t.technical?.statusPending || "Pending";
            case 'IN_PROGRESS': return t.technical?.statusInProgress || "In Progress";
            case 'COMPLETED': return t.technical?.statusCompleted || "Completed";
            default: return status;
        }
    };

    const getLandscapeTaskLabel = (type: string) => {
        switch (type) {
            case 'WATERING': return t.environment.landscapeWater;
            case 'MOWING': return t.environment.landscapeMow;
            case 'PRUNING': return t.environment.landscapePrune;
            case 'FERTILIZING': return t.environment.landscapeFertilize;
            case 'CLEANING': return t.environment.landscapeClean;
            default: return type;
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">{t.environment.title}</h2>
                    <p className="text-slate-500">{t.environment.subtitle}</p>
                </div>

                <div className="flex bg-slate-100 p-1 rounded-xl">
                    <button onClick={() => setActiveTab('REQUESTS')} className={clsx("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'REQUESTS' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700")}>
                        {t.environment.tabRequests}
                    </button>
                    <button onClick={() => setActiveTab('WASTE')} className={clsx("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'WASTE' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700")}>
                        {t.environment.tabWaste}
                    </button>
                    <button onClick={() => setActiveTab('LANDSCAPE')} className={clsx("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'LANDSCAPE' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700")}>
                        {t.environment.tabLandscape}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* LEFT CONTENT AREA */}
                <div className="lg:col-span-2 space-y-4">
                    <AnimatePresence mode="wait">
                        {activeTab === 'REQUESTS' && (
                            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {requests.map((req) => {
                                    const typeConfig = taskTypes[req.taskType] || taskTypes['ROUTINE'];
                                    const Icon = typeConfig.icon;
                                    return (
                                        <div key={req.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
                                            <div className={clsx("absolute left-0 top-0 bottom-0 w-1.5",
                                                req.status === 'PENDING' ? "bg-slate-300" :
                                                    req.status === 'IN_PROGRESS' ? "bg-blue-500" : "bg-emerald-500")} />
                                            <div className="flex justify-between items-start mb-3">
                                                <div className={clsx("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", typeConfig.color)}>
                                                    <Icon size={20} />
                                                </div>
                                                <span className={clsx("text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider",
                                                    req.status === 'PENDING' ? "bg-slate-100 text-slate-500" :
                                                        req.status === 'IN_PROGRESS' ? "bg-blue-100 text-blue-600" : "bg-emerald-100 text-emerald-600")}>
                                                    {getStatusLabel(req.status)}
                                                </span>
                                            </div>
                                            <h4 className="font-bold text-slate-800 text-lg mb-1 flex items-center gap-2">
                                                <MapPin size={16} className="text-slate-400" /> {req.location}
                                            </h4>
                                            <p className="text-xs font-bold text-slate-500 uppercase mb-2 ml-6">{typeConfig.label}</p>
                                            <p className="text-sm text-slate-600 mt-2 bg-slate-50 p-3 rounded-xl min-h-[60px]">{req.description || "No description."}</p>
                                            <div className="flex items-center gap-1 mt-4 text-xs text-slate-400">
                                                <Clock size={14} /> {new Date(req.createdAt).toLocaleDateString('en-GB')}
                                            </div>

                                            <div className="mt-4 pt-4 border-t border-slate-100 flex justify-end gap-2">
                                                {req.status === 'PENDING' && (
                                                    <button
                                                        onClick={() => updateStatus(req.id, 'IN_PROGRESS')}
                                                        className="px-3 py-1.5 bg-blue-50 text-blue-600 text-xs font-bold rounded-lg hover:bg-blue-100 transition-colors"
                                                    >
                                                        {t.technical?.tooltipAssign || "Assign"}
                                                    </button>
                                                )}
                                                {req.status === 'IN_PROGRESS' && (
                                                    <button
                                                        onClick={() => updateStatus(req.id, 'COMPLETED')}
                                                        className="px-3 py-1.5 bg-emerald-50 text-emerald-600 text-xs font-bold rounded-lg hover:bg-emerald-100 transition-colors"
                                                    >
                                                        {t.technical?.statusCompleted || "Complete"}
                                                    </button>
                                                )}
                                                <button
                                                    onClick={() => deleteRequest(req.id)}
                                                    className="px-3 py-1.5 bg-slate-50 text-slate-400 text-xs font-bold rounded-lg hover:bg-red-50 hover:text-red-500 transition-colors"
                                                >
                                                    <Trash2 size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })}
                                {requests.length === 0 && (
                                    <div className="col-span-full py-16 text-center border-2 border-dashed border-slate-200 rounded-2xl">
                                        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <Trees className="text-slate-300" size={32} />
                                        </div>
                                        <h3 className="font-bold text-slate-700">{t.environment.emptyRequests}</h3>
                                    </div>
                                )}
                            </motion.div>
                        )}

                        {activeTab === 'WASTE' && (
                            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-6">
                                {/* Waste Stats Dashboard */}
                                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                    {Object.entries(wasteTypes).map(([type, config]) => {
                                        const totalWeight = wasteLogs
                                            .filter(l => l.wasteType === type)
                                            .reduce((sum, l) => sum + l.weight, 0);
                                        return (
                                            <div key={type} className={clsx("p-4 rounded-xl border flex flex-col items-center justify-center text-center", config.color)}>
                                                <span className="text-3xl font-bold bg-white/50 px-2 rounded-lg mb-1">{totalWeight.toFixed(1)}</span>
                                                <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">KG • {config.label}</span>
                                            </div>
                                        );
                                    })}
                                </div>

                                {/* Recent Logs Cards */}
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {wasteLogs.slice(0, 6).map((log) => {
                                        const typeConfig = wasteTypes[log.wasteType] || wasteTypes['GENERAL'];
                                        return (
                                            <div key={log.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between group hover:border-emerald-200 transition-all">
                                                <div>
                                                    <div className="flex justify-between items-start mb-2">
                                                        <span className={clsx("text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider block w-fit border", typeConfig.color)}>
                                                            {typeConfig.label}
                                                        </span>
                                                        <button onClick={() => editWaste(log)} className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                                                            <SprayCan size={14} className="rotate-90" />
                                                        </button>
                                                    </div>
                                                    <div className="flex items-end gap-1 mb-1">
                                                        <span className="text-3xl font-bold text-slate-800">{log.weight}</span>
                                                        <span className="text-sm font-bold text-slate-400 mb-1">KG</span>
                                                    </div>
                                                    <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
                                                        <MapPin size={14} className="text-slate-400" /> {log.location}
                                                    </div>
                                                </div>
                                                <div className="border-t border-slate-50 pt-3 mt-2">
                                                    <div className="flex items-center justify-between text-xs text-slate-400">
                                                        <span>{new Date(log.collectedAt).toLocaleDateString('en-GB')}</span>
                                                        <span>{log.handler?.fullName}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                {/* Historical Table Section */}
                                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                                    <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row justify-between items-end md:items-center gap-4 bg-slate-50/50">
                                        <div>
                                            <h3 className="font-bold text-slate-800 flex items-center gap-2">
                                                <Calendar size={18} className="text-slate-500" /> {t.common.history}
                                            </h3>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                                                <span className="text-xs font-bold text-slate-400">From:</span>
                                                <DateInput
                                                    className="text-xs font-bold text-slate-700 bg-transparent outline-none w-24"
                                                    value={dateFilter.start}
                                                    onChange={(e: any) => setDateFilter({ ...dateFilter, start: e.target.value })}
                                                />
                                            </div>
                                            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                                                <span className="text-xs font-bold text-slate-400">To:</span>
                                                <DateInput
                                                    className="text-xs font-bold text-slate-700 bg-transparent outline-none w-24"
                                                    value={dateFilter.end}
                                                    onChange={(e: any) => setDateFilter({ ...dateFilter, end: e.target.value })}
                                                />
                                            </div>
                                            {(dateFilter.start || dateFilter.end) && (
                                                <button
                                                    onClick={() => setDateFilter({ start: "", end: "" })}
                                                    className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                                >
                                                    <Filter size={16} className="off" />
                                                </button>
                                            )}
                                        </div>
                                    </div>

                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm text-left">
                                            <thead className="text-xs text-slate-500 uppercase bg-slate-50/80 border-b border-slate-100">
                                                <tr>
                                                    <th className="px-6 py-4 font-bold">{t.common.date}</th>
                                                    <th className="px-6 py-4 font-bold">{t.environment.labelWasteType}</th>
                                                    <th className="px-6 py-4 font-bold text-right">{t.environment.labelWeight}</th>
                                                    <th className="px-6 py-4 font-bold">{t.environment.labelSource}</th>
                                                    <th className="px-6 py-4 font-bold">{t.common.createdBy}</th>
                                                    <th className="px-6 py-4 font-bold text-center">{t.common.action}</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-slate-100">
                                                {filteredWasteLogs.map((log) => (
                                                    <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                                                        <td className="px-6 py-4 font-medium text-slate-700">
                                                            <div>{new Date(log.collectedAt).toLocaleDateString('en-GB')}</div>
                                                            <div className="text-xs text-slate-400 font-normal">{new Date(log.collectedAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</div>
                                                        </td>
                                                        <td className="px-6 py-4">
                                                            <span className={clsx("text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider border",
                                                                wasteTypes[log.wasteType]?.color || wasteTypes['GENERAL'].color)}>
                                                                {wasteTypes[log.wasteType]?.label}
                                                            </span>
                                                        </td>
                                                        <td className="px-6 py-4 text-right font-bold text-slate-800">
                                                            {log.weight}
                                                        </td>
                                                        <td className="px-6 py-4 text-slate-600">
                                                            {log.location}
                                                        </td>
                                                        <td className="px-6 py-4 text-slate-600">
                                                            {log.handler?.fullName}
                                                        </td>
                                                        <td className="px-6 py-4 text-center">
                                                            <button onClick={() => editWaste(log)} className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                                                                <SprayCan size={16} className="rotate-90" />
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                                {filteredWasteLogs.length === 0 && (
                                                    <tr>
                                                        <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                                                            {t.common.noData}
                                                        </td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'LANDSCAPE' && (
                            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-3">
                                {landscapeTasks.map((task) => (
                                    <div key={task.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
                                        <div className={clsx("absolute left-0 top-0 bottom-0 w-1.5",
                                            task.status === 'PENDING' ? "bg-slate-300" :
                                                task.status === 'IN_PROGRESS' ? "bg-blue-500" : "bg-emerald-500")} />

                                        <div className="flex flex-col md:flex-row justify-between md:items-start gap-4 mb-3 pl-3">
                                            <div className="flex items-center gap-4">
                                                <div className={clsx("w-12 h-12 rounded-full flex items-center justify-center shrink-0 border",
                                                    task.status === 'COMPLETED' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-slate-50 text-slate-500 border-slate-100")}>
                                                    {task.taskType === 'WATERING' && <SprayCan size={20} />}
                                                    {task.taskType === 'MOWING' && <Recycle size={20} />}
                                                    {task.taskType === 'PRUNING' && <Trees size={20} />}
                                                    {task.taskType === 'FERTILIZING' && <Sprout size={20} />}
                                                    {task.taskType === 'CLEANING' && <Trash2 size={20} />}
                                                    {!['WATERING', 'MOWING', 'PRUNING', 'FERTILIZING', 'CLEANING'].includes(task.taskType) && <Leaf size={20} />}
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-slate-700 text-lg">{task.area}</h4>
                                                    <div className="flex items-center gap-2 text-xs text-slate-500 font-bold uppercase mt-1">
                                                        <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-600">{getLandscapeTaskLabel(task.taskType)}</span>
                                                        <span>•</span>
                                                        <span className="flex items-center gap-1"><Calendar size={12} /> {new Date(task.scheduledDate).toLocaleDateString('en-GB')}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span className={clsx("px-3 py-1 rounded-full text-[10px] font-bold uppercase w-fit",
                                                task.status === 'PENDING' ? "bg-slate-100 text-slate-500" :
                                                    task.status === 'IN_PROGRESS' ? "bg-blue-100 text-blue-600" : "bg-emerald-100 text-emerald-600")}>
                                                {getStatusLabel(task.status)}
                                            </span>
                                        </div>

                                        <div className="mt-4 pt-4 border-t border-slate-50 flex justify-end gap-2 pl-3">
                                            {task.status === 'PENDING' && (
                                                <button
                                                    onClick={() => updateLandscapeStatus(task.id, 'IN_PROGRESS')}
                                                    className="px-3 py-1.5 bg-blue-50 text-blue-600 text-xs font-bold rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-2"
                                                >
                                                    <CheckCircle2 size={14} /> {t.technical?.tooltipAssign || "Assign"}
                                                </button>
                                            )}
                                            {task.status === 'IN_PROGRESS' && (
                                                <button
                                                    onClick={() => updateLandscapeStatus(task.id, 'COMPLETED')}
                                                    className="px-3 py-1.5 bg-emerald-50 text-emerald-600 text-xs font-bold rounded-lg hover:bg-emerald-100 transition-colors flex items-center gap-2"
                                                >
                                                    <CheckCircle2 size={14} /> {t.technical?.statusCompleted || "Complete"}
                                                </button>
                                            )}
                                            <button
                                                onClick={() => deleteLandscapeTask(task.id)}
                                                className="px-3 py-1.5 bg-slate-50 text-slate-400 text-xs font-bold rounded-lg hover:bg-red-50 hover:text-red-500 transition-colors"
                                                title={t.common.delete}
                                            >
                                                <Trash2 size={14} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                                {landscapeTasks.length === 0 && (
                                    <div className="py-16 text-center border-2 border-dashed border-slate-200 rounded-2xl">
                                        <Leaf className="text-slate-300 mx-auto mb-4" size={32} />
                                        <h3 className="font-bold text-slate-700">{t.environment.emptyGreenery}</h3>
                                    </div>
                                )}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* RIGHT FORM PANEL */}
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xl h-fit sticky top-24">
                    {activeTab === 'REQUESTS' && (
                        <div className="text-center py-8 text-slate-500">
                            <Leaf size={40} className="mx-auto mb-3 text-slate-300" />
                            <p className="font-bold text-sm">{t.environment.titleRequest}</p>
                            <p className="text-xs mt-1">{t.environment.subtitleRequest}</p>
                        </div>
                    )}

                    {activeTab === 'WASTE' && (
                        <form onSubmit={submitWaste} className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <Recycle size={20} className="text-emerald-500" />
                                    {editingWasteId ? t.environment.titleUpdateWaste : t.environment.titleWaste}
                                </h3>
                                {editingWasteId && (
                                    <button type="button" onClick={cancelEditWaste} className="text-xs text-red-500 hover:underline font-bold">{t.common.cancel}</button>
                                )}
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelWasteType}</label>
                                <select className="w-full px-4 py-2 border border-slate-200 rounded-xl" value={wasteForm.wasteType} onChange={e => setWasteForm({ ...wasteForm, wasteType: e.target.value })}>
                                    <option value="MEDICAL">{t.environment.wasteMedical}</option>
                                    <option value="HAZARDOUS">{t.environment.wasteHazardous}</option>
                                    <option value="RECYCLABLE">{t.environment.wasteRecycle}</option>
                                    <option value="GENERAL">{t.environment.wasteGeneral}</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelWeight}</label>
                                <input type="number" step="0.1" required className="w-full px-4 py-2 border border-slate-200 rounded-xl" placeholder="0.0" value={wasteForm.weight} onChange={e => setWasteForm({ ...wasteForm, weight: e.target.value })} />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelSource}</label>
                                <input required className="w-full px-4 py-2 border border-slate-200 rounded-xl" placeholder={t.environment.placeholderArea || "Room/Area..."} value={wasteForm.location} onChange={e => setWasteForm({ ...wasteForm, location: e.target.value })} />
                            </div>
                            <button className={clsx("w-full py-3 text-white font-bold rounded-xl transition-all", editingWasteId ? "bg-blue-600 hover:bg-blue-700 shadow-blue-200 shadow-lg" : "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 shadow-lg")}>
                                {editingWasteId ? t.environment.btnUpdate : t.environment.btnSave}
                            </button>
                        </form>
                    )}

                    {activeTab === 'LANDSCAPE' && (
                        <form onSubmit={submitLandscape} className="space-y-4">
                            <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><Sprout size={20} className="text-emerald-500" /> {t.environment.titleGreenery}</h3>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelActivity}</label>
                                <select className="w-full px-4 py-2 border border-slate-200 rounded-xl" value={landscapeForm.taskType} onChange={e => setLandscapeForm({ ...landscapeForm, taskType: e.target.value })}>
                                    <option value="WATERING">{t.environment.landscapeWater}</option>
                                    <option value="MOWING">{t.environment.landscapeMow}</option>
                                    <option value="PRUNING">{t.environment.landscapePrune}</option>
                                    <option value="FERTILIZING">{t.environment.landscapeFertilize}</option>
                                    <option value="CLEANING">{t.environment.landscapeClean}</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelAreaSimple}</label>
                                <input required className="w-full px-4 py-2 border border-slate-200 rounded-xl" placeholder="Ex: Front Garden..." value={landscapeForm.area} onChange={e => setLandscapeForm({ ...landscapeForm, area: e.target.value })} />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.environment.labelDate}</label>
                                <DateInput required className="w-full px-4 py-2 border border-slate-200 rounded-xl" value={landscapeForm.scheduledDate} onChange={(e: any) => setLandscapeForm({ ...landscapeForm, scheduledDate: e.target.value })} />
                            </div>
                            <button className="w-full py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700">{t.environment.btnAddSchedule}</button>
                        </form>
                    )}
                </div>
            </div>

            {/* UI Components */}
            <Toast
                isVisible={toast.isVisible}
                message={toast.message}
                type={toast.type}
                onClose={() => setToast({ ...toast, isVisible: false })}
            />

            <ConfirmModal
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
                variant={confirmModal.variant}
            />
        </div>
    );
}

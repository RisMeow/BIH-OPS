-- Technical Ticket Comment Migration
-- Adds comment/command system for ticket workflow

CREATE TABLE IF NOT EXISTS "TicketComment" (
    "id" SERIAL PRIMARY KEY,
    "requestId" INTEGER NOT NULL REFERENCES "MaintenanceRequest"("id") ON DELETE CASCADE,
    "authorId" INTEGER NOT NULL,
    "authorName" VARCHAR(255) NOT NULL,
    "authorRole" VARCHAR(50) NOT NULL,
    "content" TEXT NOT NULL,
    "type" VARCHAR(50) DEFAULT 'COMMENT',
    "parentId" INTEGER,
    "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS "idx_comment_request" ON "TicketComment"("requestId");
CREATE INDEX IF NOT EXISTS "idx_comment_parent" ON "TicketComment"("parentId");
CREATE INDEX IF NOT EXISTS "idx_comment_author" ON "TicketComment"("authorId");

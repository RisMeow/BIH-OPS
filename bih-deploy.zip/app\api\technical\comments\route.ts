import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return session.user as { id: number; role: string; position: string; name?: string };
}

// GET: Get comments for a ticket
export async function GET(request: Request) {
    try {
        const user = await getUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const requestId = searchParams.get('requestId');

        if (!requestId) {
            return NextResponse.json({ error: "requestId is required" }, { status: 400 });
        }

        const comments = await prisma.ticketComment.findMany({
            where: { requestId: parseInt(requestId) },
            orderBy: { createdAt: 'asc' }
        });

        return NextResponse.json(comments);
    } catch (error) {
        console.error("Fetch comments error:", error);
        return NextResponse.json({ error: 'Failed to fetch comments' }, { status: 500 });
    }
}

// POST: Add a comment/command to a ticket
export async function POST(request: Request) {
    try {
        const user = await getUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        const { requestId, content, type, parentId } = body;

        if (!requestId || !content) {
            return NextResponse.json({ error: "requestId and content are required" }, { status: 400 });
        }

        // Determine author role
        const isLeader = ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(user.position) || user.role === 'ADMIN';
        const authorRole = isLeader ? 'LEADER' : 'STAFF';

        // Determine comment type
        let commentType = type || 'COMMENT';
        if (!type) {
            // Auto-detect: if leader posts first-level comment, it's a COMMAND. If staff replies, it's REPLY
            if (isLeader && !parentId) {
                commentType = 'COMMAND';
            } else if (!isLeader) {
                commentType = 'REPLY';
            }
        }

        const comment = await prisma.ticketComment.create({
            data: {
                requestId: parseInt(requestId),
                authorId: Number(user.id),
                authorName: user.name || 'Unknown',
                authorRole,
                content,
                type: commentType,
                parentId: parentId ? parseInt(parentId) : null
            }
        });

        // Also update ticket status if this is a command from leader
        if (commentType === 'COMMAND' && isLeader) {
            await prisma.maintenanceRequest.update({
                where: { id: parseInt(requestId) },
                data: { status: 'ASSIGNED' }
            });
        }

        return NextResponse.json(comment, { status: 201 });
    } catch (error) {
        console.error("Create comment error:", error);
        return NextResponse.json({ error: 'Failed to create comment' }, { status: 500 });
    }
}

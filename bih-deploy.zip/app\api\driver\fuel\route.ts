import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string } | null;
}

export async function GET(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const { searchParams } = new URL(request.url);
        const vehicleId = searchParams.get('vehicleId');

        const where = vehicleId ? { vehicleId: parseInt(vehicleId) } : {};

        const logs = await prisma.fuelLog.findMany({
            where,
            include: {
                vehicle: { select: { licensePlate: true, brand: true, model: true } },
                filledBy: { select: { fullName: true } }
            },
            orderBy: { filledAt: 'desc' }
        });

        return NextResponse.json(logs);
    } catch (error) {
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const body = await request.json();
        const { vehicleId, liters, pricePerLiter, odoReading, notes } = body;

        if (!vehicleId || !liters || !pricePerLiter) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const totalCost = liters * pricePerLiter;
        // Ensure user ID is an integer
        const filledById = parseInt(String(user.id));

        // Perform transaction: Create Log + Update Vehicle Km
        const result = await prisma.$transaction(async (tx) => {
            const log = await tx.fuelLog.create({
                data: {
                    vehicleId: parseInt(vehicleId),
                    liters: parseFloat(liters),
                    pricePerLiter: parseFloat(pricePerLiter),
                    totalCost,
                    odoReading: parseInt(odoReading) || 0,
                    filledById,
                    notes
                }
            });

            // Update vehicle current KM if new reading is higher
            if (odoReading) {
                const vehicle = await tx.vehicle.findUnique({ where: { id: parseInt(vehicleId) } });
                if (vehicle && (vehicle.currentKm === null || odoReading > vehicle.currentKm)) {
                    await tx.vehicle.update({
                        where: { id: parseInt(vehicleId) },
                        data: { currentKm: parseInt(odoReading) }
                    });
                }
            }

            return log;
        });

        return NextResponse.json(result);
    } catch (error: any) {
        console.error("Create Fuel Log Error Full Details:", JSON.stringify(error, null, 2));
        return NextResponse.json({ error: "Failed to create log: " + (error.message || "Unknown error") }, { status: 500 });
    }
}

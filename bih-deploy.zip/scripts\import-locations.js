
const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const CSV_FILE = 'Bảng dữ liệu Hộ lý - Location.csv';

async function main() {
    const filePath = path.join(process.cwd(), CSV_FILE);

    if (!fs.existsSync(filePath)) {
        console.error(`File not found: ${filePath}`);
        process.exit(1);
    }

    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split(/\r?\n/).filter(line => line.trim() !== '');

    // Headers: Vị trí chi tiết,Block,Mã vị trí,Loại,Hạng phòng,Định mức Tủ,Định mức Ghế
    // Index: 0, 1, 2, 3, 4, 5, 6

    // Skip header
    const dataLines = lines.slice(1);

    console.log(`Found ${dataLines.length} locations to import...`);

    const parentCache = new Map(); // Name -> ID

    // Helper to map type
    const mapType = (rawType, name, code) => {
        const lowerRaw = rawType?.toLowerCase().trim();
        if (lowerRaw === 'công cộng') return 'PUBLIC';
        if (lowerRaw === 'nội trú') return 'ROOM';
        if (lowerRaw === 'wc nội trú') return 'WC';

        // Heuristics
        if (name.toLowerCase().includes('wc') || code?.toLowerCase().includes('wc')) return 'WC';

        return 'ROOM'; // Default
    };

    for (const line of dataLines) {
        // Simple CSV split by comma. 
        // Note: This fails if values contain commas. Assuming they don't based on file view.
        const cols = line.split(',');

        if (cols.length < 4) continue;

        const name = cols[0].trim();
        const parentName = cols[1].trim();
        const code = cols[2].trim();
        const rawType = cols[3].trim();
        const description = cols[4]?.trim() ? `${cols[4]}` : null; // Hạng phòng as description?

        // 1. Handle Parent (Block/Area)
        if (parentName && !parentCache.has(parentName)) {
            // Check DB
            let parent = await prisma.location.findFirst({
                where: { name: parentName, type: 'BLOCK' }
            });

            if (!parent) {
                console.log(`Creating parent Block: ${parentName}`);
                parent = await prisma.location.create({
                    data: {
                        name: parentName,
                        type: 'BLOCK',
                        code: parentName.toUpperCase().replace(/\s+/g, '-'), // Simple code generation
                    }
                });
            }
            parentCache.set(parentName, parent.id);
        }

        const parentId = parentCache.get(parentName);

        // 2. Create Location
        // Check if exists by Code to avoid duplicates?
        const existing = await prisma.location.findFirst({
            where: { code: code }
        });

        if (existing) {
            console.log(`Skipping existing location: ${code} - ${name}`);
            continue;
        }

        const finalType = mapType(rawType, name, code);

        console.log(`Importing: ${name} (${code}) [${finalType}] -> Parent: ${parentName}`);

        await prisma.location.create({
            data: {
                name,
                code,
                type: finalType,
                description,
                parentId
            }
        });
    }

    console.log('Import completed!');
}

main()
    .catch(e => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

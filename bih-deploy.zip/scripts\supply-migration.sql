-- Create ProcurementPlan table
CREATE TABLE IF NOT EXISTS "ProcurementPlan" (
    id SERIAL PRIMARY KEY,
    code VARCHAR(100) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    "supplierBank" VARCHAR(255),
    status VARCHAR(50) DEFAULT 'PENDING',
    "createdById" INTEGER,
    "createdAt" TIMESTAMP DEFAULT NOW(),
    "updatedAt" TIMESTAMP DEFAULT NOW()
);

-- Create ProcurementItem table
CREATE TABLE IF NOT EXISTS "ProcurementItem" (
    id SERIAL PRIMARY KEY,
    "itemName" VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    quantity INTEGER NOT NULL,
    unit VARCHAR(50) NOT NULL,
    supplier VARCHAR(255),
    "unitPrice" FLOAT,
    vat FLOAT DEFAULT 0,
    note TEXT,
    "planId" INTEGER NOT NULL
);

-- Add foreign key constraints
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'ProcurementPlan_createdById_fkey'
    ) THEN
        ALTER TABLE "ProcurementPlan" 
        ADD CONSTRAINT "ProcurementPlan_createdById_fkey" 
        FOREIGN KEY ("createdById") REFERENCES "User"(id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'ProcurementItem_planId_fkey'
    ) THEN
        ALTER TABLE "ProcurementItem" 
        ADD CONSTRAINT "ProcurementItem_planId_fkey" 
        FOREIGN KEY ("planId") REFERENCES "ProcurementPlan"(id) ON DELETE CASCADE;
    END IF;
END $$;

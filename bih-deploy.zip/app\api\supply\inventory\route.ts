import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

export async function GET(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const { searchParams } = new URL(request.url);
        const lowStock = searchParams.get('lowStock');

        // Logic handled in memory or simple DB query.
        // Prisma's where clause for field comparison is complex, so for now we fetch all
        // or filter in memory if the dataset is small (as it likely is for this MVP).
        const items = await prisma.inventoryItem.findMany({
            orderBy: { name: 'asc' },
            include: {
                transactions: {
                    take: 5,
                    orderBy: { createdAt: 'desc' },
                    include: {
                        performedBy: { select: { fullName: true } }
                    }
                }
            }
        });

        let responseData = items;
        if (lowStock === 'true') {
            responseData = items.filter(i => i.quantity <= i.minLevel);
        }

        return NextResponse.json(responseData);
    } catch (error) {
        console.error("Fetch Inventory Error:", error);
        return NextResponse.json({ error: 'Error fetching inventory' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();

        // Create new Item
        if (!body.sku || !body.name) {
            return NextResponse.json({ error: "Vui lòng điền tên và mã SKU" }, { status: 400 });
        }

        const newItem = await prisma.inventoryItem.create({
            data: {
                sku: body.sku,
                name: body.name,
                category: body.category || 'OTHER',
                unit: body.unit || 'PCS',
                minLevel: parseInt(body.minLevel) || 0,
                maxLevel: body.maxLevel ? parseInt(body.maxLevel) : null,
                quantity: parseInt(body.quantity) || 0,
                location: body.location,
                description: body.description,

                // create initial transaction if quantity > 0
                transactions: (parseInt(body.quantity) || 0) > 0 ? {
                    create: {
                        type: 'IMPORT',
                        quantity: parseInt(body.quantity) || 0,
                        reason: 'Tồn kho ban đầu',
                        performedById: parseInt(String(user.id)) // Ensure ID is integer
                    }
                } : undefined
            }
        });

        return NextResponse.json(newItem, { status: 201 });
    } catch (error: any) {
        console.error("Create Inventory Item Error:", error);
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'Mã SKU đã tồn tại' }, { status: 400 });
        }
        // Return actual error for debugging (safe enough for internal app)
        return NextResponse.json({ error: `Lỗi: ${error.message || 'Lỗi server'}` }, { status: 500 });
    }
}

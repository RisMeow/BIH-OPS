import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function createAdmin() {
    const hashedPassword = await bcrypt.hash('admin', 10);

    const admin = await prisma.user.upsert({
        where: { username: 'admin' },
        update: {},
        create: {
            username: 'admin',
            password: hashedPassword,
            fullName: 'Administrator',
            email: 'admin@bih.vn',
            role: 'ADMIN',
            position: 'MANAGER',
        }
    });

    console.log('✓ Admin user created/updated:', admin.username);
    await prisma.$disconnect();
}

createAdmin().catch(console.error);

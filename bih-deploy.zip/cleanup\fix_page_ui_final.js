
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // 1. Add useSession import
    if (!content.includes('import { useSession }')) {
        content = content.replace('import { useLanguage }', 'import { useSession } from "next-auth/react";\nimport { useLanguage }');
        console.log("Import added.");
    }

    // 2. Add hook usage
    if (!content.includes('const { data: session } = useSession();')) {
        content = content.replace('const { t } = useLanguage();', 'const { t } = useLanguage();\n    const { data: session } = useSession();');
        console.log("Hook added.");
    }

    // 3. Remove 'Loại' column from Detail Table
    // Header
    content = content.replace('<th className="border border-slate-300 p-2 text-left w-[15mm]">Loại</th>', '');
    // Body - using regex to match the cell
    // <td className="border border-slate-300 p-2">{typeDisplay}</td>
    const bodyCellRegex = /<td className="border border-slate-300 p-2">\{typeDisplay\}<\/td>/;
    if (bodyCellRegex.test(content)) {
        content = content.replace(bodyCellRegex, '');
        console.log("Loại column data removed.");
    }
    // Remove the unused calculation of typeDisplay if we want to be clean, but not strictly necessary for functionality. 

    // 4. Update Footer ColSpan
    // <td colSpan={8} ...> -> <td colSpan={7} ...>
    content = content.replace('colSpan={8}', 'colSpan={7}');
    content = content.replace('colSpan={3}', 'colSpan={2}'); // Also check the screen view table if needed.

    // Screen view table check:
    // Screen view header: <th className="border p-2 text-center">SL</th>
    // Screen view doesn't seem to have "Loại" column in the code snippet I saw earlier (lines 976-984), wait let me check viewing 976...
    // Ah, lines 976-984 shows: Hạng mục, SL, Đơn giá, Thành tiền. So Screen View didn't have "Category/Loại". 
    // Wait, let's re-read step 786 output. 
    // Lines 1070-1077 (Print view) HAS "Loại". 
    // Lines 976-984 (Screen view) DOES NOT have "Loại". 
    // So only Print View needs modification. Correct.

    // 5. Add VAT Note
    // Look for the VAT input we added previously.
    // <input type="number" ... placeholder="VAT%" title="VAT %" ... />
    // We want to add a note below or change the placeholder/title.
    // User asked for "chu thich".
    // I can append a small <div> after the input row.
    const rowEndRegex = /<input type="number"[\s\S]*?value=\{item\.vat\}[\s\S]*?\/>\s*<\/div>/;
    if (rowEndRegex.test(content)) {
        // We regex match the whole row div closing
        // We find the LAST input (VAT) and append a small text after the div? Or inside?
        // Let's replace the VAT input with itself + a small span or modify the container to wrap.
        // Actually, the user just needs "chu thich trong Tao phieu du tru". 
        // A placeholder "VAT %" is there. 
        // I will add a text below the list or headers? 
        // Let's add a small text in the VAT input placeholder or title.
        // "VAT Field nee co them chu thich" -> Maybe a label "VAT (%)"?
        // Currently: <input ... placeholder="VAT%" ... />
        // Let's replace it with a labelled version or simpler: 
        // Change placeholder to "VAT (%)" if it isn't.
        // Or better: add a <small> tag under the list.

        // I'll add a header for the list columns. currently there are no headers for the item list inputs (lines 818+ just map items).
        // Line 814: "Danh sách chi tiết"
        // I can add a legend.

        const listHeader = `<div className="flex gap-2 mb-1 px-3">
                                                <span className="text-xs font-bold text-slate-500 w-4 text-center">#</span>
                                                <span className="flex-[3] text-xs font-bold text-slate-500">Hạng mục</span>
                                                <span className="flex-[2] text-xs font-bold text-slate-500">NCC</span>
                                            </div>`;

        // Using `replace` on "Danh sách chi tiết" label to add a help text?
        content = content.replace('<label className="text-sm font-bold text-slate-700">Danh sách chi tiết</label>',
            '<label className="text-sm font-bold text-slate-700">Danh sách chi tiết <span className="text-xs font-normal text-slate-400 italic">(Lưu ý: Nhập % VAT cho từng món)</span></label>');

        console.log("VAT note added.");
    }

    // 6. Permissions & Revert Logic
    // We need to inject the logic to determine permissions.
    // Inside SupplyDashboard component function body.
    // Can insert after stats state.

    // Logic: 
    // const canDelete = session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER');
    // const canRevert = session?.user?.role === 'SUPPLY' || session?.user?.role === 'ADMIN'; // Staff can request edit?
    // User said: "Neu supply staff muon dieu chinh lai Phieu du tru thi flow se tro lai buoc duyet cua supply_manager hoac admin."
    // This implies Staff (or anyone) can "Request Edit".

    // We already have `handleApprovePlan` and `handleDeletePlan`.
    // I will add `handleRevertPlan`.

    const revertFunc = `
    const handleRevertPlan = (id: number) => {
        openConfirm("Yêu cầu chỉnh sửa", "Phiếu sẽ được chuyển về trạng thái 'Chờ duyệt' để bạn chỉnh sửa. Xác nhận?", async () => {
            try {
                const res = await fetch(\`/api/supply/plans/\${id}\`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: 'PENDING' }),
                    headers: { 'Content-Type': 'application/json' }
                });
                if (res.ok) {
                    fetchPlans();
                    if (selectedPlan && selectedPlan.id === id) setSelectedPlan({ ...selectedPlan, status: 'PENDING' });
                    showToast("Đã chuyển về trạng thái Chờ duyệt!", 'success');
                } else {
                    const data = await res.json();
                    showToast("Lỗi: " + data.error, 'error');
                }
            } catch (e) { console.error(e); showToast("Lỗi kết nối", 'error'); }
        }, 'info');
    };
    `;

    // Insert function before return
    content = content.replace('return (', revertFunc + '\n    return (');

    // Update Button Logic in Detail Modal
    // Look for: {selectedPlan.status === 'APPROVED' && (
    // Replace the content block.

    const approvedBlockRegex = /\{selectedPlan\.status === 'APPROVED' && \(\s*<>[\s\S]*?<\/button>\s*<\/button>\s*<>\s*\)\}/;
    // The previous code had nested fragments or buttons?
    // Let's look at the file content lines 1014-1021.
    /*
    {selectedPlan.status === 'APPROVED' && (
                                    <>
                                        <button onClick={handleDownloadPDF} ...>
                                            <Download size={18} /> PDF
                                        </button>
                                        
                                    </>
                                )}
    */

    const approvedBlockStart = `{selectedPlan.status === 'APPROVED' && (`;
    // We will construct the new block.
    // We need logic variables available in render scope.
    // I'll put the logic check inline or define vars at top of render.
    // Inline: 
    // const isManager = session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER');

    // Let's replace the whole approved block.
    const approvedNewBlock = `{selectedPlan.status === 'APPROVED' && (
                                    <>
                                        {(session?.user?.role === 'ADMIN' || (session?.user?.role === 'SUPPLY' && session?.user?.position === 'MANAGER')) && (
                                            <button onClick={() => handleDeletePlan(selectedPlan.id)} className="px-4 py-2 text-red-600 hover:bg-red-50 font-bold rounded-xl border border-transparent hover:border-red-100">Xóa phiếu</button>
                                        )}
                                        
                                        <button onClick={() => handleRevertPlan(selectedPlan.id)} className="px-4 py-2 bg-amber-100 text-amber-700 font-bold rounded-xl hover:bg-amber-200">Điều chỉnh</button>

                                        <button onClick={handleDownloadPDF} className="px-6 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 flex items-center gap-2">
                                            <Download size={18} /> PDF
                                        </button>
                                    </>
                                )}`;

    // I need to match the existing block robustly.
    // It contains "handleDownloadPDF" and "PDF".
    const pdfBtnRegex = /<button onClick=\{handleDownloadPDF\}[\s\S]*?PDF\s*<\/button>/;
    // Find the enclosing block??
    // It's safer to target the specific APPROVED block if possible.
    // I'll try to find the block by context.

    const oldApprovedBlockRegex = /\{selectedPlan\.status === 'APPROVED' && \(\s*<>[\s\S]*?handleDownloadPDF[\s\S]*?<\/button>\s*<>\s*\)\}/;
    // My previous fix removed the Print button, so the block ends with the PDF button closing tag and fragment closing.
    // `<button ...> <Download ... /> PDF </button> </> )}`

    const matchApproved = content.match(/\{selectedPlan\.status === 'APPROVED' && \(\s*<>[\s\S]*?PDF\s*<\/button>\s*<>\s*\)\}/);
    if (matchApproved) {
        content = content.replace(matchApproved[0], approvedNewBlock);
        console.log("Approved buttons updated.");
    } else {
        console.log("Could not match Approved buttons block explicitly. Trying looser match.");
        // Try matching just the PDF button and wrapping it? No, need to inject siblings.
        // Let's assume the previous `fix_page_pdf.js` left it as:
        /*
        {selectedPlan.status === 'APPROVED' && (
                                   <>
                                       <button onClick={handleDownloadPDF} className="...">
                                           <Download size={18} /> PDF
                                       </button>
                                       
                                   </>
                               )}
        */
        // The regex `\{selectedPlan\.status === 'APPROVED' && \(\s*<>[\s\S]*?PDF\s*<\/button>\s*<>\s*\)\}` should work if whitespace matches.
        // Let's try a split string approach if regex fails.
    }

    fs.writeFileSync(path, content);
    console.log("Final UI updates applied.");

} catch (e) {
    console.error("Error:", e);
}

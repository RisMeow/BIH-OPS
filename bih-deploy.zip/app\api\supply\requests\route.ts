import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string };
}

function canManageSupply(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (user.role === 'SUPPLY' && ['MANAGER', 'LEADER'].includes(user.position)) return true;
    return false;
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const requests = await prisma.supplyRequest.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                inventory: true
            }
        });
        return NextResponse.json(requests);
    } catch (error) {
        console.error("Fetch Supply Requests Error:", error);
        return NextResponse.json({ error: "Failed to fetch supply requests" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        let { itemName, category, quantity, unit, urgency, requester, title, priority, location, description, inventoryId } = body;

        // Mapping for Generic Request Form
        if (title && !itemName) {
            itemName = title;
            category = 'GENERAL';
            quantity = 1;
            unit = 'Lần/Cái';
            urgency = priority || 'NORMAL';
            const locInfo = location ? ` (Tại: ${location})` : '';
            requester = user.fullName + locInfo;
        }

        if (!itemName) {
            return NextResponse.json({ error: "Missing required fields (itemName or title)" }, { status: 400 });
        }

        const newRequest = await prisma.supplyRequest.create({
            data: {
                itemName,
                category: category || 'GENERAL',
                quantity: parseInt(quantity) || 1,
                unit: unit || 'PCS',
                urgency: urgency || 'NORMAL',
                requester: requester || user.fullName,
                status: 'PENDING',
                inventoryId: inventoryId ? parseInt(inventoryId) : undefined,
                // Tracking: Lưu thông tin người gửi yêu cầu
                requestedById: user.id
            }
        });

        // Notify Supply Leaders
        try {
            const leaders = await prisma.user.findMany({
                where: { role: 'SUPPLY', position: { in: ['LEADER', 'MANAGER'] } },
                select: { id: true }
            });

            const { createNotification } = await import("@/lib/notification");

            await Promise.all(leaders.map(leader =>
                createNotification(
                    leader.id,
                    "Yêu cầu vật tư mới",
                    `${user.fullName} yêu cầu: ${itemName} (SL: ${quantity})`,
                    "SUPPLY",
                    newRequest.id,
                    "WARNING"
                )
            ));
        } catch (notifError) {
            console.error("Failed to send notifications", notifError);
        }

        return NextResponse.json(newRequest, { status: 201 });
    } catch (error) {
        console.error("Create Supply Request Error:", error);
        return NextResponse.json({ error: "Failed to create supply request" }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const body = await request.json();
        const { id, status, assignedToId, rejectReason } = body;

        if (!id) {
            return NextResponse.json({ error: "Missing ID" }, { status: 400 });
        }

        const updateData: Record<string, unknown> = {};
        if (status) updateData.status = status;
        if (assignedToId !== undefined) updateData.assignedToId = assignedToId ? parseInt(assignedToId) : null;

        const updated = await prisma.supplyRequest.update({
            where: { id: parseInt(id) },
            data: updateData,
            include: {
                assignedTo: { select: { id: true, fullName: true } },
                inventory: true
            }
        });

        // Nếu REJECTED, tạo TicketFeedback
        if (status === 'REJECTED' && rejectReason) {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'SUPPLY',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: rejectReason,
                    type: 'REJECT_REASON',
                    statusSnapshot: 'REJECTED'
                }
            });
        }

        // Ghi nhận timeline khi thay đổi trạng thái
        if (status && status !== 'PENDING') {
            await prisma.ticketFeedback.create({
                data: {
                    ticketType: 'SUPPLY',
                    ticketId: parseInt(id),
                    authorId: user.id,
                    authorName: user.fullName,
                    authorRole: user.role === 'ADMIN' ? 'ADMIN' : user.position,
                    content: `Trạng thái đã thay đổi thành: ${status}`,
                    type: 'STATUS_CHANGE',
                    statusSnapshot: status
                }
            });
        }

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Update Supply Request Error:", error);
        return NextResponse.json({ error: "Failed to update supply request" }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        if (!canManageSupply(user)) {
            return NextResponse.json({ error: "Permission denied: Manager only" }, { status: 403 });
        }

        // Check for Bulk Delete (Body with ids)
        try {
            const body = await request.json();
            if (body.ids && Array.isArray(body.ids) && body.ids.length > 0) {
                const ids = body.ids.map((id: any) => parseInt(id));
                const result = await prisma.supplyRequest.deleteMany({
                    where: { id: { in: ids } }
                });
                return NextResponse.json({ success: true, count: result.count });
            }
        } catch (e) {
            // Ignore JSON parse error, might be empty body or normal DELETE
        }

        // Check for Single Delete (Query Param)
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');

        if (id) {
            await prisma.supplyRequest.delete({
                where: { id: parseInt(id) }
            });
            return NextResponse.json({ success: true });
        }

        return NextResponse.json({ error: "Missing ID or IDs" }, { status: 400 });
    } catch (error) {
        console.error("Delete Supply Request Error:", error);
        return NextResponse.json({ error: "Failed to delete supply request" }, { status: 500 });
    }
}

import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string } | null;
}

// Helper: Check permission
function canManageDriver(user: { role: string; position: string } | null): boolean {
    if (!user) return false;
    const role = user.role?.toUpperCase();
    const position = user.position?.toUpperCase();

    if (role === 'ADMIN') return true;
    if (role === 'DRIVER' && ['MANAGER', 'LEADER', 'SUPERVISOR'].includes(position)) return true;
    return false;
}

// PATCH: Edit Fuel Log
export async function PATCH(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const id = parseInt(params.id);
        const body = await request.json();
        const { vehicleId, liters, pricePerLiter, odoReading, notes } = body;

        // Check ownership or permission
        const currentLog = await prisma.fuelLog.findUnique({ where: { id } });
        if (!currentLog) return NextResponse.json({ error: "Not found" }, { status: 404 });

        // Only Creator or Manager can edit
        const isCreator = currentLog.filledById === parseInt(String(user.id));
        const isManager = canManageDriver(user);

        if (!isCreator && !isManager) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        const dataToUpdate: any = {};
        if (vehicleId) dataToUpdate.vehicleId = parseInt(vehicleId);
        if (liters) dataToUpdate.liters = parseFloat(liters);
        if (pricePerLiter) dataToUpdate.pricePerLiter = parseFloat(pricePerLiter);
        if (odoReading) dataToUpdate.odoReading = parseInt(odoReading);
        if (notes !== undefined) dataToUpdate.notes = notes;

        // Recalculate total cost if liters or price changed
        const newLiters = liters ? parseFloat(liters) : currentLog.liters;
        const newPrice = pricePerLiter ? parseFloat(pricePerLiter) : currentLog.pricePerLiter;
        dataToUpdate.totalCost = newLiters * newPrice;

        const updatedLog = await prisma.fuelLog.update({
            where: { id },
            data: dataToUpdate
        });

        // Optional: Update Vehicle ODO if this is the latest log? 
        // For simplicity, we might skip re-syncing vehicle ODO on edit unless strictly required, 
        // as it might conflict with newer logs. 
        // But if ODO is changed, we *could* check if it's > current vehicle ODO.
        if (dataToUpdate.odoReading && dataToUpdate.vehicleId) {
            const vId = dataToUpdate.vehicleId || currentLog.vehicleId;
            const vehicle = await prisma.vehicle.findUnique({ where: { id: vId } });
            if (vehicle && (vehicle.currentKm === null || dataToUpdate.odoReading > vehicle.currentKm)) {
                await prisma.vehicle.update({
                    where: { id: vId },
                    data: { currentKm: dataToUpdate.odoReading }
                });
            }
        }

        return NextResponse.json(updatedLog);

    } catch (error: any) {
        console.error("Edit Fuel Log Error:", error);
        return NextResponse.json({ error: "Failed to edit log" }, { status: 500 });
    }
}

// DELETE: Delete Fuel Log
export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const user = await getCurrentUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const id = parseInt(params.id);
        const currentLog = await prisma.fuelLog.findUnique({ where: { id } });
        if (!currentLog) return NextResponse.json({ error: "Not found" }, { status: 404 });

        // Only Creator or Manager can delete
        const isCreator = currentLog.filledById === parseInt(String(user.id));
        const isManager = canManageDriver(user);

        if (!isCreator && !isManager) {
            return NextResponse.json({ error: "Permission denied" }, { status: 403 });
        }

        await prisma.fuelLog.delete({ where: { id } });

        return NextResponse.json({ message: "Deleted successfully" });

    } catch (error: any) {
        console.error("Delete Fuel Log Error:", error);
        return NextResponse.json({ error: "Failed to delete log" }, { status: 500 });
    }
}

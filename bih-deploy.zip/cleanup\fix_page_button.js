
const fs = require('fs');
const path = 'app/dashboard/supply/page.tsx';

try {
    let content = fs.readFileSync(path, 'utf8');

    // Regex to locate the existing INVENTORY button block
    // We look for: {activeTab === 'INVENTORY' && (...)}
    const inventoryBtnRegex = /\{activeTab === 'INVENTORY' && \(\s*<button[\s\S]*?onClick=\{\(\) => setIsCreateItemModalOpen\(true\)\}[\s\S]*?<\/button>\s*\)\}/;

    if (inventoryBtnRegex.test(content)) {
        const match = content.match(inventoryBtnRegex)[0];
        const newBlock = `${match}
                    {activeTab === 'PLANS' && (
                        <button
                            onClick={() => setIsCreatePlanModalOpen(true)}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 flex items-center gap-2"
                        >
                            <Plus size={18} /> Tạo phiếu dự trù
                        </button>
                    )}`;

        content = content.replace(inventoryBtnRegex, newBlock);
        fs.writeFileSync(path, content);
        console.log("Create Plan button added successfully.");
    } else {
        console.log("Could not find Inventory button block to append Plan button.");
    }

} catch (e) {
    console.error("Error:", e);
}

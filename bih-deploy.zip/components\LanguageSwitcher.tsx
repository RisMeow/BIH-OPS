"use client";

import { useLanguage } from "@/app/context/LanguageContext";
import { clsx } from "clsx";
import { motion } from "framer-motion";

export default function LanguageSwitcher() {
    const { locale, switchLanguage } = useLanguage();

    return (
        <div className="relative flex items-center bg-slate-100 p-1 rounded-full border border-slate-200 w-[84px]">
            {/* Sliding Background */}
            <motion.div
                className="absolute top-1 bottom-1 w-[36px] bg-white rounded-full shadow-sm z-0"
                initial={false}
                animate={{
                    x: locale === 'vi' ? 0 : 40
                }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
            />

            {/* VI Button */}
            <button
                onClick={() => switchLanguage('vi')}
                className={clsx(
                    "relative z-10 w-[38px] py-1 text-[10px] font-bold text-center rounded-full transition-colors duration-200",
                    locale === 'vi' ? "text-blue-700" : "text-slate-400 hover:text-slate-600"
                )}
            >
                VN
            </button>

            {/* EN Button */}
            <button
                onClick={() => switchLanguage('en')}
                className={clsx(
                    "relative z-10 w-[38px] py-1 text-[10px] font-bold text-center rounded-full transition-colors duration-200",
                    locale === 'en' ? "text-blue-700" : "text-slate-400 hover:text-slate-600"
                )}
            >
                EN
            </button>
        </div>
    );
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user as { id: number; role: string; position: string; fullName: string } | null;
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const inventoryId = parseInt(params.id);
        const body = await request.json();

        // Transaction Logic
        // Type: IMPORT (Add), EXPORT (Subtract)

        if (!body.type || !body.quantity) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const qty = parseInt(body.quantity);
        if (isNaN(qty) || qty <= 0) {
            return NextResponse.json({ error: "Invalid quantity" }, { status: 400 });
        }

        // Transaction
        const transactionResult = await prisma.$transaction(async (tx) => {
            // 1. Update master Quantity
            const currentItem = await tx.inventoryItem.findUnique({ where: { id: inventoryId } });
            if (!currentItem) throw new Error("Item not found");

            let newQuantity = currentItem.quantity;
            if (body.type === 'IMPORT' || body.type === 'RETURN') {
                newQuantity += qty;
            } else if (body.type === 'EXPORT') {
                if (currentItem.quantity < qty) throw new Error("Thất bại: Tồn kho không đủ để xuất.");
                newQuantity -= qty;
            } else {
                throw new Error("Invalid Type");
            }

            const updatedItem = await tx.inventoryItem.update({
                where: { id: inventoryId },
                data: { quantity: newQuantity }
            });

            // 2. Create Transaction Log
            const log = await tx.inventoryTransaction.create({
                data: {
                    inventoryId: inventoryId,
                    type: body.type,
                    quantity: qty,
                    reason: body.reason,
                    referenceId: body.referenceId || null,
                    performedById: parseInt(String(user.id)) // Ensure ID is parsed to Int
                }
            });

            return { item: updatedItem, log };
        });

        return NextResponse.json(transactionResult);

    } catch (error: any) {
        console.error("Inventory Transaction Error:", error);
        return NextResponse.json({ error: error.message || 'Error processing transaction' }, { status: 500 });
    }
}

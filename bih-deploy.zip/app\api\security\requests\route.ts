import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const prisma = new PrismaClient();

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user) return null;
    return {
        ...session.user,
        id: parseInt(session.user.id as any)
    } as { id: number; role: string; position: string; fullName: string };
}

export async function GET() {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const reports = await prisma.securityReport.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                assignedTo: { select: { id: true, fullName: true } }
            }
        });
        return NextResponse.json(reports);
    } catch (error) {
        console.error("Fetch Security Reports Error:", error);
        return NextResponse.json({ error: "Failed to fetch reports" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Anyone can report security incidents
        const body = await request.json();
        const { location, incidentType, description, severity } = body;

        if (!location || !incidentType || !description) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const newReport = await prisma.securityReport.create({
            data: {
                location,
                incidentType,
                description,
                severity: severity || 'LOW',
                status: 'PENDING',
                reportedById: user.id,
                reportedBy: user.fullName
            }
        });

        return NextResponse.json(newReport, { status: 201 });
    } catch (error) {
        console.error("Create Security Report Error:", error);
        return NextResponse.json({ error: "Failed to create report" }, { status: 500 });
    }
}

import { NextResponse } from 'next/server';
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET() {
    try {
        const session = await getServerSession(authOptions);
        if (!session) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const [
            techTotal, techActive, techCompleted,
            nursingTotal, nursingActive,
            driverTotal, driverActive,
            securityTotal, securityActive,
            supplyTotal, supplyActive,
            envTotal, envActive,
            fuelCostAgg
        ] = await Promise.all([
            // Technical
            prisma.maintenanceRequest.count(),
            prisma.maintenanceRequest.count({ where: { status: { in: ['PENDING', 'ASSIGNED', 'IN_PROGRESS'] } } }),
            prisma.maintenanceRequest.findMany({
                where: { status: 'COMPLETED' },
                select: { createdAt: true, updatedAt: true },
                take: 500 // Sample size for performance
            }),

            // Nursing
            prisma.nursingRequest.count(),
            prisma.nursingRequest.count({ where: { status: { in: ['PENDING'] } } }),

            // Driver
            prisma.transportRequest.count(),
            prisma.transportRequest.count({ where: { status: { in: ['PENDING', 'ASSIGNED', 'APPROVED', 'IN_PROGRESS'] } } }),

            // Security
            prisma.securityReport.count(),
            prisma.securityReport.count({ where: { status: { in: ['OPEN', 'PENDING', 'ASSIGNED', 'IN_PROGRESS'] } } }),

            // Supply
            prisma.supplyRequest.count(),
            prisma.supplyRequest.count({ where: { status: { in: ['PENDING'] } } }),

            // Environment
            prisma.cleaningRequest.count(),
            prisma.cleaningRequest.count({ where: { status: { in: ['PENDING'] } } }),

            // Operating Cost (Fuel)
            prisma.fuelLog.aggregate({
                _sum: { totalCost: true }
            })
        ]);

        const totalRequests = techTotal + nursingTotal + driverTotal + securityTotal + supplyTotal + envTotal;
        const totalActive = techActive + nursingActive + driverActive + securityActive + supplyActive + envActive;

        // Calculate SLA (Average Resolution Time in hours)
        let totalTimeMs = 0;
        let countSLA = 0;

        techCompleted.forEach(req => {
            const diff = new Date(req.updatedAt).getTime() - new Date(req.createdAt).getTime();
            if (diff > 0) {
                totalTimeMs += diff;
                countSLA++;
            }
        });

        const avgResolutionTimeHours = countSLA > 0 ? (totalTimeMs / countSLA / (1000 * 60 * 60)) : 0;

        // Calculate performance score (inverse of resolution time, simplified)
        // Base 100, deduct 1 point for every 2 hours over 24h average? Or just use completion rate
        const completionRate = totalRequests > 0 ? ((totalRequests - totalActive) / totalRequests) * 100 : 100;

        return NextResponse.json({
            overview: {
                totalRequests,
                totalActive,
                performance: Math.round(completionRate),
                avgResolutionTime: avgResolutionTimeHours.toFixed(1), // New field
                operatingCost: fuelCostAgg._sum.totalCost || 0
            },
            departments: {
                technical: { total: techTotal, active: techActive },
                nursing: { total: nursingTotal, active: nursingActive },
                driver: { total: driverTotal, active: driverActive },
                security: { total: securityTotal, active: securityActive },
                supply: { total: supplyTotal, active: supplyActive },
                environment: { total: envTotal, active: envActive }
            }
        });

    } catch (error) {
        console.error("Error fetching system stats:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
